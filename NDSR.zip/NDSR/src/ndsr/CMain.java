package ndsr;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class CMain {
	@SuppressWarnings("unchecked")
	// [REV 2026-11] args: Scenario Seed [WITH|WITHOUT] [threads]
	public static int THREADS = 12;

	public static void main(String[] args) throws Exception {
		{			
			int Scenario=Integer.parseInt(args[0]);
			int Seed=Integer.parseInt(args[1]);
			String config = args.length>2 ? args[2].toUpperCase() : "WITH";
			if (!config.equals("WITH") && !config.equals("WITHOUT")) throw new IllegalArgumentException("config must be WITH or WITHOUT");
			CODSet.PRECUT = config.equals("WITH");
			if (args.length>3) THREADS = Integer.parseInt(args[3]);
			System.out.println("CONFIG\t" + config + "\tPRECUT=" + CODSet.PRECUT + "\tTHREADS=" + THREADS);
			
			int Node_N=CODSet.GetScenarioNode(Scenario); 
			int Arc_N=CODSet.GetScenarioArc(Scenario); 
			int OD_N=CODSet.GetScenarioOD(Scenario); 

			String dataDir=System.getProperty("ndsr.data","data");   // folder with Scenario<k>_S<seed>.txt
			String file=dataDir+"/Scenario"+Scenario
			+"_S"+Seed+".txt";
			
			CODSet.Init(file,OD_N);
			System.out.println("PREP_STATS\tt_precut=" + String.format("%.4f", CODSet.T_PRECUT)
					+ "\tt_enum=" + String.format("%.4f", CODSet.T_ENUM)
					+ "\tpool=" + CutPool.size());
			
			CGRB grb=new CGRB ();
			grb.Init();
			grb.build_model(Node_N);
			grb.solve();
			grb.lpOrig();
			grb.end();
			
			System.out.println("N"+Node_N+"A"+Arc_N+"C"+OD_N+"_"+CODSet.SEED+"\t"+grb.objVal+"\t"+grb.runtime+"\t"
					+grb.gap);
		}
	}
}
