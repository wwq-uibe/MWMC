package ndsr;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

public class CGRB {

	GRBEnv env;
	GRBModel model;	
	
	GRBVar[] z;
	GRBVar[] x;
	
	public ArrayList<Integer> openarclist=new ArrayList<Integer> ();
	public ArrayList<CArc> OpenArc=new ArrayList<CArc> ();
	
	public double objVal;
	public double runtime;
	public double gap;
	public int path_number=0;
	public int nPreCuts=0;
	
	public void Init() throws GRBException {
		// [REV 2026-11] no shared log file; retry if the token server is busy; explicit thread count
		env = StartEnv();
        
        model = new GRBModel(env);
        model.set(GRB.IntParam.Threads, CMain.THREADS);
        model.set(GRB.DoubleParam.TimeLimit, 3600.0);
        model.set(GRB.IntParam.LazyConstraints, 1);
        model.set(GRB.IntParam.PreCrush, 1);
        
        for (int od=0;od<CODSet.ODSet.size();od++) {
        	path_number+=CODSet.ODSet.get(od).LABELLIST.size();
        }
        
        int var_p=0;
        for (int od=0;od<CODSet.ODSet.size();od++) {
        	for (int l=0;l<CODSet.ODSet.get(od).LABELLIST.size();l++) {
        		CODSet.ODSet.get(od).LABELLIST.get(l).var_p=var_p;
        		var_p++;
        	}
        }
	}
	
	static GRBEnv StartEnv() throws GRBException {
		for (int attempt=1;;attempt++) {
			try {
				GRBEnv e = new GRBEnv(true);
				e.start();
				return e;
			} catch (GRBException ex) {
				if (attempt>=60) throw ex;
				System.out.println("GRB_ENV_RETRY\tattempt="+attempt+"\tcode="+ex.getErrorCode()+"\tmsg="+ex.getMessage());
				try { Thread.sleep(60000); } catch (InterruptedException ie) { throw ex; }
			}
		}
	}

	public void build_model(int Node_N) throws GRBException {		
	    z=new GRBVar[CODSet.ArcSet.size()];
	    for (int a=0;a<CODSet.ArcSet.size();a++) {
	    	z[a]=model.addVar(0, 1, 0, GRB.BINARY, "z" +a);
	    }
	    
	    x=new GRBVar[path_number];
	    for (int i=0;i<x.length;i++) {
	    	x[i]=model.addVar(0, 1, 0, GRB.BINARY, "x" +x);
	    }
	    //add cuts (the pool is empty in configuration WITHOUT)
	    nPreCuts = CutPool.pool.size();
	    for (Set<Integer> cut : CutPool.pool) {
            ArrayList<Integer> list = new ArrayList<>(cut);
            GRBLinExpr temp = new GRBLinExpr();
            for (int i=0;i<list.size();i++) {
            	int a=list.get(i);
            	temp.addTerm(1.0, z[a]);
            }
            model.addConstr(temp, GRB.GREATER_EQUAL, 1, null);
        }

	    //For each OD, must select one path
	    for (int od=0;od<CODSet.ODSet.size();od++) {
	    	GRBLinExpr temp = new GRBLinExpr();
	    	for (int l=0;l<CODSet.ODSet.get(od).LABELLIST.size();l++) {
	    		int var_p=CODSet.ODSet.get(od).LABELLIST.get(l).var_p;
	    		temp.addTerm(1.0, x[var_p]);
	    	}
	    	model.addConstr(temp, GRB.EQUAL, 1, null);
	    }
	    
	    //For each OD, if arc is not active, all relate path must be close
	    for (int a=0;a<z.length;a++) {
	    	for (int od=0;od<CODSet.ODSet.size();od++) {
	    		GRBLinExpr temp = new GRBLinExpr();
	    		for (int l=0;l<CODSet.ODSet.get(od).LABELLIST.size();l++) {
	    			if (CODSet.ODSet.get(od).LABELLIST.get(l).arc_visit_sequence.indexOf(a)>=0) {
	    				int var_p=CODSet.ODSet.get(od).LABELLIST.get(l).var_p;
	    				temp.addTerm(1.0, x[var_p]);
	    			}
	    		}
	    		model.addConstr(z[a], GRB.GREATER_EQUAL, temp, null);
	    	}
	    }
	    //obj
	    GRBLinExpr obj = new GRBLinExpr();
	    for (int a=0;a<CODSet.ArcSet.size();a++) {
	    	obj.addTerm(CODSet.ArcSet.get(a).fix_cost, z[a]);
	    }
	    for (int od=0;od<CODSet.ODSet.size();od++) {
    		for (int l=0;l<CODSet.ODSet.get(od).LABELLIST.size();l++) {
    			double path_cost=CODSet.ODSet.get(od).LABELLIST.get(l).cost;
    			int var_p=CODSet.ODSet.get(od).LABELLIST.get(l).var_p;
    			obj.addTerm(path_cost, x[var_p]);
    		}
	    }
	    model.setObjective(obj, GRB.MINIMIZE);
	    
	    //test

	}
	
	public void solve() throws GRBException, IOException {	
	//	CMyCB cb=new CMyCB (z);
	//	model.setCallback(cb);
		
		model.optimize();		
		
		// [REV 2026-11] solver statistics in one parseable line; no exception if no incumbent
		int status = model.get(GRB.IntAttr.Status);
		int solCount = model.get(GRB.IntAttr.SolCount);
        objVal = solCount>0 ? model.get(GRB.DoubleAttr.ObjVal) : Double.NaN;
        runtime=model.get(GRB.DoubleAttr.Runtime);
        gap = solCount>0 ? model.get(GRB.DoubleAttr.MIPGap) : Double.NaN;
        double work = Double.NaN;
        try { work = model.get(GRB.DoubleAttr.Work); } catch (Exception ignore) {}
        System.out.println("GRB_STATS\tstatus=" + status
        		+ "\tobj=" + objVal
        		+ "\tbound=" + model.get(GRB.DoubleAttr.ObjBound)
        		+ "\tgap=" + gap
        		+ "\tnodes=" + model.get(GRB.DoubleAttr.NodeCount)
        		+ "\titer=" + model.get(GRB.DoubleAttr.IterCount)
        		+ "\truntime=" + runtime
        		+ "\twork=" + work
        		+ "\tn_precuts=" + nPreCuts
        		+ "\tn_paths=" + path_number);
		
		openarclist.clear();
		OpenArc.clear();
		if (solCount<=0) return;
		for (int a=0;a<z.length;a++) {
			if (z[a].get(GRB.DoubleAttr.X)>0.5) {
				openarclist.add(a);
				OpenArc.add(CODSet.ArcSet.get(a));
			}
		}
	}
	
	/** [REV 2026-11] LP relaxation of the original (unpresolved) model, solved after the MIP and not timed. */
	public void lpOrig() {
		GRBModel r = null;
		try {
			r = model.relax();
			r.set(GRB.IntParam.OutputFlag, 0);
			r.set(GRB.IntParam.Threads, CMain.THREADS);
			r.set(GRB.DoubleParam.TimeLimit, 600.0);
			r.optimize();
			int st = r.get(GRB.IntAttr.Status);
			double v = st==GRB.Status.OPTIMAL ? r.get(GRB.DoubleAttr.ObjVal) : Double.NaN;
			System.out.println("LP_ORIG\tstatus=" + st + "\tobj=" + v + "\truntime=" + r.get(GRB.DoubleAttr.Runtime));
		} catch (GRBException e) {
			System.out.println("LP_ORIG\terror=" + e.getMessage());
		} finally {
			if (r != null) r.dispose();
		}
	}

	public void end () throws GRBException {
		model.dispose();
        env.dispose();
	}

}
