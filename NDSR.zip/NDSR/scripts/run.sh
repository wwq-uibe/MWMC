#!/bin/bash
#SBATCH --job-name=NDSR
#SBATCH --output=logs/slurm/%x_%A_%a.txt
#SBATCH --time=02:00:00
#SBATCH --cpus-per-task=12
#SBATCH --mem=32G
#SBATCH --account=<your-account>
#SBATCH --array=0-89
#SBATCH --constraint=rome          # paper: AMD EPYC 7532 nodes of the Narval cluster
#
# Runs one configuration on the 90 NDSR instances (18 scenarios x 5 seeds).
# Usage (from the NDSR folder, after scripts/build.sh):
#   sbatch scripts/run.sh WITH        (with pre-generated lb-cuts)
#   sbatch scripts/run.sh WITHOUT     (path-based formulation only)
# The instance files Scenario<k>_S<seed>.txt are read from ./data (or from -Dndsr.data=<folder>);
# they are the benchmark instances of Balakrishnan et al. (2017) and are not distributed here.
set -euo pipefail
CONFIG="${1:?usage: sbatch scripts/run.sh WITH|WITHOUT}"
GUROBI_HOME="${GUROBI_HOME:-$EBROOTGUROBI}"
export LD_LIBRARY_PATH="$GUROBI_HOME/lib:${LD_LIBRARY_PATH:-}"

tid=${SLURM_ARRAY_TASK_ID}
SCENARIO=$(( tid / 5 + 1 ))
SEED=$(( tid % 5 + 1 ))
TAG="Scenario${SCENARIO}_S${SEED}"
OUTDIR="logs/${CONFIG}"
mkdir -p "$OUTDIR" logs/slurm
OUT="${OUTDIR}/out_${TAG}.txt"

echo "CONFIG=${CONFIG} TASK=${tid} TAG=${TAG} CPU=$(lscpu | grep 'Model name' | sed 's/.*: *//')"
java -Xmx8g -Dndsr.data=data -cp "bin:$GUROBI_HOME/lib/gurobi.jar:lib/*" -Djava.library.path="$GUROBI_HOME/lib" \
     ndsr.CMain "$SCENARIO" "$SEED" "$CONFIG" "${SLURM_CPUS_PER_TASK:-12}" > "$OUT" 2>&1
