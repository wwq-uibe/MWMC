#!/bin/bash
# Lists the task ids of CONFIG whose output has no GRB_STATS line (failed or not run yet).
# Usage (from the NDSR folder):  bash scripts/missing.sh WITH|WITHOUT
CONFIG="${1:?usage: bash scripts/missing.sh WITH|WITHOUT}"
ids=""
for tid in $(seq 0 89); do
  f="logs/${CONFIG}/out_Scenario$(( tid / 5 + 1 ))_S$(( tid % 5 + 1 )).txt"
  if [ ! -f "$f" ] || ! grep -q GRB_STATS "$f"; then ids="${ids:+$ids,}$tid"; fi
done
echo "${ids:-none}"
