#!/bin/bash
# Compile the NDSR code into bin/. Requires Java 17, the Gurobi 12.0 Java API (gurobi.jar),
# and the JGraphT jars (jgrapht-core and its dependencies) in ./lib.
set -euo pipefail
GUROBI_HOME="${GUROBI_HOME:-$EBROOTGUROBI}"
rm -rf bin && mkdir -p bin
javac -encoding UTF-8 -nowarn -cp "$GUROBI_HOME/lib/gurobi.jar:lib/*" -d bin src/ndsr/*.java
echo "Compiled $(ls bin/ndsr/*.class | wc -l) classes into bin/ndsr"
