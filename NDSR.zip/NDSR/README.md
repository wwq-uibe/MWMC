# NDSR: path-based formulation with pre-generated lb-cuts

Code of the NDSR experiments (Section 6.3) of the paper "Lexicographic Minimum-Weight Minimum-Cardinality Length-Bounded Cuts: Applications in Network Optimization".

## Contents

- `src/ndsr/`: Java code. The model is the path-based formulation of Gudapati et al. (2022), in which all service-feasible paths of each commodity are enumerated in advance.
- `scripts/`: `build.sh` (compile), `run.sh` (Slurm array job over the 90 instances), and `missing.sh` (lists unfinished tasks).

## Configurations

- `WITHOUT`: path-based formulation only.
- `WITH`: path-based formulation plus the pre-generated lb-cuts (S-CUT, T-CUT, and MIN-CUT on the transformed network G_k of each commodity), added to the initial formulation.

The two configurations differ only in these constraints.

## Requirements

- Java 17 or later
- Gurobi 12.0 with its Java API (`gurobi.jar`) and a valid license
- JGraphT (`jgrapht-core` and its dependencies), placed in `lib/`

## Instances (not included)

The 90 benchmark instances (18 scenarios × 5 seeds) are those of Balakrishnan et al. (2017), also used by Gudapati et al. (2022). They are not distributed here. The code reads `Scenario<k>_S<seed>.txt` (k = 1, …, 18; seed = 1, …, 5) from the folder given by `-Dndsr.data=<folder>` (default `data`). The numbers of nodes, arcs, and commodities of each scenario are set in `CODSet`.

## Running one instance

```
bash scripts/build.sh
java -Dndsr.data=data -cp "bin:$GUROBI_HOME/lib/gurobi.jar:lib/*" -Djava.library.path="$GUROBI_HOME/lib" \
     ndsr.CMain SCENARIO SEED WITH|WITHOUT [THREADS]
```

The output contains `PREP_STATS` (time to generate the lb-cuts and to enumerate the paths), `GRB_STATS` (status, objective value, bound, gap, nodes, iterations, runtime, work, numbers of pre-generated lb-cuts and of paths), and `LP_ORIG` (LP relaxation of the original, unpresolved model, solved after the MIP and not included in the reported times). The root relaxation, the root bound after Gurobi's cutting planes, and the numbers of solver-generated cuts by type are taken from the Gurobi log, which is written to the same output file.

The paper's runs used 12 threads, 32 GB of memory, AMD EPYC 7532 processors, Gurobi 12.0, a time limit of 3,600 s, and the default relative optimality tolerance of 10^-4. The instance-level results are in `supplementary_results.zip`.
