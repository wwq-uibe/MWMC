package weiquanmax;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Locale;

/**
 * [REV 2026-11] Configuration switches and statistics for the revision experiments.
 *
 * Configurations (5th command-line argument of CMain):
 *   BC1   : no pre-cuts, integer separation IntSep-M (canonical cut + cut-min), no fractional separation
 *           (= B&C-1 of Arslan et al. 2019, re-implemented in this code base)
 *   BC1E  : BC1 + eps-MIN compression before cut-min at integer solutions (no pre-cuts)
 *   ALG1  : pre-cuts + IntSep-M at integer solutions
 *   ALG2  : pre-cuts + eps-MIN compression + cut-min at integer solutions
 *   ALG2M : ALG2, but the integer cut is the EXACT MWMC cut (minimum-cardinality zero-weight lb-cut,
 *           CMIPLBMIN.RunExact, warm-started with the ALG2 cut); cut sizes of all variants are logged
 *   ALG3  : ALG2 + fractional separation (eps-MIN + cut-min)
 *   ALG4  : ALG3 + SPBA-t (t = SPBA_T) + quick-exit
 *   ALG2ST: ALG2 without the crossing-hop pre-cut (pre-cuts S-CUT and T-CUT only)   [patch 5]
 */
public class CRev {
    public static String CONFIG = "ALG4";
    public static boolean PRECUT = true;
    /** [patch 5] generate the crossing-hop (middle) pre-cut; false only in ALG2ST */
    public static boolean PRECUT_MIDDLE = true;
    public static boolean INT_EPSMIN = true;
    public static boolean INT_EXACT = false;
    public static boolean FRAC_EPSMIN = true;
    public static boolean FRAC_SPBA = true;
    public static boolean LOG_CUTSIZES = false;

    /** Time limit of SPBA-t in seconds (paper: SPBA-0.01). */
    public static double SPBA_T = 0.01;
    /** Time limit (s) of one exact MWMC separation MIP in ALG2M. */
    public static double EXACT_TL = 10.0;

    // ---------------- statistics ----------------
    public static double tNodeSet = 0, tPreCut = 0;          // preprocessing (s)
    public static double tIntSep = 0, tFracSep = 0;          // separation inside the callback (s)
    public static double tExact = 0, tLog = 0;               // parts of tIntSep: exact MIP, logging only
    public static long nIntCalls = 0, nIntCuts = 0, sumIntCard = 0;
    public static long nFracCuts = 0, sumFracCard = 0, nSpbaCuts = 0;
    public static long nExactOpt = 0, nExactTL = 0, nExactFail = 0;
    public static long nPreCuts = 0;

    public static PrintWriter cutLog = null;

    public static void set(String c) {
        CONFIG = c;
        PRECUT_MIDDLE = true;
        switch (c) {
            case "BC1":   PRECUT = false; INT_EPSMIN = false; INT_EXACT = false; FRAC_EPSMIN = false; FRAC_SPBA = false; LOG_CUTSIZES = false; break;
            case "BC1E":  PRECUT = false; INT_EPSMIN = true;  INT_EXACT = false; FRAC_EPSMIN = false; FRAC_SPBA = false; LOG_CUTSIZES = false; break;
            case "ALG1":  PRECUT = true;  INT_EPSMIN = false; INT_EXACT = false; FRAC_EPSMIN = false; FRAC_SPBA = false; LOG_CUTSIZES = false; break;
            case "ALG2":  PRECUT = true;  INT_EPSMIN = true;  INT_EXACT = false; FRAC_EPSMIN = false; FRAC_SPBA = false; LOG_CUTSIZES = false; break;
            case "ALG2M": PRECUT = true;  INT_EPSMIN = true;  INT_EXACT = true;  FRAC_EPSMIN = false; FRAC_SPBA = false; LOG_CUTSIZES = true;  break;
            case "ALG2ST": PRECUT = true; PRECUT_MIDDLE = false; INT_EPSMIN = true; INT_EXACT = false; FRAC_EPSMIN = false; FRAC_SPBA = false; LOG_CUTSIZES = false; break;
            case "ALG3":  PRECUT = true;  INT_EPSMIN = true;  INT_EXACT = false; FRAC_EPSMIN = true;  FRAC_SPBA = false; LOG_CUTSIZES = false; break;
            case "ALG4":  PRECUT = true;  INT_EPSMIN = true;  INT_EXACT = false; FRAC_EPSMIN = true;  FRAC_SPBA = true;  LOG_CUTSIZES = false; break;
            default: throw new IllegalArgumentException("Unknown configuration: " + c
                    + " (use BC1, BC1E, ALG1, ALG2, ALG2M, ALG2ST, ALG3, ALG4)");
        }
    }

    /** Pre-cut sets are only needed for the pre-cut constraints and for the eps-MIN trigger of ALG2-ALG4. */
    public static boolean needPreCutSets() {
        return PRECUT;
    }

    public static void openCutLog(String path) {
        try {
            cutLog = new PrintWriter(new FileWriter(path, false));
            cutLog.println("od,canonical,intsepm,heuristic,exact,exact_status,exact_time,used");
            cutLog.flush();
        } catch (Exception e) {
            System.err.println("Cannot open cut log " + path + ": " + e.getMessage());
            cutLog = null;
        }
    }

    public static void logCut(int od, int canonical, int intsepm, int heuristic, int exact,
                              int status, double exactTime, int used) {
        if (cutLog == null) return;
        cutLog.println(od + "," + canonical + "," + intsepm + "," + heuristic + "," + exact + ","
                + status + "," + String.format(Locale.US, "%.4f", exactTime) + "," + used);
    }

    public static void closeCutLog() {
        if (cutLog != null) { cutLog.flush(); cutLog.close(); cutLog = null; }
    }

    static String f(double x) { return String.format(Locale.US, "%.4f", x); }

    /** One tab-separated key=value line, easy to parse. */
    public static String summary() {
        StringBuilder sb = new StringBuilder("REV_SUMMARY");
        sb.append("\tconfig=").append(CONFIG)
          .append("\tspba_t=").append(SPBA_T)
          .append("\tt_nodeset=").append(f(tNodeSet))
          .append("\tt_precut=").append(f(tPreCut))
          .append("\tn_precuts=").append(nPreCuts)
          .append("\tt_intsep=").append(f(tIntSep))
          .append("\tt_exact=").append(f(tExact))
          .append("\tt_log=").append(f(tLog))
          .append("\tt_fracsep=").append(f(tFracSep))
          .append("\tn_int_calls=").append(nIntCalls)
          .append("\tn_int_cuts=").append(nIntCuts)
          .append("\tavg_int_card=").append(nIntCuts > 0 ? f((double) sumIntCard / nIntCuts) : "NA")
          .append("\tn_frac_cuts=").append(nFracCuts)
          .append("\tavg_frac_card=").append(nFracCuts > 0 ? f((double) sumFracCard / nFracCuts) : "NA")
          .append("\tn_spba_cuts=").append(nSpbaCuts)
          .append("\tn_exact_opt=").append(nExactOpt)
          .append("\tn_exact_tl=").append(nExactTL)
          .append("\tn_exact_fail=").append(nExactFail);
        return sb.toString();
    }
}
