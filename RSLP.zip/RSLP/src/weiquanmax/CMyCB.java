package weiquanmax;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBCallback;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBVar;

public class CMyCB extends GRBCallback{
	public static ArrayList<ArrayList<Integer>> Total_LBT_List=new ArrayList<> ();
	
//	public double rootRelaxObj = Double.NaN;
//    public static double rootRelaxationBound = Double.NaN;
    public static double rootBoundAfterCuts = Double.NaN;
    public static double firstRootNodeBound = Double.NaN;

    // 加完 root cuts 后的 root bound
    public double getRootBoundAfterCuts() {
        return rootBoundAfterCuts;
    }

    // 第一次 root MIPNODE bound，可选
    public double getFirstRootNodeBound() {
        return firstRootNodeBound;
    }
	
	double epsilon= 10e-4;

	private GRBVar[] x;
	private GRBVar[] y;
	
	private double[] value_x;
	private double[] value_y;
	
	double best_value=0;
	public static int cuts=0;
	public static int lba_cuts=0;
	double lastLpObj = Double.NaN;
    // 控制输出
	
	// [REV 2026-11] fractional separation rule: all OD pairs with ybar_k > Y_MIN; cut added if violation > VIOL_TOL
	static final double Y_MIN = 1e-6;
	static final double VIOL_TOL = 1e-6;

	public CMyCB (GRBVar[] x,GRBVar[] y) {
		this.x=x;
		this.y=y;
		System.out.println("FRAC_RULE\tall_ybar_positive\tY_MIN="+Y_MIN+"\tVIOL_TOL="+VIOL_TOL);
	}

	@Override
	protected void callback() {
	    try {
	        // 2. 读取 root node 阶段不断被 cuts 加强后的 bound
	        if (where == GRB.CB_MIPNODE) {
	            int status = getIntInfo(GRB.CB_MIPNODE_STATUS);

	            if (status == GRB.OPTIMAL) {
	                double nodeCnt = getDoubleInfo(GRB.CB_MIPNODE_NODCNT);
	                double bnd = getDoubleInfo(GRB.CB_MIPNODE_OBJBND);

	                // nodeCnt == 0 表示还在 root node 阶段
	                if (nodeCnt < 0.5) {
	                    if (Double.isNaN(firstRootNodeBound)) {
	                        firstRootNodeBound = bnd;
	                    }

	                    // 这里不断覆盖。
	                    // 最后一次 root node callback 留下来的值，
	                    // 就是 root cuts 之后的 root bound。
	                    rootBoundAfterCuts = bnd;
	                }
	            }
	        }

	        // 3. 原来的 integer separation
	        Integer();

	        // 4. 原来的 fractional separation
	        Fractional();

	    } catch (GRBException e) {
	        System.err.println("Callback error: code=" + e.getErrorCode()
	                + ", msg=" + e.getMessage());
	    }
	}
	
	public void Integer () {
		try {			
			if (where == GRB.CB_MIPSOL) {				
				long tStart=System.nanoTime();
				double objVal = getDoubleInfo(GRB.CB_MIPSOL_OBJ);			  
				
				value_x= getSolution(x);
				value_y= getSolution(y);
				
				ArrayList<Integer> opencs=new ArrayList<Integer>();
				for (int cs=0;cs<value_x.length;cs++) {
					if (value_x[cs]>0.5)
						opencs.add(cs);
				}
				
				ArrayList<Integer> openOD=new ArrayList<Integer>();
	            for (int i=0;i<CODSet.ODSet.size();i++) {
	            	if (value_y[i]>0.5)
	            		openOD.add(i);
	            }
	            
	            ArrayList<Integer> infeasible_OD=new ArrayList<Integer>();
	            for (int i=0;i<openOD.size();i++) {
	            	int od_pair=openOD.get(i);
	            	ArrayList<Integer> relate_cs= CGetLength.Filter (opencs, od_pair);
	            	boolean isfeasible=CGetLength.Run(relate_cs,od_pair);
	            	if (isfeasible==false) {
	            		infeasible_OD.add(od_pair);
	            		// [REV 2026-11] canonical cut = all closed candidate stations of this OD pair
	            		ArrayList<Integer> canonical=CFindPath.GetQNodes(CODSet.ODSet.get(od_pair).nodes_set,relate_cs);
	            		ArrayList<Integer> q_nodes=(ArrayList<Integer>) canonical.clone();
	            		ArrayList<Integer> rcs=(ArrayList<Integer>) relate_cs.clone();
	            		// eps-MIN compression (ALG2-ALG4, BC1E); BC1 and ALG1 use IntSep-M on the canonical cut only
	            		if (CRev.INT_EPSMIN && q_nodes.size()>CODSet.ODSet.get(od_pair).mincut_cardinality) {
	            			int O=CODSet.ODSet.get(od_pair).origin_node;
		            		int D=CODSet.ODSet.get(od_pair).destination_node;
		            		CMinCut.Run(O,D,CODSet.ODSet.get(od_pair).nodes_set,value_x);
		            		if (CMinCut.wt<=1e-9) {
		            			q_nodes=(ArrayList<java.lang.Integer>) CMinCut.mincut.clone();
		            			rcs=CGetLength.QuFan(q_nodes, od_pair);
		            		}
	            		}
	            		q_nodes=IntSep_M(q_nodes,rcs,od_pair);   // cut-min
	            		ArrayList<Integer> cut=q_nodes;
	            		int exactSize=-1, exactStatus=-1, used=0; double exactTime=0;
	            		// exact MWMC cut (ALG2M): minimum-cardinality zero-weight lb-cut, warm start = heuristic cut
	            		if (CRev.INT_EXACT) {
	            			long e0=System.nanoTime();
	            			CMIPLBMIN.RunExact(od_pair, value_x, CRev.EXACT_TL, 0.0, q_nodes);
	            			exactTime=(System.nanoTime()-e0)/1e9;
	            			CRev.tExact+=exactTime;
	            			exactStatus=CMIPLBMIN.status;
	            			if (CMIPLBMIN.cutFound && CMIPLBMIN.validCut && CMIPLBMIN.mincut.size()>0) {
	            				exactSize=CMIPLBMIN.mincut.size();
	            				if (CMIPLBMIN.optimal) CRev.nExactOpt++; else CRev.nExactTL++;
	            				if (exactSize<=q_nodes.size()) { cut=(ArrayList<Integer>) CMIPLBMIN.mincut.clone(); used=1; }
	            			} else {
	            				CRev.nExactFail++;
	            			}
	            		}
	            		// logging only (ALG2M): IntSep-M applied to the canonical cut, for a paired comparison
	            		if (CRev.LOG_CUTSIZES) {
	            			long l0=System.nanoTime();
	            			ArrayList<Integer> intsepm=IntSep_M((ArrayList<Integer>) canonical.clone(),(ArrayList<Integer>) relate_cs.clone(),od_pair);
	            			CRev.tLog+=(System.nanoTime()-l0)/1e9;
	            			CRev.logCut(od_pair, canonical.size(), intsepm.size(), q_nodes.size(), exactSize, exactStatus, exactTime, used);
	            		}
	            		//add cuts
	            		AddFeasibleCuts(cut,od_pair);
	            		CRev.nIntCuts++;
	            		CRev.sumIntCard+=cut.size();
	            	}
	            }
	            if (infeasible_OD.size()==0)
	            	best_value=objVal;		
	            cuts+=infeasible_OD.size();
	            CRev.nIntCalls++;
	            CRev.tIntSep+=(System.nanoTime()-tStart)/1e9;
			}
		} catch (GRBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void Fractional () {
		// [REV 2026-11] fractional separation only in ALG3/ALG4
		if (!CRev.FRAC_EPSMIN) return;
		try {
    		if (where == GRB.CB_MIPNODE) {
        	    int status = getIntInfo(GRB.CB_MIPNODE_STATUS);
        	    if (status == GRB.OPTIMAL) {
        	    	double lpObj = getDoubleInfo(GRB.CB_MIPNODE_OBJBND);   	
        	    	if (Double.isNaN(lastLpObj) || Math.abs(lpObj - lastLpObj) > epsilon) {
        	    		long tStart=System.nanoTime();
        	    		lastLpObj = lpObj;
        	    		
        	    		value_x= getNodeRel(x);
        				value_y= getNodeRel(y);
        				
        				boolean quick_exit=false;
        				
        				for (int od=0;od<value_y.length;od++) {
        					// [REV 2026-11] every OD pair with positive coverage is separated (no 0.4-0.6 window)
        					if (value_y[od]>Y_MIN) {
        						//epsilon min-cut
        						int O=CODSet.ODSet.get(od).origin_node;
        						int D=CODSet.ODSet.get(od).destination_node;
        						CMinCut.Run(O,D,CODSet.ODSet.get(od).nodes_set,value_x);
        						double total_weight=CMinCut.wt;
        						if (value_y[od]>total_weight+VIOL_TOL) {
        							ArrayList<Integer> q_nodes=(ArrayList<java.lang.Integer>) CMinCut.mincut.clone();
            						ArrayList<Integer> relate_cs=CGetLength.QuFan(q_nodes, od);
            						q_nodes=IntSep_M(q_nodes,relate_cs,od);
        							AddFeasibleCuts(q_nodes,od);
        							cuts++;
        							CRev.nFracCuts++; CRev.sumFracCard+=q_nodes.size();
        						}else if (CRev.FRAC_SPBA && quick_exit==false) {
        							CSPBA lbcutA = new CSPBA();
        						    lbcutA.Init();
        						    lbcutA.Run(od, value_x, CRev.SPBA_T);
        						    
        						    if (lbcutA.min_wt < Double.POSITIVE_INFINITY
        						            && value_y[od] > lbcutA.min_wt + VIOL_TOL
        						            && lbcutA.final_lb_cut_nodelist.size() > 0) {

        						        ArrayList<Integer> q_nodes =
        						                (ArrayList<Integer>) lbcutA.final_lb_cut_nodelist.clone();

        						        ArrayList<Integer> relate_cs = CGetLength.QuFan(q_nodes, od);
        						        q_nodes = IntSep_M(q_nodes, relate_cs, od);

        						        AddFeasibleCuts(q_nodes, od);
        						        cuts++;
        						        lba_cuts++;
        						        CRev.nFracCuts++; CRev.sumFracCard+=q_nodes.size(); CRev.nSpbaCuts++;
        						        quick_exit = true;
        						    }
        						}
        					}
        				}
        				CRev.tFracSep+=(System.nanoTime()-tStart)/1e9;
        	    	}
        	    
        	    }
        	}
    	}catch (GRBException e) {
            System.err.println("Callback error: code=" + e.getErrorCode() + ", msg=" + e.getMessage());
        }
	}
    
	public void AddFeasibleCuts(ArrayList<Integer> q_nodes,int od) throws GRBException {
		GRBLinExpr expr = new GRBLinExpr();
		
		expr.addTerm(1.0, y[od]);
		
		for (int i=0;i<q_nodes.size();i++) {
			int cs=q_nodes.get(i);
			expr.addTerm(-1.0, x[cs]);
		}
		//Add cuts
		addLazy(expr, GRB.LESS_EQUAL, 0);
	}
	
	public void AddUserCuts(ArrayList<Integer> q_nodes, int od) throws GRBException {
	    GRBLinExpr expr = new GRBLinExpr();

	    expr.addTerm(1.0, y[od]);

	    for (int i = 0; i < q_nodes.size(); i++) {
	        int cs = q_nodes.get(i);
	        expr.addTerm(-1.0, x[cs]);
	    }

	    addCut(expr, GRB.LESS_EQUAL, 0);
	}
	
	public ArrayList<Integer> IntSep_M (ArrayList<Integer> orgin_q_nodes,ArrayList<Integer> origin_opencs,int od){
    	ArrayList<Integer> opencs=(ArrayList<Integer>) origin_opencs.clone();
    	
    	for (int i=0;i<orgin_q_nodes.size();i++) {
    		int cs=orgin_q_nodes.get(i);
    		
    		opencs.add(cs);
    		if (CGetLength.Run(opencs,od)==true) {
    			int index=opencs.indexOf(cs);
    			opencs.remove(index);
    		}else {
    			int index=orgin_q_nodes.indexOf(cs);
        		orgin_q_nodes.remove(index);
        		i--;
    		}
    	}
    	
    	return orgin_q_nodes;
    }
}
