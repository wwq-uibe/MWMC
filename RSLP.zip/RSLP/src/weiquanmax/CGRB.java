package weiquanmax;

import java.util.ArrayList;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

public class CGRB {
	public static ArrayList<Integer> opencs=new ArrayList<Integer>();
	public static int NN;
	GRBEnv env;
	GRBModel model;	
	
	GRBVar[] x;
	GRBVar[] y;
	
	public static double cur_obj;
	
	public void Init() throws GRBException {
		// [REV 2026-11] no shared log file: the Gurobi log goes to stdout (one output file per job)
		int threads = Integer.parseInt(System.getenv().getOrDefault("SLURM_CPUS_PER_TASK", "1"));
		env = StartEnv(threads, true);
        
        model = new GRBModel(env);
        model.set(GRB.DoubleParam.TimeLimit, 3600.0);
        model.set(GRB.IntParam.LazyConstraints, 1);
	}
	
	/**
	 * [REV 2026-11] Starts a Gurobi environment. On the cluster, the license token server may refuse the
	 * request when the cluster-wide use limit is reached ("Request denied: use limit exceeded");
	 * the request is then retried every 60 s for up to 60 min instead of aborting the run.
	 */
	public static GRBEnv StartEnv(int threads, boolean output) throws GRBException {
		for (int attempt = 1; ; attempt++) {
			GRBEnv e = null;
			try {
				e = new GRBEnv(true);
				if (!output) e.set(GRB.IntParam.OutputFlag, 0);
				e.set(GRB.IntParam.Threads, threads);
				e.start();
				if (attempt > 1) System.out.println("GRB_ENV_STARTED after " + attempt + " attempts");
				return e;
			} catch (GRBException ex) {
				try { if (e != null) e.dispose(); } catch (Exception ignore) {}
				if (attempt >= 60) throw ex;
				System.out.println("GRB_ENV_RETRY " + attempt + ": " + ex.getMessage());
				try { Thread.sleep(60000L); } catch (InterruptedException ie) { throw ex; }
			}
		}
	}
	
	public void build_model(int alpha) throws GRBException {
		x=new GRBVar[NN];
	    y=new GRBVar[CODSet.ODSet.size()];
	  //variables
	    for (int i=0;i<NN;i++) {
	    	x[i]=model.addVar(0, 1,0, GRB.BINARY, "x" + i);
	    }
	    for (int od=0;od<CODSet.ODSet.size();od++){
	    	y[od]=model.addVar(0, 1,0, GRB.BINARY, "y" + od);
	    }
	    //building model
	    {
	    	GRBLinExpr cs_num = new GRBLinExpr();
	    	for (int i=0;i<x.length;i++) {
	    		cs_num.addTerm(1, x[i]);
	    	}
	    	model.addConstr(cs_num, GRB.EQUAL, alpha, null);
	    }
	    
	    // [REV 2026-11] pre-cuts (S-cut, T-cut, Min-Cut) only if the configuration uses them
	    if (CRev.PRECUT) {
	    //N_q Set Forward
	    for (int i=0;i<CODSet.ODSet.size();i++) {
	    	if (CODSet.ODSet.get(i).nodes_set_forward.size()==0)
	    		continue;	    	
	    	GRBLinExpr temp = new GRBLinExpr();
	    	for (int j=0;j<CODSet.ODSet.get(i).nodes_set_forward.size();j++) {
	    		int candi_node=CODSet.ODSet.get(i).nodes_set_forward.get(j);
	    		temp.addTerm(1.0, x[candi_node]);
	    	}
	    	model.addConstr(y[i], GRB.LESS_EQUAL, temp, null);
	    	CRev.nPreCuts++;
	    }
	    
	    //N_q_Set_Backward
	    for (int i=0;i<CODSet.ODSet.size();i++) {
	    	if (CODSet.ODSet.get(i).nodes_set_backward.size()==0)
	    		continue;	    	
	    	GRBLinExpr temp = new GRBLinExpr();
	    	for (int j=0;j<CODSet.ODSet.get(i).nodes_set_backward.size();j++) {
	    		int candi_node=CODSet.ODSet.get(i).nodes_set_backward.get(j);
	    		temp.addTerm(1.0, x[candi_node]);
	    	}
	    	model.addConstr(y[i], GRB.LESS_EQUAL, temp, null);
	    	CRev.nPreCuts++;
	    }
	    
	    //N_q_Set_Middle
	    for (int i=0;i<CODSet.ODSet.size();i++) {
	    	if (CODSet.ODSet.get(i).nodes_set_middle.size()==0)
	    		continue;	    	
	    	GRBLinExpr temp = new GRBLinExpr();
	    	for (int j=0;j<CODSet.ODSet.get(i).nodes_set_middle.size();j++) {
	    		int candi_node=CODSet.ODSet.get(i).nodes_set_middle.get(j);
	    		temp.addTerm(1.0, x[candi_node]);
	    	}
	    	model.addConstr(y[i], GRB.LESS_EQUAL, temp, null);
	    	CRev.nPreCuts++;
	    }
	    }
	    //maximize OBJ	    
	    GRBLinExpr obj = new GRBLinExpr();
		for (int od = 0; od < CODSet.ODSet.size(); od++) {
		    obj.addTerm(CODSet.ODSet.get(od).flow, y[od]);
		}
		model.setObjective(obj, GRB.MAXIMIZE);
		//test
		//25, 303, 306, 348, 396
		//		model.addConstr(x[322], GRB.EQUAL, 1, null);
	}
	
	public void solve() throws GRBException {	
		CMyCB.cuts=0;
		CMyCB cb=new CMyCB(x,y);
		model.setCallback(cb);
		
		model.optimize();
		int status = model.get(GRB.IntAttr.Status);
		// [REV 2026-11] solver statistics in one parseable line
		try {
			double work = Double.NaN;
			try { work = model.get(GRB.DoubleAttr.Work); } catch (Exception ignore) {}
			double objv = model.get(GRB.IntAttr.SolCount) > 0 ? model.get(GRB.DoubleAttr.ObjVal) : Double.NaN;
			System.out.println("GRB_STATS\tstatus=" + status
					+ "\tobj=" + objv
					+ "\tbound=" + model.get(GRB.DoubleAttr.ObjBound)
					+ "\tgap=" + (model.get(GRB.IntAttr.SolCount) > 0 ? model.get(GRB.DoubleAttr.MIPGap) : Double.NaN)
					+ "\tnodes=" + model.get(GRB.DoubleAttr.NodeCount)
					+ "\titer=" + model.get(GRB.DoubleAttr.IterCount)
					+ "\truntime=" + model.get(GRB.DoubleAttr.Runtime)
					+ "\twork=" + work
					+ "\troot_bound_after_cuts=" + CMyCB.rootBoundAfterCuts);
		} catch (GRBException e) { System.err.println("GRB_STATS error: " + e.getMessage()); }
        if (status == GRB.Status.INFEASIBLE) {
        	cur_obj=-1;
        	return;
        }
		if (status == GRB.Status.OPTIMAL || status == GRB.Status.SUBOPTIMAL) {
        	
        }else {
        	opencs.clear();
        	cur_obj=-1;
        	return;
        }
		opencs.clear();
		
		
		for (int cs=0;cs<NN;cs++) {
			if (x[cs].get(GRB.DoubleAttr.X)>0.5) {
				opencs.add(cs);
			}
		}

		if (model.get(GRB.DoubleAttr.MIPGap)*100<=0.1)
			cur_obj=model.get(GRB.DoubleAttr.ObjVal);
		else
			cur_obj=(1+model.get(GRB.DoubleAttr.MIPGap))*model.get(GRB.DoubleAttr.ObjVal);
		
		System.out.println(cur_obj+"\t"+model.get(GRB.DoubleAttr.Runtime)+"\t"+opencs);
		
		double root_node_gap = 100.0 * (CMyCB.rootBoundAfterCuts - cur_obj) / cur_obj;
		System.out.printf("Root node gap:\t%.2f%%%n", root_node_gap);

		System.out.println("Number of cuts:\t"+CMyCB.cuts+"\t"+CMyCB.lba_cuts);
	}
	
	public void end () throws GRBException {
		model.dispose();
        env.dispose();
	}
}
