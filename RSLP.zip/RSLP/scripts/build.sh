#!/bin/bash
# Compile the RSLP code into bin/. Requires Java 17 and the Gurobi 12.0 Java API (gurobi.jar).
# On a cluster with environment modules, e.g.:  module load java/17 gurobi/12.0.0
set -euo pipefail
GUROBI_HOME="${GUROBI_HOME:-$EBROOTGUROBI}"
rm -rf bin && mkdir -p bin
javac -encoding UTF-8 -nowarn -cp "$GUROBI_HOME/lib/gurobi.jar" -d bin src/weiquanmax/*.java
echo "Compiled $(ls bin/weiquanmax | wc -l) class files into bin/weiquanmax"
