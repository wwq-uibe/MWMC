#!/bin/bash
# Lists the task ids of CONFIG whose output has no REV_SUMMARY line (failed or not run yet).
# Usage (from the RSLP folder):  bash scripts/missing.sh CONFIG
CONFIG="${1:?usage: bash scripts/missing.sh CONFIG}"
NETS=(BE CA QC US); TOLS=(0.0 0.1 0.25 0.5); ids=""
for tid in $(seq 0 239); do
  iN=$(( tid / 60 )); iR=$(( (tid / 20) % 3 )); iT=$(( (tid / 5) % 4 )); iP=$(( tid % 5 ))
  f="logs/${CONFIG}/out_${NETS[$iN]}_r$((iR+1))_tol${TOLS[$iT]}_p$((iP+1)).txt"
  if [ ! -f "$f" ] || ! grep -q REV_SUMMARY "$f"; then ids="${ids:+$ids,}$tid"; fi
done
echo "${ids:-none}"
