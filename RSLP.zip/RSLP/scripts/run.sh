#!/bin/bash
#SBATCH --job-name=RSLP
#SBATCH --output=logs/slurm/%x_%A_%a.txt
#SBATCH --time=02:30:00
#SBATCH --cpus-per-task=12
#SBATCH --mem=32G
#SBATCH --account=<your-account>
#SBATCH --array=0-239
#SBATCH --constraint=rome          # paper: AMD EPYC 7532 nodes of the Narval cluster
#
# Runs one configuration on the 240 RSLP instances (4 networks x 3 ranges x 4 deviation levels x 5 budgets).
# Usage (from the RSLP folder, after scripts/build.sh):
#   sbatch scripts/run.sh CONFIG     CONFIG in {BC1, BC1E, ALG1, ALG2, ALG2ST, ALG2M, ALG3, ALG4}
#   sbatch --array=5,17 scripts/run.sh CONFIG     (re-run selected tasks)
# The network data are read from ./data (or from -Drslp.data=<folder>); they are not distributed here.
set -euo pipefail
CONFIG="${1:?usage: sbatch scripts/run.sh CONFIG}"
GUROBI_HOME="${GUROBI_HOME:-$EBROOTGUROBI}"
export LD_LIBRARY_PATH="$GUROBI_HOME/lib:${LD_LIBRARY_PATH:-}"

NETWORK_SET=(1 2 3 4)          # 1-BE581; 2-CA339; 3-QC405; 4-US420
NETWORK_NAME_SET=(BE CA QC US)
R_TYPE_SET=(1 2 3)
TOL_SET=(0.0 0.1 0.25 0.5)
P_TYPE_SET=(1 2 3 4 5)
NR=${#R_TYPE_SET[@]}; NT=${#TOL_SET[@]}; NP=${#P_TYPE_SET[@]}
tid=${SLURM_ARRAY_TASK_ID}
iN=$(( tid / (NR * NT * NP) )); iR=$(( (tid / (NT * NP)) % NR )); iT=$(( (tid / NP) % NT )); iP=$(( tid % NP ))
NETWORK="${NETWORK_SET[$iN]}"; NETWORK_NAME="${NETWORK_NAME_SET[$iN]}"
R_TYPE="${R_TYPE_SET[$iR]}"; TOL="${TOL_SET[$iT]}"; P_TYPE="${P_TYPE_SET[$iP]}"
TAG="${NETWORK_NAME}_r${R_TYPE}_tol${TOL}_p${P_TYPE}"

OUTDIR="logs/${CONFIG}"
mkdir -p "$OUTDIR" logs/slurm
OUT="${OUTDIR}/out_${TAG}.txt"
EXTRA=""
if [ "$CONFIG" = "ALG2M" ]; then EXTRA="${OUTDIR}/cutsizes_${TAG}.csv"; fi

echo "CONFIG=${CONFIG} TASK=${tid} TAG=${TAG} CPU=$(lscpu | grep 'Model name' | sed 's/.*: *//')"
java -Xmx8g -Drslp.data=data -cp "bin:$GUROBI_HOME/lib/gurobi.jar" -Djava.library.path="$GUROBI_HOME/lib" \
     weiquanmax.CMain "$NETWORK" "$R_TYPE" "$TOL" "$P_TYPE" "$CONFIG" $EXTRA > "$OUT" 2>&1
