# RSLP: branch-and-cut with pre-generated lb-cuts

Code of the RSLP experiments (Section 6.2) of the paper "Lexicographic Minimum-Weight Minimum-Cardinality Length-Bounded Cuts: Applications in Network Optimization".

## Contents

- `src/weiquanmax/`: Java code. The formulation is that of Arslan et al. (2019). All configurations share the same code base and differ only in the components switched in `CRev`.
- `scripts/`: `build.sh` (compile), `run.sh` (Slurm array job over the 240 instances), and `missing.sh` (lists unfinished tasks).

## Configurations (Table 9 of the paper)

| Name | Pre-generated lb-cuts | Integer solutions | Fractional solutions |
|---|---|---|---|
| `BC1` | none | canonical cut + cut-min (B&C-1 of Arslan et al. 2019) | none |
| `BC1E` | none | ε-MIN compression + cut-min | none |
| `ALG1` | S-CUT, T-CUT, HOP-CUT | canonical cut + cut-min | none |
| `ALG2` | S-CUT, T-CUT, HOP-CUT | ε-MIN compression + cut-min | none |
| `ALG2ST` | S-CUT, T-CUT | ε-MIN compression + cut-min | none |
| `ALG2M` | S-CUT, T-CUT, HOP-CUT | exact MWMC cut (MIP, 10 s per call, warm-started with the ALG2 cut) | none |
| `ALG3` | S-CUT, T-CUT, HOP-CUT | ε-MIN compression + cut-min | ε-MIN + cut-min |
| `ALG4` | S-CUT, T-CUT, HOP-CUT | ε-MIN compression + cut-min | ε-MIN + cut-min, SPBA-0.01, quick-exit |

## Requirements

- Java 17 or later
- Gurobi 12.0 with its Java API (`gurobi.jar`) and a valid license

## Network data (not included)

The four networks are taken from the literature and are not distributed here: BE581 (Mahmutoğulları and Yaman 2023), CA339 (Arslan et al. 2019), QC405 (Hydro-Québec), and US420 (Kınay et al. 2023). The code reads two files per network from the folder given by `-Drslp.data=<folder>` (default `data`), with `<NET>` in {`BE`, `CA`, `QC`, `US`}:

- `<NET>_ODs.txt`: one OD pair per line, `origin,destination,flow` (the flows are normalized by the code).
- `<NET>_ShortestLength.txt`: one node pair per line, `i,j,d`, where `d` is the shortest-path distance (km) from node i to node j in the road network.

Nodes are numbered from 0.

## Running one instance

```
bash scripts/build.sh
java -Drslp.data=data -cp "bin:$GUROBI_HOME/lib/gurobi.jar" -Djava.library.path="$GUROBI_HOME/lib" \
     weiquanmax.CMain NETWORK R_TYPE TAU P_TYPE CONFIG [cutsizes.csv]
```

- `NETWORK`: 1 = BE581, 2 = CA339, 3 = QC405, 4 = US420.
- `R_TYPE` (1, 2, 3): vehicle range R; BE581 {200, 250, 300}, CA339 {100, 150, 200}, QC405 {200, 300, 400}, US420 {300, 400, 500} km.
- `TAU`: deviation level τ in {0.0, 0.1, 0.25, 0.5}.
- `P_TYPE` (1–5): station budget p = 5 × P_TYPE for CA339 and 10 × P_TYPE for the other networks.
- `CONFIG`: one of the configurations above.
- `cutsizes.csv` (optional, used with `ALG2M`): records, at every separation at an integer solution, the cardinalities of the canonical cut, the cut-min cut, the ALG2 cut, and the exact MWMC cut. These extra cut computations are timed separately and excluded from the reported times.

The output ends with two summary lines: `GRB_STATS` (status, objective value, bound, gap, nodes, iterations, runtime, work, root bound after cuts) and `REV_SUMMARY` (preprocessing and separation times, numbers and average cardinalities of the cuts).

The paper's runs used 12 threads, 32 GB of memory, AMD EPYC 7532 processors, Gurobi 12.0, a time limit of 3,600 s, and the default relative optimality tolerance of 10^-4. The instance-level results are in `supplementary_results.zip`.
