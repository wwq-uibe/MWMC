package ndsr;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

public class ClbcutA2 {
    private static final double DEFAULT_TIME_LIMIT_SEC = 0.01;
    private static final double EPS = 1.0e-12;

    /**
     * If true, the algorithm returns as soon as it finds a violated lb-cut with weight < 1.
     * If you really want the minimum-weight lb-cut, keep this false.
     */
    private static final boolean STOP_WHEN_WEIGHT_BELOW_ONE = false;

    public ArrayList<Integer> zero_weight_arclist = new ArrayList<Integer>();

    public double min_wt = Double.POSITIVE_INFINITY;
    public ArrayList<Integer> final_lb_cut_arclist = new ArrayList<Integer>();

    /** true only if the branch-and-bound tree is completely exhausted. */
    public boolean solvedToOptimality = false;

    /** true if the method stops because the time limit is reached. */
    public boolean timeLimitReached = false;

    public void Init() {
        zero_weight_arclist.clear();
        min_wt = Double.POSITIVE_INFINITY;
        final_lb_cut_arclist.clear();
        solvedToOptimality = false;
        timeLimitReached = false;
    }

    /**
     * Default run: 0.01 second time limit.
     */
    public void Run(ArrayList<Integer> arcsetindex, double[] value_z,
                    int s, int t, double maxW1, double maxW2) {
        Run(arcsetindex, value_z, s, t, maxW1, maxW2, DEFAULT_TIME_LIMIT_SEC);
    }

    /**
     * Branch-and-bound for the min-weight length-bounded cut.
     *
     * Note: this time limit is checked before/after calls to ConstrainedShortestPath.findPath.
     * If a single findPath call itself takes longer than the limit, ClbcutA cannot interrupt it
     * unless findPath also supports a deadline/time limit internally.
     */
    public void Run(ArrayList<Integer> arcsetindex, double[] value_z,
                    int s, int t, double maxW1, double maxW2,
                    double timeLimitSec) {
        Init();

        long timeBudgetNanos = Math.max(1L, (long) (timeLimitSec * 1_000_000_000L));
        long deadlineNanos = System.nanoTime() + timeBudgetNanos;

        ArrayList<Integer> initialOpenArcs = RemoveZeroWeightArc(arcsetindex, value_z);
        if (isTimeUp(deadlineNanos)) {
            timeLimitReached = true;
            return;
        }

        ArrayList<Integer> initialPath = ConstrainedShortestPath.findPath(initialOpenArcs, s, t, maxW1, maxW2);
        double initialLength = ConstrainedShortestPath.bestLength;

        if (isNoPath(initialPath)) {
            min_wt = 0.0;
            final_lb_cut_arclist.clear();
            solvedToOptimality = true;
            return;
        }

        PriorityQueue<Clbcut> queue = new PriorityQueue<Clbcut>(
                Comparator.comparingDouble(node -> node.weight)
        );

        queue.add(makeNode(new ArrayList<Integer>(), 0.0, initialLength,
                initialPath, initialOpenArcs));

        while (!queue.isEmpty()) {
            if (isTimeUp(deadlineNanos)) {
                timeLimitReached = true;
                return;
            }

            Clbcut current = queue.poll();

            // Bound: any descendant of current has weight at least current.weight.
            if (current.weight >= min_wt - EPS) {
                continue;
            }

            for (int j = 0; j < current.shortpatharclist.size(); j++) {
                if (isTimeUp(deadlineNanos)) {
                    timeLimitReached = true;
                    return;
                }

                int arcIndex = current.shortpatharclist.get(j);
                double childWeight = current.weight + value_z[arcIndex];

                // Important pruning before the expensive CSP call.
                if (childWeight >= min_wt - EPS) {
                    continue;
                }

                ArrayList<Integer> childOpenArcs = GetNewArcSetRemove(current.openarcsetindex, arcIndex);
                ArrayList<Integer> childPath = ConstrainedShortestPath.findPath(childOpenArcs, s, t, maxW1, maxW2);
                double childLength = ConstrainedShortestPath.bestLength;

                ArrayList<Integer> childCut = new ArrayList<Integer>(current.lbcut);
                childCut.add(arcIndex);

                if (isNoPath(childPath)) {
                    if (childWeight < min_wt - EPS) {
                        min_wt = childWeight;
                        final_lb_cut_arclist = childCut;

                        if (STOP_WHEN_WEIGHT_BELOW_ONE && min_wt < 1.0 - EPS) {
                            return;
                        }
                    }
                } else {
                    queue.add(makeNode(childCut, childWeight, childLength,
                            childPath, childOpenArcs));
                }
            }
        }

        solvedToOptimality = true;
    }

    private boolean isTimeUp(long deadlineNanos) {
        return System.nanoTime() >= deadlineNanos;
    }

    private boolean isNoPath(ArrayList<Integer> path) {
        return path == null || path.isEmpty();
    }

    private Clbcut makeNode(ArrayList<Integer> lbcut, double weight, double length,
                           ArrayList<Integer> shortpatharclist,
                           ArrayList<Integer> openarcsetindex) {
        Clbcut node = new Clbcut();
        node.lbcut = new ArrayList<Integer>(lbcut);
        node.weight = weight;
        node.length = length;
        node.shortpatharclist = new ArrayList<Integer>(shortpatharclist);
        node.openarcsetindex = new ArrayList<Integer>(openarcsetindex);
        return node;
    }

    public double GetWeight(ArrayList<Integer> arclist, double[] value_z) {
        double wt = 0.0;
        for (int i = 0; i < arclist.size(); i++) {
            wt += value_z[arclist.get(i)];
        }
        return wt;
    }

    public ArrayList<Integer> GetNewArcSetRemove(ArrayList<Integer> arcsetindex, int index) {
        ArrayList<Integer> temp = new ArrayList<Integer>(arcsetindex);
        int pos = temp.indexOf(index);
        if (pos >= 0) {
            temp.remove(pos);
        }
        return temp;
    }

    public ArrayList<Integer> RemoveZeroWeightArc(ArrayList<Integer> arcsetindex, double[] value_z) {
        ArrayList<Integer> positiveWeightArcs = new ArrayList<Integer>();
        zero_weight_arclist.clear();

        for (int i = 0; i < arcsetindex.size(); i++) {
            int index = arcsetindex.get(i);
            if (value_z[index] <= EPS) {
                zero_weight_arclist.add(index);
            } else {
                positiveWeightArcs.add(index);
            }
        }
        return positiveWeightArcs;
    }
}
