package ndsr;

import java.util.ArrayList;

public class Clbcut {
	public ArrayList<Integer> lbcut=new ArrayList<Integer> ();
	public double weight;
	public double length;
	public ArrayList<Integer> shortpatharclist=new ArrayList<Integer>();
	public ArrayList<Integer> openarcsetindex=new ArrayList<Integer>();
}
