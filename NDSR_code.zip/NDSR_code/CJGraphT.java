package ndsr;

import java.util.ArrayList;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

public class CJGraphT {
	
	public static void InitOpenArcsW1 (ArrayList<CArc> OpenArcSetW1) {
		Graph<Integer, DefaultWeightedEdge> g =
	            new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);

	    for (CArc arc : OpenArcSetW1) {

	        int u = arc.real_left;
	        int v = arc.real_right;

	        if (!g.containsVertex(u)) g.addVertex(u);
	        if (!g.containsVertex(v)) g.addVertex(v);

	        DefaultWeightedEdge e = g.addEdge(u, v);

	        if (e != null) {
	            double w = arc.w1;
	            g.setEdgeWeight(e, w);
	        }
	    }
	    
	    DijkstraShortestPath<Integer, DefaultWeightedEdge> dijkstra =
	            new DijkstraShortestPath<>(g);
	    
	    for (int od=0;od<CODSet.ODSet.size();od++) {
	    	int s=CODSet.ODSet.get(od).origin_node;
	    	int t=CODSet.ODSet.get(od).destination_node;
	    	GraphPath<Integer, DefaultWeightedEdge> path =
    	            dijkstra.getPath(s, t);
	    	System.out.println(od+"\t"+path.getWeight()+"\t"+CODSet.ODSet.get(od).W_Limit_1);
	    }
	}

	public static void InitOpenArcsW2 (ArrayList<CArc> OpenArcSetW1) {
		Graph<Integer, DefaultWeightedEdge> g =
	            new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);

	    for (CArc arc : OpenArcSetW1) {

	        int u = arc.real_left;
	        int v = arc.real_right;

	        if (!g.containsVertex(u)) g.addVertex(u);
	        if (!g.containsVertex(v)) g.addVertex(v);

	        DefaultWeightedEdge e = g.addEdge(u, v);

	        if (e != null) {
	            double w = arc.w2;
	            g.setEdgeWeight(e, w);
	        }
	    }
	    
	    DijkstraShortestPath<Integer, DefaultWeightedEdge> dijkstra =
	            new DijkstraShortestPath<>(g);
	    
	    for (int od=0;od<CODSet.ODSet.size();od++) {
	    	int s=CODSet.ODSet.get(od).origin_node;
	    	int t=CODSet.ODSet.get(od).destination_node;
	    	GraphPath<Integer, DefaultWeightedEdge> path =
    	            dijkstra.getPath(s, t);
	    	System.out.println(od+"\t"+path.getWeight()+"\t"+CODSet.ODSet.get(od).W_Limit_2);
	    }
	}
}
