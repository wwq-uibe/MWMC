package ndsr;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class CMain {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		{			
			int Scenario=Integer.parseInt(args[0]);
			int Seed=Integer.parseInt(args[1]);
			
			int Node_N=CODSet.GetScenarioNode(Scenario); 
			int Arc_N=CODSet.GetScenarioArc(Scenario); 
			int OD_N=CODSet.GetScenarioOD(Scenario); 

			String file="/home/wwq/projects/def-adulyasa/wwq/Balakrishnan/Scenario"+Scenario
			+"_S"+Seed+".txt";
			
			CODSet.Init(file,OD_N);
			
			CGRB grb=new CGRB ();
			grb.Init();
			grb.build_model(Node_N);
			grb.solve();
			grb.end();
			
			System.out.println("N"+Node_N+"A"+Arc_N+"C"+OD_N+"_"+CODSet.SEED+"\t"+grb.objVal+"\t"+grb.runtime+"\t"
					+grb.gap+"\t"+CMyCB.Cuts+"\t"+CMyCB.lba_cuts);
		}
	}
}
