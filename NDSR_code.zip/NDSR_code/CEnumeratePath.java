package ndsr;

import java.util.ArrayList;

public class CEnumeratePath {

	public static void Run () {
		for (int od=0;od<CODSet.ODSet.size();od++) {
			int s=CODSet.ODSet.get(od).origin_node;
	    	int t=CODSet.ODSet.get(od).destination_node;
			double WL1=CODSet.ODSet.get(od).W_Limit_1;
			double WL2=CODSet.ODSet.get(od).W_Limit_2;
			
			Generate(od, s,t,CODSet.ODSet.get(od).lb_arclist_W,WL1,WL2);
		}
	}
	
	public static void Generate (int od, int s, int t, ArrayList<Integer> arclist,double WL1,double WL2) {
		ArrayList<Integer> nodeset=GetNodeList(arclist);
		ArrayList<ArrayList<Integer>> leftnode_relate_arcindex=Get_leftnode_relate_arcindex(arclist);
		
		CLabel lb=new CLabel();
		lb.path.add(s);
		
		ArrayList<CLabel> LABLE=new ArrayList<CLabel> ();
		LABLE.add(lb);
		
		ArrayList<CLabel> LABLE_OUTPUT=new ArrayList<CLabel> ();
		while (true) {
			if (LABLE.size()==0)
				break;
			ArrayList<CLabel> generate_Lablelist=new ArrayList<CLabel>();
			for (int l=0;l<LABLE.size();l++) {				
				int size=LABLE.get(l).path.size();
				int last_node=LABLE.get(l).path.get(size-1);
				
				for (int i=0;i<leftnode_relate_arcindex.get(last_node).size();i++) {
					CLabel temp_label=CopyLabel(LABLE.get(l));
					
					int a=leftnode_relate_arcindex.get(last_node).get(i);
					int next_node=CODSet.ArcSet.get(a).real_right;
					
					if (temp_label.w1+CODSet.ArcSet.get(a).w1+CODSet.W1[next_node][t]>WL1)
						continue;
					if (temp_label.w2+CODSet.ArcSet.get(a).w2+CODSet.W2[next_node][t]>WL2)
						continue;
					if (temp_label.path.indexOf(next_node)>=0)
						continue;
//					if (temp_label.arc_visit_sequence.indexOf(a)>=0)
//						continue;
					
					if (temp_label.w1+CODSet.ArcSet.get(a).w1<=WL1+0.01&temp_label.w2+CODSet.ArcSet.get(a).w2<=WL2+0.01) {						
						temp_label.path.add(next_node);
						temp_label.arc_visit_sequence.add(a);
						temp_label.w1+=CODSet.ArcSet.get(a).w1;
						temp_label.w2+=CODSet.ArcSet.get(a).w2;
						temp_label.cost+=CODSet.ArcSet.get(a).variableCost;
						
						if (next_node==t) {
							LABLE_OUTPUT.add(temp_label);
						}else {
							generate_Lablelist.add(temp_label);
						}
					}
				}
			}
			LABLE=(ArrayList<CLabel>) generate_Lablelist.clone();
		}
		
		CODSet.ODSet.get(od).LABELLIST=(ArrayList<CLabel>) LABLE_OUTPUT.clone();
//		for (int i=0;i<LABLE_OUTPUT.size();i++) {
//			CODSet.ODSet.get(od).arc_visit_index.add(LABLE_OUTPUT.get(i).arc_visit_sequence);
//			CODSet.ODSet.get(od).path_visit_index.add(LABLE_OUTPUT.get(i).path);
//		}
	}
	
	public static ArrayList<Integer> GetNodeList (ArrayList<Integer> arclist) {
		ArrayList<Integer> temp = new ArrayList<Integer> ();
		
		for (int i=0;i<arclist.size();i++) {
			int a=arclist.get(i);
			int left=CODSet.ArcSet.get(a).real_left;
			int right=CODSet.ArcSet.get(a).real_right;
			if (temp.indexOf(left)<0) {
				temp.add(left);
			}
			if (temp.indexOf(right)<0) {
				temp.add(right);
			}
		}
		
		return temp;
	}
	
	public static ArrayList<ArrayList<Integer>> Get_leftnode_relate_arcindex (ArrayList<Integer> arclist) {
		ArrayList<ArrayList<Integer>> leftnode_relate_arcindex=new ArrayList<> ();
		for (int i=0;i<CODSet.Max_Node_Index+1;i++) {
			ArrayList<Integer> empty=new ArrayList<Integer> ();
			leftnode_relate_arcindex.add(empty);
		}
		
		for (int i=0;i<arclist.size();i++) {
			int a=arclist.get(i);
			int left=CODSet.ArcSet.get(a).real_left;
			leftnode_relate_arcindex.get(left).add(a);
		}
		
		return leftnode_relate_arcindex;
	}
	
	public static CLabel CopyLabel (CLabel label) {
		CLabel temp=new CLabel ();
		temp.w1=label.w1;
		temp.w2=label.w2;
		temp.path=(ArrayList<Integer>) label.path.clone();
		temp.arc_visit_sequence=(ArrayList<Integer>) label.arc_visit_sequence.clone();
		temp.cost=label.cost;		
		return temp;
	}
}
