package ndsr;

import java.util.ArrayList;

public class CODPair {

	public int origin_node;
	public int destination_node;
	public double flow;
	public int W_Limit_1;
	public int W_Limit_2;
	
	public ArrayList<Integer> lb_arclist_W=new ArrayList<>();	
	
	public ArrayList<Integer> forwardcut=new ArrayList<>();	
	public ArrayList<Integer> backwardcut=new ArrayList<>();	
	public ArrayList<Integer> mincut=new ArrayList<>();	
	
	public ArrayList<CLabel> LABELLIST=new ArrayList<> ();
//	public ArrayList<ArrayList<Integer>> arc_visit_index=new ArrayList<> ();
//	public ArrayList<ArrayList<Integer>> path_visit_index=new ArrayList<> ();
}
