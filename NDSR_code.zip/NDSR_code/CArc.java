package ndsr;

public class CArc {

	public int real_left=-1;
	public int real_right=-1;
	public float fix_cost=-1;
	public float variableCost=-1;
	public float w1=-1;
	public float w2=-1;
	double weight;
	public int var=-1;
}
