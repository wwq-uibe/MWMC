package ndsr;

import org.jgrapht.Graph;
import org.jgrapht.alg.shortestpath.MartinShortestPath;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;
import org.jgrapht.GraphPath;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

public class ConstrainedShortestPath {
	
	public static double bestLength;

    public static ArrayList<Integer> findPath(ArrayList<Integer> arcSet_Index, int source, int target, double maxW1, double maxW2) {
        // 1. 创建有向图
        Graph<Integer, DefaultWeightedEdge> graph = new SimpleDirectedWeightedGraph<>(DefaultWeightedEdge.class);
        HashMap<DefaultWeightedEdge, CArc> edgeToArc = new HashMap<>();
        
        // 2. 添加顶点和边
        for (int k=0;k<arcSet_Index.size();k++) {
        	int a=arcSet_Index.get(k);
            graph.addVertex(CODSet.ArcSet.get(a).real_left);
            graph.addVertex(CODSet.ArcSet.get(a).real_right);
            DefaultWeightedEdge edge = graph.addEdge(CODSet.ArcSet.get(a).real_left, CODSet.ArcSet.get(a).real_right);
            if (edge != null) {
                graph.setEdgeWeight(edge, CODSet.ArcSet.get(a).variableCost);
                edgeToArc.put(edge, CODSet.ArcSet.get(a));
            }
        }
        
        if (!graph.containsVertex(source)) {
            bestLength = Double.POSITIVE_INFINITY;
            return new ArrayList<>();  // 返回空列表
        }
        
        if (!graph.containsVertex(target)) {
            bestLength = Double.POSITIVE_INFINITY;
            return new ArrayList<>();  // 返回空列表
        }

        // 3. 显式指定泛型类型 - 修复的关键
        MartinShortestPath<Integer, DefaultWeightedEdge> multiObjectiveShortestPath = 
            new MartinShortestPath<>(graph, (edge) -> {
                CArc arc = edgeToArc.get(edge);
                // 返回三维权重: [length, w1, w2]
                return new double[]{arc.variableCost, arc.w1, arc.w2};
            });
        
        // 4. 获取帕累托最优路径
        List<GraphPath<Integer, DefaultWeightedEdge>> paretoPaths = 
            multiObjectiveShortestPath.getPaths(source, target);
        
        // 5. 筛选满足约束条件且长度最短的路径
        GraphPath<Integer, DefaultWeightedEdge> bestPath = null;
        bestLength = Double.POSITIVE_INFINITY;
        
        if (paretoPaths != null) {
            for (GraphPath<Integer, DefaultWeightedEdge> path : paretoPaths) {
                double totalW1 = 0.0;
                double totalW2 = 0.0;
                for (DefaultWeightedEdge edge : path.getEdgeList()) {
                    CArc arc = edgeToArc.get(edge);
                    if (arc != null) {
                        totalW1 += arc.w1;
                        totalW2 += arc.w2;
                    }
                }
                
                if (totalW1 <= maxW1 && totalW2 <= maxW2 && path.getWeight() < bestLength) {
                    bestLength = path.getWeight();
                    bestPath = path;
                }
            }
        }
        
        // 6. 返回边的索引列表
        ArrayList<Integer> arcIndices = new ArrayList<>();
        if (bestPath != null) {
            for (DefaultWeightedEdge edge : bestPath.getEdgeList()) {
                CArc arc = edgeToArc.get(edge);
                if (arc != null) {
                    arcIndices.add(arc.var);
                }
            }
        }
        
        return arcIndices;
    }
}