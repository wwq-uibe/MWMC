package ndsr;

import java.util.ArrayList;

public class CLabel {

	public double w1=0;
	public double w2=0;
	public ArrayList<Integer> path=new ArrayList<Integer>();
	public ArrayList<Integer> arc_visit_sequence=new ArrayList<Integer>();
	public double cost=0;
	public int var_p=-1;
}
