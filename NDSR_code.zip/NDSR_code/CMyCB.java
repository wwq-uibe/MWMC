package ndsr;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBCallback;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBVar;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class CMyCB extends GRBCallback {

    private static final double EPS = 1e-6;
    private static final double LBA_TIME_LIMIT_SEC = 0.01;

    /*
     * To keep the callback light, we run the expensive lb-cut B&B procedure
     * at most once per processed MIP node. The ordinary min-cut separation is
     * still checked for every OD pair.
     */
    private static final int MAX_LBA_CUTS_PER_NODE = 1;

    private final GRBVar[] z;

    public static int Cuts = 0;
    public static int lba_cuts = 0;
    public static int output = 0;

    private double lastLpObj = Double.NaN;

    /*
     * Reuse the same separator object to avoid repeated object allocation in
     * high-frequency callbacks.
     *
     * If your class is named ClbcutA rather than ClbcutA2, replace ClbcutA2
     * below by ClbcutA.
     */
    private final ClbcutA2 lba = new ClbcutA2();

    public CMyCB(GRBVar[] z) {
        this.z = z;
    }

    @Override
    protected void callback() {
        try {
            if (where == GRB.CB_MIPNODE) {
                separateFractionalNode();
            }
        } catch (GRBException e) {
            System.err.println("Callback error: code=" + e.getErrorCode()
                    + ", msg=" + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Unexpected callback error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void separateFractionalNode() throws GRBException {
        int status = getIntInfo(GRB.CB_MIPNODE_STATUS);
        if (status != GRB.OPTIMAL) {
            return;
        }

        double lpObj = getDoubleInfo(GRB.CB_MIPNODE_OBJBND);
        if (!shouldSeparateAtThisNode(lpObj)) {
            return;
        }
        lastLpObj = lpObj;

        double[] valueZ = getNodeRel(z);
        CutPoolCB.pool.clear();

        int lbaCutsAtThisNode = 0;

        for (int od = 0; od < CODSet.ODSet.size(); od++) {
            int s = CODSet.ODSet.get(od).origin_node;
            int t = CODSet.ODSet.get(od).destination_node;
            double WL1 = CODSet.ODSet.get(od).W_Limit_1;
            double WL2 = CODSet.ODSet.get(od).W_Limit_2;

            /*
             * First try the cheap min-cut separation.
             */
            ArrayList<Integer> minCut = CMinCut.RunFraction(od, s, t, valueZ);
            if (CMinCut.minCutValue < 1.0) {
                ArrayList<Integer> openArcs = Filter(minCut, od);
                ArrayList<Integer> strengthenedCut =
                        MINCARD(openArcs, minCut, s, t, WL1, WL2);
                CutPoolCB.addCut(strengthenedCut);
                continue;
            }

            /*
             * If min-cut separation fails, try the more expensive min-weight
             * length-bounded cut separator, but only a limited number of times.
             */
            if (lbaCutsAtThisNode < MAX_LBA_CUTS_PER_NODE) {
                ArrayList<Integer> arcSet =
                        new ArrayList<Integer>(CODSet.ODSet.get(od).lb_arclist_W);

                lba.Init();
                lba.Run(arcSet, valueZ, s, t, WL1, WL2, LBA_TIME_LIMIT_SEC);

                if (lba.min_wt < 1.0) {
                    ArrayList<Integer> lbCut =
                            new ArrayList<Integer>(lba.final_lb_cut_arclist);

                    /*
                     * The separator removes zero-weight arcs before B&B, so they
                     * must be added back to form the complete violated lb-cut.
                     */
                    lbCut.addAll(lba.zero_weight_arclist);

                    if (!lbCut.isEmpty()) {
                        ArrayList<Integer> openArcs = Filter(lbCut, od);
                        ArrayList<Integer> strengthenedCut =
                                MINCARD(openArcs, lbCut, s, t, WL1, WL2);

                        CutPoolCB.addCut(strengthenedCut);

                        lbaCutsAtThisNode++;
                        lba_cuts++;
                    }
                }
            }
        }

        addCutsFromPool();
    }

    private boolean shouldSeparateAtThisNode(double lpObj) {
        return Double.isNaN(lastLpObj) || Math.abs(lpObj - lastLpObj) > EPS;
    }

    private void addCutsFromPool() throws GRBException {
        for (Set<Integer> cut : CutPoolCB.pool) {
            if (cut == null || cut.isEmpty()) {
                continue;
            }
            AddFeasibleCuts(new ArrayList<Integer>(cut));
        }
    }

    /*
     * The old version used addLazy() at MIPNODE. We keep the same behavior here.
     * The inequality below is
     *
     *      1 - sum_{a in cut} z_a <= 0,
     *
     * which is equivalent to sum_{a in cut} z_a >= 1.
     *
     * In the main model, LazyConstraints must be set to 1 before optimize().
     */
    public void AddFeasibleCuts(ArrayList<Integer> cutArcs) throws GRBException {
        if (cutArcs == null || cutArcs.isEmpty()) {
            return;
        }

        GRBLinExpr expr = new GRBLinExpr();
        expr.addConstant(1.0);

        for (int i = 0; i < cutArcs.size(); i++) {
            int index = cutArcs.get(i);
            expr.addTerm(-1.0, z[index]);
        }

        addLazy(expr, GRB.LESS_EQUAL, 0.0);
        Cuts++;
    }

    /*
     * Given a cut set, return the complementary open-arc set within the OD's
     * length-bounded arc set.
     */
    public ArrayList<Integer> Filter(ArrayList<Integer> cutArcs, int od) {
        HashSet<Integer> cutSet = new HashSet<Integer>(cutArcs);
        ArrayList<Integer> openArcs = new ArrayList<Integer>();

        ArrayList<Integer> odArcSet = CODSet.ODSet.get(od).lb_arclist_W;
        for (int i = 0; i < odArcSet.size(); i++) {
            int index = odArcSet.get(i);
            if (!cutSet.contains(index)) {
                openArcs.add(index);
            }
        }

        return openArcs;
    }

    /*
     * Keep only arcs that belong to the OD's length-bounded arc set.
     */
    public ArrayList<Integer> GetODOpenArcList(ArrayList<Integer> openArcList, int od) {
        HashSet<Integer> odArcSet =
                new HashSet<Integer>(CODSet.ODSet.get(od).lb_arclist_W);
        ArrayList<Integer> result = new ArrayList<Integer>();

        for (int i = 0; i < openArcList.size(); i++) {
            int index = openArcList.get(i);
            if (odArcSet.contains(index)) {
                result.add(index);
            }
        }

        return result;
    }

    /*
     * Reverse-deletion cardinality minimization:
     * Try adding each removed arc back. If no feasible length-bounded path
     * appears, this arc is unnecessary and can be removed from the cut.
     */
    public ArrayList<Integer> MINCARD(ArrayList<Integer> openArcs,
                                      ArrayList<Integer> cutArcs,
                                      int s,
                                      int t,
                                      double WL1,
                                      double WL2) {
        ArrayList<Integer> currentOpen = new ArrayList<Integer>(openArcs);
        ArrayList<Integer> currentCut = new ArrayList<Integer>(cutArcs);

        for (int i = 0; i < currentCut.size(); i++) {
            int index = currentCut.get(i);

            currentOpen.add(0, index);

            ArrayList<Integer> path =
                    ConstrainedShortestPath.findPath(currentOpen, s, t, WL1, WL2);

            if (path.size() == 0) {
                /*
                 * Even after adding this arc back, s and t are still disconnected
                 * under the length bound. Therefore, this arc is not needed in
                 * the cut and can be permanently removed.
                 */
                currentCut.remove(i);
                i--;
            } else {
                /*
                 * Adding this arc back restores feasibility, so it is necessary.
                 */
                currentOpen.remove(0);
            }
        }

        return currentCut;
    }
}
