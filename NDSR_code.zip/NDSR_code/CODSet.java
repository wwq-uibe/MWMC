package ndsr;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

public class CODSet {
	public static ArrayList<CArc> ArcSet=new ArrayList<>();
	public static ArrayList<CODPair> ODSet = new ArrayList<>();
	public static int Max_Node_Index;
	public static double[][] W1;
	public static double[][] W2;
	public static int SEED;
	
	public static void Init(String s,int OD_N) {
		int MAX_NODE=-1;
		ODSet.clear();
		ArcSet.clear();
		try {
			File file = new File(s);
			FileReader fred = new FileReader(file);
			@SuppressWarnings("resource")
			BufferedReader bfred = new BufferedReader(fred);
			String temp = "";
			
			int k=0;
			int od_n=0;
			int arc_n=28+OD_N+2;

			while (null != (temp = bfred.readLine())) {		
				k++;
				if (k==11) {
					String[] newArr = temp.trim().split("\\s+");
					int seed=Integer.parseInt(newArr[1]);
					SEED=seed;
				}
				if (k<=28) {
					continue;
				}
				if (od_n<OD_N) {
					String[] newArr = temp.trim().split("\\s+");
					int o=Integer.parseInt(newArr[1]);
					int d=Integer.parseInt(newArr[2]);
					double flow=Double.parseDouble(newArr[3]);
					int w1=Integer.parseInt(newArr[4]);
					int w2=Integer.parseInt(newArr[5]);
					
					CODPair OD=new CODPair();
					OD.origin_node=o;
					OD.destination_node=d;
					OD.flow=flow;
					OD.W_Limit_1=w1;
					OD.W_Limit_2=w2;
					
					ODSet.add(OD);
					od_n++;
				}
				
				if (k>=arc_n) {
					String[] newArr = temp.trim().split("\\s+");
					int index=Integer.parseInt(newArr[0]);
					int o=Integer.parseInt(newArr[1]);
					int d=Integer.parseInt(newArr[2]);
					int fixcost=Integer.parseInt(newArr[3]);
					int variableCost=Integer.parseInt(newArr[4]);
					int w1=Integer.parseInt(newArr[5]);
					int w2=Integer.parseInt(newArr[6]);
					
					CArc arc=new CArc ();
					arc.real_left=o;
					arc.real_right=d;
					arc.fix_cost=fixcost;
					arc.variableCost=variableCost;
					arc.w1=w1;
					arc.w2=w2;
					
					if (MAX_NODE<o) {
						MAX_NODE=o;
					}
					if (MAX_NODE<d) {
						MAX_NODE=d;
					}
					
					ArcSet.add(arc);
				}
				
			}
			InitVarArc();
			Max_Node_Index=MAX_NODE;
			//init W1
			W1=new double [MAX_NODE+1][MAX_NODE+1];
			InitW1();
			//init W2
			W2=new double [MAX_NODE+1][MAX_NODE+1];
			InitW2();
			//init lb-cut list
			InitLBCutListW();
		} catch (Exception e) {
			System.out.print(e.toString());
		}
		//init cut
		InitMincut();
		InitForwardcut();
		InitBackwardcut();
		//all paths
		CEnumeratePath.Run();
	}
	
	public static void InitW1 () {
		Graph<Integer, DefaultWeightedEdge> g =
	            new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);

	    for (CArc arc : CODSet.ArcSet) {

	        int u = arc.real_left;
	        int v = arc.real_right;

	        if (!g.containsVertex(u)) g.addVertex(u);
	        if (!g.containsVertex(v)) g.addVertex(v);

	        DefaultWeightedEdge e = g.addEdge(u, v);

	        if (e != null) {
	            double w = arc.w1;
	            g.setEdgeWeight(e, w);
	        }
	    }
	    
	    DijkstraShortestPath<Integer, DefaultWeightedEdge> dijkstra =
	            new DijkstraShortestPath<>(g);
	    	    
	    for (int i=0;i<Max_Node_Index+1;i++) {
	    	for (int j=0;j<Max_Node_Index+1;j++) {
	    		if (i!=j) {
	    			if (g.containsVertex(i)==false|g.containsVertex(j)==false) {
	    				W1[i][j]=Double.POSITIVE_INFINITY;
	    			}else {
	    				GraphPath<Integer, DefaultWeightedEdge> path =
			    	            dijkstra.getPath(i, j);
		    			if (path == null) {
		    				W1[i][j]=Double.POSITIVE_INFINITY;
		    			}else {
		    				W1[i][j]=path.getWeight();
		    			}
	    			}
	    		}
	    	}
	    }
	}
	
	public static void InitW2 () {
		Graph<Integer, DefaultWeightedEdge> g =
	            new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);

	    for (CArc arc : CODSet.ArcSet) {

	        int u = arc.real_left;
	        int v = arc.real_right;

	        if (!g.containsVertex(u)) g.addVertex(u);
	        if (!g.containsVertex(v)) g.addVertex(v);

	        DefaultWeightedEdge e = g.addEdge(u, v);

	        if (e != null) {
	            double w = arc.w2;
	            g.setEdgeWeight(e, w);
	        }
	    }
	    
	    DijkstraShortestPath<Integer, DefaultWeightedEdge> dijkstra =
	            new DijkstraShortestPath<>(g);
	    	    
	    for (int i=0;i<Max_Node_Index+1;i++) {
	    	for (int j=0;j<Max_Node_Index+1;j++) {
	    		if (i!=j) {
	    			if (g.containsVertex(i)==false|g.containsVertex(j)==false) {
	    				W2[i][j]=Double.POSITIVE_INFINITY;
	    			}else {
	    				GraphPath<Integer, DefaultWeightedEdge> path =
			    	            dijkstra.getPath(i, j);
		    			if (path == null) {
		    				W2[i][j]=Double.POSITIVE_INFINITY;
		    			}else {
		    				W2[i][j]=path.getWeight();
		    			}
	    			}
	    		}
	    	}
	    }
	}
	
	public static void InitLBCutListW () {
		for (int od=0;od<ODSet.size();od++) {
	    	int s=ODSet.get(od).origin_node;
	    	int t=ODSet.get(od).destination_node;
	    	for (int a=0;a<ArcSet.size();a++) {
	    		int i=ArcSet.get(a).real_left;
	    		int j=ArcSet.get(a).real_right;
	    		if (W1[s][i]+W1[i][t]<=ODSet.get(od).W_Limit_1+0.01
	    				&W1[s][j]+W1[j][t]<=ODSet.get(od).W_Limit_1+0.01) {
	    			if (W2[s][i]+W2[i][t]<=ODSet.get(od).W_Limit_2+0.01
	    					&W2[s][j]+W2[j][t]<=ODSet.get(od).W_Limit_2+0.01) {
	    				ODSet.get(od).lb_arclist_W.add(a);
	    			}
	    		}
	    	}
		}
	}
	
	public static void InitForwardcut() {
		for (int od=0;od<ODSet.size();od++) {
			int s=ODSet.get(od).origin_node;
	    	for (int i=0;i<ODSet.get(od).lb_arclist_W.size();i++) {
	    		int a=ODSet.get(od).lb_arclist_W.get(i);
	    		if (ArcSet.get(a).real_left==s) {
	    			ODSet.get(od).forwardcut.add(a);
	    		}
	    	}
	    	CutPool.addCut(ODSet.get(od).forwardcut);
	    	if (haveSameElements(ODSet.get(od).forwardcut,ODSet.get(od).mincut)==true) {
	    		ODSet.get(od).forwardcut.clear();
	    	}
		}
	}
	
	public static void InitBackwardcut() {
		for (int od=0;od<ODSet.size();od++) {
			int t=ODSet.get(od).destination_node;
	    	for (int i=0;i<ODSet.get(od).lb_arclist_W.size();i++) {
	    		int a=ODSet.get(od).lb_arclist_W.get(i);
	    		if (ArcSet.get(a).real_right==t) {
	    			ODSet.get(od).backwardcut.add(a);
	    		}
	    	}
	    	CutPool.addCut(ODSet.get(od).backwardcut);
	    	if (haveSameElements(ODSet.get(od).backwardcut,ODSet.get(od).mincut)==true) {
	    		ODSet.get(od).backwardcut.clear();
	    	}
		}
	}
	
	public static void InitMincut() {
		for (int od=0;od<ODSet.size();od++) {
			int s=ODSet.get(od).origin_node;
	    	int t=ODSet.get(od).destination_node;
	    	ArrayList<Integer> temp=CMinCut.Run(ODSet.get(od).lb_arclist_W, s, t);
	    	
	    	CutPool.addCut(temp);
		}
	}
	
	public static <T extends Comparable<? super T>> boolean haveSameElements(ArrayList<T> list1, ArrayList<T> list2) {
	    if (list1 == null || list2 == null) return false;
	    if (list1.size() != list2.size()) return false;
	    
	    ArrayList<T> sorted1 = new ArrayList<>(list1);
	    ArrayList<T> sorted2 = new ArrayList<>(list2);
	    Collections.sort(sorted1);
	    Collections.sort(sorted2);
	    
	    return sorted1.equals(sorted2);
	}
	
	public static void InitVarArc() {
		for (int a=0;a<ArcSet.size();a++) {
			ArcSet.get(a).var=a;
		}
	}
	
	public static void InitCutPool () {
		Random ran=new Random();
		for (int od=0;od<ODSet.size();od++) {
			int s=ODSet.get(od).origin_node;
	    	int t=ODSet.get(od).destination_node;
	    	double wl1=ODSet.get(od).W_Limit_1;
	    	double wl2=ODSet.get(od).W_Limit_2;
	    	
	    	ArrayList<Integer> OpenArcIndex=(ArrayList<Integer>) ODSet.get(od).lb_arclist_W.clone();
	    	ArrayList<Integer> cutIndex=new ArrayList<Integer>();
	    	while (true) {	    		
	    		ArrayList<Integer> path=ConstrainedShortestPath.findPath(OpenArcIndex, s, t, wl1, wl2);
	    		if (path.size()!=0) {
	    			int i=ran.nextInt(path.size());
	    			int a=path.get(i);
	    			int index=OpenArcIndex.indexOf(a);
	    			OpenArcIndex.remove(index);	    			
	    			cutIndex.add(a);
	    		}else {
	    			break;
	    		}
	    	}
	    	cutIndex=MINCARD(OpenArcIndex,cutIndex,s,t,wl1,wl2);
	    	CutPool.addCut(cutIndex);
		}
	}
	
	public static ArrayList<Integer> MINCARD (ArrayList<Integer> s_open,ArrayList<Integer> s_remove,int s,int t,double WL1,double WL2) {
    	for (int i=0;i<s_remove.size();i++) {
    		int id=s_remove.get(i);
    		s_open.add(0,id);
    		
    		ArrayList<Integer> temp=ConstrainedShortestPath.findPath(s_open, s, t, WL1, WL2);
    		double LEN=ConstrainedShortestPath.bestLength;
    		if (temp.size()==0) {
    			s_remove.remove(i);
    			i--;
    		}else {
    			s_open.remove(0);
    		}
    	}
    	
    	return s_remove;
    }
	
	public static int GetScenarioNode (int Scenario) {
		if (Scenario==1) {
			return 30;
		}else if (Scenario==2) {
			return 40;
		}else if (Scenario>=3&Scenario<=15) {
			return 50;
		}else if (Scenario==16) {
			return 60;
		}else if (Scenario==17) {
			return 70;
		}else if (Scenario==18) {
			return 80;
		}else {
			return -1;
		}
	}
	
	public static int GetScenarioArc (int Scenario) {
		if (Scenario==1) {
			return 120;
		}else if (Scenario==2) {
			return 160;
		}else if (Scenario==3) {
			return 150;
		}else if (Scenario>=4&Scenario<=6) {
			return 200;
		}else if (Scenario==7) {
			return 250;
		}else if (Scenario>=8&Scenario<=15) {
			return 200;
		}else if (Scenario==16) {
			return 240;
		}else if (Scenario==17) {
			return 280;
		}else if (Scenario==18) {
			return 320;
		}else {
			return -1;
		}
	}
	
	public static int GetScenarioOD (int Scenario) {
		if (Scenario==1) {
			return 90;
		}else if (Scenario==2) {
			return 120;
		}else if (Scenario==3) {
			return 150;
		}else if (Scenario==4) {
			return 100;
		}else if (Scenario==5) {
			return 150;
		}else if (Scenario==6) {
			return 200;
		}else if (Scenario>=7&Scenario<=15) {
			return 150;
		}else if (Scenario==16) {
			return 180;
		}else if (Scenario==17) {
			return 210;
		}else if (Scenario==18) {
			return 240;
		}else {
			return -1;
		}
	}
}
