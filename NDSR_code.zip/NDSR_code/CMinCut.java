package ndsr;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import org.jgrapht.Graph;
import org.jgrapht.alg.flow.DinicMFImpl;
import org.jgrapht.alg.interfaces.MinimumSTCutAlgorithm;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

public class CMinCut {
	
	public static double minCutValue;

	public static ArrayList<Integer> Run (ArrayList<Integer> ArcSetIndexLL, int s,int t) {
		Graph<Integer, DefaultWeightedEdge> g =
				new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);
		// 用来把JGraphT中的edge映射回你自己的CArc
		HashMap<DefaultWeightedEdge, CArc> edgeToArc = new HashMap<>();
		
		for (int i=0;i<ArcSetIndexLL.size();i++) {
			int a=ArcSetIndexLL.get(i);
			int u = CODSet.ArcSet.get(a).real_left;
			int v = CODSet.ArcSet.get(a).real_right;

			if (!g.containsVertex(u)) {
				g.addVertex(u);
			}
			if (!g.containsVertex(v)) {
				g.addVertex(v);
			}

			// 如果网络中不存在平行边，这样写就可以
			DefaultWeightedEdge e = g.addEdge(u, v);

			// 若重复边导致 addEdge 返回 null，则跳过或自行处理
			if (e != null) {
				// 
				g.setEdgeWeight(e, 1);
				edgeToArc.put(e, CODSet.ArcSet.get(a));
			}
		}
		
		if (!g.containsVertex(s) || !g.containsVertex(t)) {
		    throw new IllegalArgumentException("Graph must contain both s and t.");
		}
		
		MinimumSTCutAlgorithm<Integer, DefaultWeightedEdge> minCutAlg =
				new DinicMFImpl<>(g);

		minCutAlg.calculateMinCut(s, t);
		Set<DefaultWeightedEdge> cutEdges = minCutAlg.getCutEdges();
		
		ArrayList<Integer> ArcIndexList = new ArrayList<>();
		for (DefaultWeightedEdge e : cutEdges) {
			CArc arc = edgeToArc.get(e);
			if (arc != null) {
				int index=arc.var;
				ArcIndexList.add(index);
			}
		}

		return ArcIndexList;
	}
	
	public static ArrayList<Integer> RunFraction (int od, int s,int t,double[] value_z) {
		Graph<Integer, DefaultWeightedEdge> g =
				new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);
		// 用来把JGraphT中的edge映射回你自己的CArc
		HashMap<DefaultWeightedEdge, Integer> edgeToArcIndex = new HashMap<>();
		
		for (int i=0;i<CODSet.ODSet.get(od).lb_arclist_W.size();i++) {
			int a=CODSet.ODSet.get(od).lb_arclist_W.get(i);
			int u = CODSet.ArcSet.get(a).real_left;
			int v = CODSet.ArcSet.get(a).real_right;
			double wt = value_z[a];
			
			if (wt<1e-6) {
				wt=1e-6;
			}

			if (!g.containsVertex(u)) {
				g.addVertex(u);
			}
			if (!g.containsVertex(v)) {
				g.addVertex(v);
			}

			// 如果网络中不存在平行边，这样写就可以
			DefaultWeightedEdge e = g.addEdge(u, v);

			// 若重复边导致 addEdge 返回 null，则跳过或自行处理
			if (e != null) {
				// 
				g.setEdgeWeight(e, wt);
				edgeToArcIndex.put(e, a);
			}
		}
		
		if (!g.containsVertex(s) || !g.containsVertex(t)) {
		    throw new IllegalArgumentException("Graph must contain both s and t.");
		}
		
		MinimumSTCutAlgorithm<Integer, DefaultWeightedEdge> minCutAlg =
				new DinicMFImpl<>(g);

		minCutAlg.calculateMinCut(s, t);
		Set<DefaultWeightedEdge> cutEdges = minCutAlg.getCutEdges();
		
		minCutValue = minCutAlg.getCutCapacity();
		
		ArrayList<Integer> ArcIndexList = new ArrayList<>();
		for (DefaultWeightedEdge e : cutEdges) {
			ArcIndexList.add(edgeToArcIndex.get(e));
		}

		return ArcIndexList;
	}
}
