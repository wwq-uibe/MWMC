package ndsr;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

public class CGRB {

	GRBEnv env;
	GRBModel model;	
	
	GRBVar[] z;
	GRBVar[] x;
	
	public ArrayList<Integer> openarclist=new ArrayList<Integer> ();
	public ArrayList<CArc> OpenArc=new ArrayList<CArc> ();
	
	public double objVal;
	public double runtime;
	public double gap;
	public int path_number=0;
	
	public void Init() throws GRBException {
		env = new GRBEnv(true);
		env.set("logFile", "knapsack.log");
//		env.set(GRB.IntParam.OutputFlag, 0);
        env.start();
        
        model = new GRBModel(env);
        model.set(GRB.DoubleParam.TimeLimit, 3600.0);
        model.set(GRB.IntParam.LazyConstraints, 1);
        model.set(GRB.IntParam.PreCrush, 1);
        
        for (int od=0;od<CODSet.ODSet.size();od++) {
        	path_number+=CODSet.ODSet.get(od).LABELLIST.size();
        }
        
        int var_p=0;
        for (int od=0;od<CODSet.ODSet.size();od++) {
        	for (int l=0;l<CODSet.ODSet.get(od).LABELLIST.size();l++) {
        		CODSet.ODSet.get(od).LABELLIST.get(l).var_p=var_p;
        		var_p++;
        	}
        }
	}
	
	public void build_model(int Node_N) throws GRBException {		
	    z=new GRBVar[CODSet.ArcSet.size()];
	    for (int a=0;a<CODSet.ArcSet.size();a++) {
	    	z[a]=model.addVar(0, 1, 0, GRB.BINARY, "z" +a);
	    }
	    
	    x=new GRBVar[path_number];
	    for (int i=0;i<x.length;i++) {
	    	x[i]=model.addVar(0, 1, 0, GRB.BINARY, "x" +x);
	    }
	    //add cuts
	    for (Set<Integer> cut : CutPool.pool) {
            ArrayList<Integer> list = new ArrayList<>(cut);
            GRBLinExpr temp = new GRBLinExpr();
            for (int i=0;i<list.size();i++) {
            	int a=list.get(i);
            	temp.addTerm(1.0, z[a]);
            }
            model.addConstr(temp, GRB.GREATER_EQUAL, 1, null);
        }

	    //For each OD, must select one path
	    for (int od=0;od<CODSet.ODSet.size();od++) {
	    	GRBLinExpr temp = new GRBLinExpr();
	    	for (int l=0;l<CODSet.ODSet.get(od).LABELLIST.size();l++) {
	    		int var_p=CODSet.ODSet.get(od).LABELLIST.get(l).var_p;
	    		temp.addTerm(1.0, x[var_p]);
	    	}
	    	model.addConstr(temp, GRB.EQUAL, 1, null);
	    }
	    
	    //For each OD, if arc is not active, all relate path must be close
	    for (int a=0;a<z.length;a++) {
	    	for (int od=0;od<CODSet.ODSet.size();od++) {
	    		GRBLinExpr temp = new GRBLinExpr();
	    		for (int l=0;l<CODSet.ODSet.get(od).LABELLIST.size();l++) {
	    			if (CODSet.ODSet.get(od).LABELLIST.get(l).arc_visit_sequence.indexOf(a)>=0) {
	    				int var_p=CODSet.ODSet.get(od).LABELLIST.get(l).var_p;
	    				temp.addTerm(1.0, x[var_p]);
	    			}
	    		}
	    		model.addConstr(z[a], GRB.GREATER_EQUAL, temp, null);
	    	}
	    }
	    //obj
	    GRBLinExpr obj = new GRBLinExpr();
	    for (int a=0;a<CODSet.ArcSet.size();a++) {
	    	obj.addTerm(CODSet.ArcSet.get(a).fix_cost, z[a]);
	    }
	    for (int od=0;od<CODSet.ODSet.size();od++) {
    		for (int l=0;l<CODSet.ODSet.get(od).LABELLIST.size();l++) {
    			double path_cost=CODSet.ODSet.get(od).LABELLIST.get(l).cost;
    			int var_p=CODSet.ODSet.get(od).LABELLIST.get(l).var_p;
    			obj.addTerm(path_cost, x[var_p]);
    		}
	    }
	    model.setObjective(obj, GRB.MINIMIZE);
	    
	    //test

	}
	
	public void solve() throws GRBException, IOException {	
		CMyCB cb=new CMyCB (z);
		model.setCallback(cb);
		
		model.optimize();		
		
        objVal = model.get(GRB.DoubleAttr.ObjVal);
        runtime=model.get(GRB.DoubleAttr.Runtime);
        gap = model.get(GRB.DoubleAttr.MIPGap);
		
		openarclist.clear();
		OpenArc.clear();
		for (int a=0;a<z.length;a++) {
			if (z[a].get(GRB.DoubleAttr.X)>0.5) {
				openarclist.add(a);
				OpenArc.add(CODSet.ArcSet.get(a));
			}
		}
	}
	
	public void end () throws GRBException {
		model.dispose();
        env.dispose();
	}

}
