package ndsr;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class CutPoolCB {
	// 全局 cut pool
    public static final Set<Set<Integer>> pool = new HashSet<>();

    /**
     * 添加一个 cut（核心函数）
     * @return true = 成功加入；false = 被支配/重复
     */
    public static boolean addCut(List<Integer> temp) {

        Set<Integer> newCut = new HashSet<>(temp);

        if (newCut.isEmpty()) return false;

        // 1️⃣ 是否被已有 cut 支配
        for (Set<Integer> oldCut : pool) {
            if (newCut.containsAll(oldCut)) {
                return false;
            }
        }

        // 2️⃣ 删除所有被 newCut 支配的旧 cut
        Iterator<Set<Integer>> it = pool.iterator();
        while (it.hasNext()) {
            Set<Integer> oldCut = it.next();
            if (oldCut.containsAll(newCut)) {
                it.remove();
            }
        }

        // 3️⃣ 加入
        pool.add(new HashSet<>(newCut));

        return true;
    }

    /**
     * 删除 cut
     */
    public static boolean removeCut(List<Integer> temp) {
        return pool.remove(new HashSet<>(temp));
    }

    /**
     * 判断是否存在完全相同 cut
     */
    public static boolean containsCut(List<Integer> temp) {
        return pool.contains(new HashSet<>(temp));
    }

    /**
     * 判断是否被支配
     */
    public static boolean isDominated(List<Integer> temp) {
        Set<Integer> newCut = new HashSet<>(temp);

        for (Set<Integer> oldCut : pool) {
            if (newCut.containsAll(oldCut)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 返回 pool size
     */
    public static int size() {
        return pool.size();
    }

    /**
     * 清空 pool
     */
    public static void clear() {
        pool.clear();
    }

    /**
     * 获取所有 cut（只读建议）
     */
    public static Set<Set<Integer>> getAllCuts() {
        return pool;
    }

    /**
     * 打印
     */
    public static void printCuts() {
        System.out.println("CutPool size = " + pool.size());

        for (Set<Integer> cut : pool) {
            ArrayList<Integer> list = new ArrayList<>(cut);
            Collections.sort(list);
            System.out.println(list);
        }
    }
}
