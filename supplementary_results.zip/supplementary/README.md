# Instance-level results

Supplementary results for "Lexicographic Minimum-Weight Minimum-Cardinality Length-Bounded Cuts: Applications in Network Optimization".
All runs: AMD EPYC 7532, 12 threads, 32 GB, Gurobi 12.0, time limit 3,600 s, relative optimality tolerance 1e-4.

## results_RSLP.csv (240 instances x 8 configurations, Table 10; maximization)
- network, R_km, tau, p: instance parameters (Section 6.2.1).
- configuration: BC1, BC1E, ALG1, ALG2, ALG2ST, ALG2M, ALG3, ALG4 (Section 6.2.2, Table 9).
- status: Gurobi termination status. ObjVal, ObjBound, MIPGap: final objective value, bound, and relative gap.
- LB = ObjVal and UB = ObjBound (maximization).
- NodeCount, IterCount, Work: Gurobi statistics. Runtime_s: Gurobi runtime (includes callbacks).
- TotalTime_s: node-set construction + pre-cut generation + Runtime_s; for ALG2M, the time spent recording the additional cut sizes for the paired comparison is excluded.
- PreCuts: number of pre-generated lb-cut constraints. DynamicCuts: number of lb-cuts generated in the callbacks.

## results_NDSR.csv (90 instances x 2 configurations, Table 14; minimization)
- configuration: path-based (without lb-cuts) or with pre-generated lb-cuts.
- LB = ObjBound and UB = ObjVal (minimization).
- TotalTime_s: Runtime_s + generation time of the pre-generated lb-cuts.
- LP_original: LP relaxation of the original (unpresolved) model; RootRelaxation_presolved: root relaxation reported by Gurobi; RootBoundAfterCuts: bound after the root cutting planes.
- RootBoundAfterCuts, RootBoundSource, RootGap_pct, BestKnownObj (RSLP): root bound after Gurobi's root cutting planes, recorded in a MIPNODE callback; for instances solved at the root node, no separate root bound is recorded and the final bound is used. RootGap_pct = 100 (RootBoundAfterCuts - BestKnownObj) / BestKnownObj, where BestKnownObj is the best objective value over all configurations (root gaps in Table 10).
