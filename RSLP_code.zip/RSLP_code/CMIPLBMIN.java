package weiquanmax;

import java.util.ArrayList;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

public class CMIPLBMIN {

    // Output: true original weight of the returned cut.
    public static double wt = Double.POSITIVE_INFINITY;

    // Output: cardinality of the returned cut.
    public static int cardinality = Integer.MAX_VALUE;

    // Output: returned node-based LB-cut.
    public static ArrayList<Integer> mincut = new ArrayList<Integer>();

    // Solver information.
    public static boolean cutFound = false;
    public static boolean optimal = false;
    public static boolean timeLimitReached = false;
    public static boolean validCut = false;

    public static int status = -1;
    public static int solCount = 0;
    public static int arcCount = 0;
    public static double runtime = 0.0;
    public static double mip_obj = Double.POSITIVE_INFINITY;

    // Numerical parameters.
    private static final double DIST_EPS = 0.01;
    private static final double STRICT_EPS = 1e-6;
    private static final double WEIGHT_TOL = 1e-6;

    // If true, validate the returned cut by calling CGetLength.
    public static boolean checkCutValidity = true;

    private static class Arc {
        int from;
        int to;
        double len;

        Arc(int from, int to, double len) {
            this.from = from;
            this.to = to;
            this.len = len;
        }
    }

    public static void Reset() {
        wt = Double.POSITIVE_INFINITY;
        cardinality = Integer.MAX_VALUE;
        mincut.clear();

        cutFound = false;
        optimal = false;
        timeLimitReached = false;
        validCut = false;

        status = -1;
        solCount = 0;
        arcCount = 0;
        runtime = 0.0;
        mip_obj = Double.POSITIVE_INFINITY;
    }

    /**
     * Minimize the cardinality of a node-based LB-cut under the min-weight upper bound.
     *
     * Input:
     *   od:          OD pair index.
     *   value_x:     current fractional x values.
     *   max_seconds: MIP time limit in seconds.
     *   max_weight:  upper bound on the original cut weight, usually CMIPLB.wt.
     *
     * Output:
     *   CMIPLBMIN.mincut
     *   CMIPLBMIN.wt
     *   CMIPLBMIN.cardinality
     */
    public static void Run(int od, double[] value_x, double max_seconds, double max_weight) {
        Reset();

        if (Double.isNaN(max_weight) || max_weight == Double.POSITIVE_INFINITY) {
            return;
        }

        GRBEnv env = null;
        GRBModel model = null;

        try {
            int O = CODSet.ODSet.get(od).origin_node;
            int D = CODSet.ODSet.get(od).destination_node;

            ArrayList<Integer> nodes = new ArrayList<Integer>(CODSet.ODSet.get(od).nodes_set);
            int n = nodes.size();

            int S = n;
            int T = n + 1;
            int totalNodes = n + 2;

            double R = CLBC.EV_Range;
            double lengthBound = CODSet.shortestdis[O][D] * (1.0 + CLBC.tolerence) + DIST_EPS;
            double M = 2.0 * lengthBound + R + 1.0;

            ArrayList<Arc> arcs = BuildRoundTripArcs(O, D, nodes, R);
            arcCount = arcs.size();

            env = new GRBEnv(true);
            env.set(GRB.IntParam.OutputFlag, 0);
            env.start();

            model = new GRBModel(env);
            model.set(GRB.IntParam.OutputFlag, 0);
            model.set(GRB.DoubleParam.TimeLimit, max_seconds);
            model.set(GRB.IntParam.Threads, 1);

            // Variables.
            // u[i] = 1 if real node nodes.get(i) is selected in the LB-cut.
            GRBVar[] u = new GRBVar[n];

            // pi variables for candidate nodes plus virtual source S and virtual sink T.
            GRBVar[] pi = new GRBVar[totalNodes];

            for (int i = 0; i < n; i++) {
                int realNode = nodes.get(i);
                u[i] = model.addVar(0.0, 1.0, 0.0, GRB.BINARY, "u_" + realNode);
            }

            for (int i = 0; i < totalNodes; i++) {
                pi[i] = model.addVar(0.0, M, 0.0, GRB.CONTINUOUS, "pi_" + i);
            }

            // pi_t = 0.
            model.addConstr(pi[T], GRB.EQUAL, 0.0, "pi_t_zero");

            // pi_s >= lengthBound + epsilon.
            model.addConstr(pi[S], GRB.GREATER_EQUAL, lengthBound + STRICT_EPS, "pi_s_lb");

            // Arc constraints:
            // pi_i <= pi_j + delta_ij + M u_j, where u_t = 0.
            for (int a = 0; a < arcs.size(); a++) {
                Arc arc = arcs.get(a);

                GRBLinExpr expr = new GRBLinExpr();
                expr.addTerm(1.0, pi[arc.from]);
                expr.addTerm(-1.0, pi[arc.to]);

                if (arc.to >= 0 && arc.to < n) {
                    expr.addTerm(-M, u[arc.to]);
                }

                // pi_from - pi_to - M u_to <= len
                model.addConstr(expr, GRB.LESS_EQUAL, arc.len, "arc_" + a);
            }

            // Weight upper bound: sum value_x[i] u_i <= CMIPLB.wt + tolerance.
            GRBLinExpr weightExpr = new GRBLinExpr();
            for (int i = 0; i < n; i++) {
                int realNode = nodes.get(i);
                weightExpr.addTerm(NodeWeight(realNode, value_x), u[i]);
            }
            model.addConstr(weightExpr, GRB.LESS_EQUAL, max_weight + WEIGHT_TOL, "weight_bound");

            // Objective: minimize cardinality.
            GRBLinExpr obj = new GRBLinExpr();
            for (int i = 0; i < n; i++) {
                obj.addTerm(1.0, u[i]);
            }
            model.setObjective(obj, GRB.MINIMIZE);

            // Optional MIP start from CMIPLB.mincut if it exists.
            // This is useful when CMIPLBMIN is called immediately after CMIPLB.
            trySetMIPStartFromCMIPLB(u, nodes, max_weight, value_x);

            model.optimize();

            status = model.get(GRB.IntAttr.Status);
            solCount = model.get(GRB.IntAttr.SolCount);
            runtime = model.get(GRB.DoubleAttr.Runtime);

            optimal = (status == GRB.Status.OPTIMAL);
            timeLimitReached = (status == GRB.Status.TIME_LIMIT);

            if (solCount <= 0) {
                return;
            }

            mip_obj = model.get(GRB.DoubleAttr.ObjVal);

            ArrayList<Integer> cut = new ArrayList<Integer>();
            double trueWeight = 0.0;

            for (int i = 0; i < n; i++) {
                if (u[i].get(GRB.DoubleAttr.X) > 0.5) {
                    int realNode = nodes.get(i);
                    cut.add(realNode);
                    trueWeight += NodeWeight(realNode, value_x);
                }
            }

            mincut = cut;
            wt = trueWeight;
            cardinality = cut.size();
            cutFound = true;

            if (checkCutValidity) {
                ArrayList<Integer> remainingNodes = CGetLength.QuFan(mincut, od);
                boolean stillFeasible = CGetLength.Run(remainingNodes, od);
                validCut = !stillFeasible;

                if (!validCut) {
                    cutFound = false;
                    mincut.clear();
                    wt = Double.POSITIVE_INFINITY;
                    cardinality = Integer.MAX_VALUE;
                }
            } else {
                validCut = true;
            }

        } catch (GRBException e) {
            System.err.println("CMIPLBMIN error: code=" + e.getErrorCode()
                    + ", msg=" + e.getMessage());
        } catch (Exception e) {
            System.err.println("CMIPLBMIN error: " + e.getMessage());
        } finally {
            try {
                if (model != null) model.dispose();
                if (env != null) env.dispose();
            } catch (GRBException e) {
                System.err.println("CMIPLBMIN dispose error: " + e.getMessage());
            }
        }
    }

    private static ArrayList<Arc> BuildRoundTripArcs(int O, int D,
                                                     ArrayList<Integer> nodes,
                                                     double R) {
        ArrayList<Arc> arcs = new ArrayList<Arc>();

        int n = nodes.size();
        int S = n;
        int T = n + 1;

        for (int i = 0; i < n; i++) {
            int vi = nodes.get(i);

            // Virtual source to first charging node: half range.
            if (CODSet.shortestdis[O][vi] <= R / 2.0 + DIST_EPS) {
                arcs.add(new Arc(S, i, CODSet.shortestdis[O][vi]));
            }

            // Charging node to virtual sink: half range.
            if (CODSet.shortestdis[vi][D] <= R / 2.0 + DIST_EPS) {
                arcs.add(new Arc(i, T, CODSet.shortestdis[vi][D]));
            }

            // Charging node to charging node: full range.
            for (int j = 0; j < n; j++) {
                if (i == j) continue;

                int vj = nodes.get(j);
                if (CODSet.shortestdis[vi][vj] <= R + DIST_EPS) {
                    arcs.add(new Arc(i, j, CODSet.shortestdis[vi][vj]));
                }
            }
        }

        return arcs;
    }

    private static double NodeWeight(int node, double[] value_x) {
        if (value_x == null || node < 0 || node >= value_x.length) {
            return 0.0;
        }
        return Math.max(0.0, value_x[node]);
    }

    private static void trySetMIPStartFromCMIPLB(GRBVar[] u,
                                                 ArrayList<Integer> nodes,
                                                 double max_weight,
                                                 double[] value_x) {
        try {
            if (CMIPLB.mincut == null || CMIPLB.mincut.size() == 0) {
                return;
            }

            double startWeight = 0.0;
            for (int k = 0; k < CMIPLB.mincut.size(); k++) {
                startWeight += NodeWeight(CMIPLB.mincut.get(k), value_x);
            }

            if (startWeight > max_weight + WEIGHT_TOL) {
                return;
            }

            for (int i = 0; i < nodes.size(); i++) {
                int realNode = nodes.get(i);
                if (CMIPLB.mincut.indexOf(realNode) >= 0) {
                    u[i].set(GRB.DoubleAttr.Start, 1.0);
                } else {
                    u[i].set(GRB.DoubleAttr.Start, 0.0);
                }
            }
        } catch (Exception e) {
            // MIP start is optional. Ignore errors here.
        }
    }
}
