package weiquanmax;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class CLBC {
	public static int NN;
	public static float tolerence;
	public static float EV_Range;
	
	public static void Run(float R,float tol,int nn) throws Exception {
		EV_Range=R;
		tolerence=tol;	
		NN=nn;
		
		for (int i=0;i<CODSet.ODSet.size();i++) {
			int head=CODSet.ODSet.get(i).origin_node;
			int tail=CODSet.ODSet.get(i).destination_node;
			GenerateNodeSet(head,tail,i);//generate node_set
		}

		N_q_Set_Forward();
	//	N_q_Set_Forward_Minimal();
		System.out.println("Forward!!!");

		N_q_Set_BackWard();
	//	N_q_Set_Backward_Minimal();
		System.out.println("Backward!!!");

		N_q_Set_Middle();
	//	N_q_Set_Middle_Minimal();
		System.out.println("Middleward!!!");
		
		for (int od=0;od<CODSet.ODSet.size();od++) {
			int c1=CODSet.ODSet.get(od).nodes_set_forward.size();
			int c2=CODSet.ODSet.get(od).nodes_set_backward.size();
			int c3=CODSet.ODSet.get(od).nodes_set_middle.size();
			int min_c=Integer.MAX_VALUE;
			if (min_c>c1&c1!=0) {
				min_c=c1;
			}
			if (min_c>c2&c2!=0) {
				min_c=c2;
			}
			if (min_c>c3&c3!=0) {
				min_c=c3;
			}
			CODSet.ODSet.get(od).mincut_cardinality=min_c;
		}

	}
	
	public static void GenerateNodeSet(int O,int D,int od) {
		float MAX_LEN=CODSet.shortestdis[O][D]*(1+tolerence);
		MAX_LEN+=0.001;
		for (int i=0;i<NN;i++) {
			float sum=CODSet.shortestdis[O][i]+CODSet.shortestdis[i][D];
			if (sum<=MAX_LEN) {
				CODSet.ODSet.get(od).nodes_set.add(i);
			}
		}
	//	SortQ(od);
	}
	
	public static void SortQ(int od) {
		ArrayList<Float> bili=new ArrayList<Float>();
		
		int O=CODSet.ODSet.get(od).origin_node;
		int D=CODSet.ODSet.get(od).destination_node;
		for (int i=0;i<CODSet.ODSet.get(od).nodes_set.size();i++) {
			int id=CODSet.ODSet.get(od).nodes_set.get(i);
			float bbb=CODSet.shortestdis[O][id]/(CODSet.shortestdis[O][id]+CODSet.shortestdis[id][D]);
			bili.add(bbb);
			
			if (i>0) {
				if (bili.get(i-1)>bili.get(i)) {
					if (bili.get(i)<bili.get(0)) {
						CODSet.ODSet.get(od).nodes_set.remove(i);
						CODSet.ODSet.get(od).nodes_set.add(0,id);
						bili.remove(i);
						bili.add(0,bbb);
					}else {
						for (int k=1;k<bili.size();k++) {
							if (bili.get(k-1)<bili.get(i)&bili.get(i)<bili.get(k)) {
								CODSet.ODSet.get(od).nodes_set.remove(i);
								CODSet.ODSet.get(od).nodes_set.add(k,id);
								bili.remove(i);
								bili.add(k,bbb);
								break;
							}
						}
					}
				}
			}
		}
	}

	public static void N_q_Set_Forward() {
		for (int i=0;i<CODSet.ODSet.size();i++) {
			ArrayList<Integer> node_set=(ArrayList<Integer>) CODSet.ODSet.get(i).nodes_set.clone();
			ArrayList<Integer> q_node_cut=new ArrayList<Integer>();
			int O=CODSet.ODSet.get(i).origin_node;
			for (int j=0;j<node_set.size();j++) {
				int node=node_set.get(j);
				if (CODSet.shortestdis[O][node]<=EV_Range/2+0.01) {
					q_node_cut.add(node);
				}
			}
			CODSet.ODSet.get(i).nodes_set_forward=(ArrayList<Integer>) q_node_cut.clone();
		}
	}
	
	public static void N_q_Set_BackWard() {
		for (int i=0;i<CODSet.ODSet.size();i++) {
			ArrayList<Integer> node_set=(ArrayList<Integer>) CODSet.ODSet.get(i).nodes_set.clone();
			ArrayList<Integer> q_node_cut=new ArrayList<Integer>();
			int D=CODSet.ODSet.get(i).destination_node;
			for (int j=0;j<node_set.size();j++) {
				int node=node_set.get(j);
				if (CODSet.shortestdis[node][D]<=EV_Range/2+0.01) {
					q_node_cut.add(node);
				}
			}
			CODSet.ODSet.get(i).nodes_set_backward=(ArrayList<Integer>) q_node_cut.clone();
		}
		
		for (int i=0;i<CODSet.ODSet.size();i++) {
			ArrayList<Integer> s1=(ArrayList<Integer>) CODSet.ODSet.get(i).nodes_set_forward.clone();
			ArrayList<Integer> s2=(ArrayList<Integer>) CODSet.ODSet.get(i).nodes_set_backward.clone();
			if (s1.size()==s2.size()) {
				if (IsTwoNodeSetEqual(s1,s2)) {
					CODSet.ODSet.get(i).nodes_set_backward.clear();
				}
			}
		}
	}
	
	public static void N_q_Set_Middle() {
		for (int i=0;i<CODSet.ODSet.size();i++) {
			int O=CODSet.ODSet.get(i).origin_node;
			int D=CODSet.ODSet.get(i).destination_node;
			if (CODSet.shortestdis[O][D]<=EV_Range+0.01) {
				continue;
			}
			ArrayList<Integer> q_node_cut=new ArrayList<Integer>();
			
			ArrayList<Integer> s_L=new ArrayList<Integer> ();
			ArrayList<Integer> s_R=new ArrayList<Integer> ();
			for (int j=0;j<CODSet.ODSet.get(i).nodes_set.size();j++) {
				int id=CODSet.ODSet.get(i).nodes_set.get(j);
				if (CODSet.shortestdis[O][id]<=CODSet.shortestdis[id][D]) {
					s_L.add(id);
				}else {
					s_R.add(id);
				}
			}
			
			ArrayList<CArc> arcset=new ArrayList<>();
			for (int a=0;a<s_L.size();a++) {
				for (int b=0;b<s_R.size();b++) {
					int aa=s_L.get(a);
					int bb=s_R.get(b);
					if (CODSet.shortestdis[aa][bb]<=EV_Range+0.01) {
						CArc arc=new CArc();
						arc.real_left=aa;arc.real_right=bb;
						arcset.add(arc);
					}
				}
			}
			//remove arc
			q_node_cut = greedyRemoveByBucket(arcset, NN);
			CODSet.ODSet.get(i).nodes_set_middle=(ArrayList<Integer>) q_node_cut.clone();
		}
		
		for (int i=0;i<CODSet.ODSet.size();i++) {
			ArrayList<Integer> s1=(ArrayList<Integer>) CODSet.ODSet.get(i).nodes_set_forward.clone();
			ArrayList<Integer> s2=(ArrayList<Integer>) CODSet.ODSet.get(i).nodes_set_middle.clone();
			if (s2.size()==0)
				continue;
			if (s1.size()==s2.size()) {
				if (IsTwoNodeSetEqual(s1,s2)) {
					CODSet.ODSet.get(i).nodes_set_middle.clear();
				}
			}
		}
		
		for (int i=0;i<CODSet.ODSet.size();i++) {
			ArrayList<Integer> s1=(ArrayList<Integer>) CODSet.ODSet.get(i).nodes_set_backward.clone();
			ArrayList<Integer> s2=(ArrayList<Integer>) CODSet.ODSet.get(i).nodes_set_middle.clone();
			if (s2.size()==0)
				continue;
			if (s1.size()==s2.size()) {
				if (IsTwoNodeSetEqual(s1,s2)) {
					CODSet.ODSet.get(i).nodes_set_middle.clear();
				}
			}
		}
		
	}
	
	public static boolean IsTwoNodeSetEqual(ArrayList<Integer> s1,ArrayList<Integer> s2) {
		if (s1.size()!=s2.size())
			return false;
		for (int i=0;i<s1.size();i++) {
			int id=s1.get(i);
			if (s2.indexOf(id)==-1)
				return false;
		}
		return true;
	}
	
	public static int FindMostVisit(ArrayList<CArc> arcset) {
		ArrayList<Integer> s_short=new ArrayList<Integer>();
		int[] visitnumber=new int [NN];
		for (int i=0;i<arcset.size();i++) {
			int a=arcset.get(i).real_left;
			int b=arcset.get(i).real_right;
			if (s_short.indexOf(a)<0) {
				s_short.add(a);
			}
			if (s_short.indexOf(b)<0) {
				s_short.add(b);
			}
			visitnumber[a]++;
			visitnumber[b]++;
		}
		Collections.sort(s_short, (a, b) -> Integer.compare(visitnumber[b], visitnumber[a]));
		return s_short.get(0);
	}
	
	public static ArrayList<Integer> greedyRemoveByBucket(ArrayList<CArc> arcset, int NN) {
	    int mM = arcset.size();
	    ArrayList<Integer> q = new ArrayList<>();
	    if (mM == 0) return q;

	    // 1) Build mapping real node ids -> 0..nM-1 (only nodes appearing in arcset)
	    HashMap<Integer, Integer> real2mid = new HashMap<>(mM * 2);
	    ArrayList<Integer> mid2real = new ArrayList<>();

	    for (int e = 0; e < mM; e++) {
	        CArc a = arcset.get(e);
	        int L = a.real_left;
	        int R = a.real_right;

	        Integer idL = real2mid.get(L);
	        if (idL == null) {
	            real2mid.put(L, mid2real.size());
	            mid2real.add(L);
	        }
	        Integer idR = real2mid.get(R);
	        if (idR == null) {
	            real2mid.put(R, mid2real.size());
	            mid2real.add(R);
	        }
	    }

	    int nM = mid2real.size();
	    int[] eu = new int[mM];
	    int[] ev = new int[mM];

	    // 2) First pass: compute degrees in middle graph
	    int[] degInit = new int[nM];
	    for (int e = 0; e < mM; e++) {
	        CArc a = arcset.get(e);
	        int u = real2mid.get(a.real_left);
	        int v = real2mid.get(a.real_right);
	        eu[e] = u;
	        ev[e] = v;
	        degInit[u]++;
	        degInit[v]++;
	    }

	    // 3) Build incident edge arrays inc[v][*] with two-pass allocation (fast)
	    int[][] inc = new int[nM][];
	    int[] fill = new int[nM];
	    for (int v = 0; v < nM; v++) inc[v] = new int[degInit[v]];

	    for (int e = 0; e < mM; e++) {
	        int u = eu[e], v = ev[e];
	        inc[u][fill[u]++] = e;
	        inc[v][fill[v]++] = e;
	    }

	    // 4) Bucket queue by degree (degrees are small integers)
	    boolean[] edgeAlive = new boolean[mM];
	    for (int e = 0; e < mM; e++) edgeAlive[e] = true;

	    boolean[] removedMid = new boolean[nM];
	    int[] deg = degInit.clone();

	    int maxDeg = 0;
	    for (int v = 0; v < nM; v++) if (deg[v] > maxDeg) maxDeg = deg[v];

	    @SuppressWarnings("unchecked")
	    ArrayDeque<Integer>[] buckets = new ArrayDeque[maxDeg + 1];
	    for (int d = 0; d <= maxDeg; d++) buckets[d] = new ArrayDeque<>();
	    for (int v = 0; v < nM; v++) buckets[deg[v]].add(v);

	    int aliveEdges = mM;

	    // avoid duplicates in q (real ids)
	    boolean[] inQ = new boolean[NN];

	    // 5) Main loop: remove max-degree nodes until all middle edges eliminated
	    while (aliveEdges > 0) {

	        while (maxDeg > 0 && buckets[maxDeg].isEmpty()) maxDeg--;

	        int vStar = -1;
	        while (maxDeg > 0 && vStar == -1) {
	            while (!buckets[maxDeg].isEmpty()) {
	                int v = buckets[maxDeg].pollLast();
	                if (removedMid[v]) continue;
	                if (deg[v] != maxDeg) continue; // stale entry (lazy)
	                vStar = v;
	                break;
	            }
	            if (vStar == -1) {
	                while (maxDeg > 0 && buckets[maxDeg].isEmpty()) maxDeg--;
	            }
	        }

	        // fallback: pick any endpoint from an alive edge
	        if (vStar == -1) {
	            for (int e = 0; e < mM; e++) {
	                if (edgeAlive[e]) {
	                    vStar = eu[e];
	                    break;
	                }
	            }
	            if (vStar == -1) break;
	        }

	        removedMid[vStar] = true;

	        int realV = mid2real.get(vStar);
	        if (!inQ[realV]) { inQ[realV] = true; q.add(realV); }

	        // delete all incident alive edges and update neighbor degrees
	        int[] incEdges = inc[vStar];
	        for (int idx = 0; idx < incEdges.length; idx++) {
	            int e = incEdges[idx];
	            if (!edgeAlive[e]) continue;

	            edgeAlive[e] = false;
	            aliveEdges--;

	            int a = eu[e], b = ev[e];
	            int other = (a == vStar ? b : a);
	            if (removedMid[other]) continue;

	            deg[other]--;
	            buckets[deg[other]].add(other); // push to new bucket (lazy)
	        }
	    }

	    return q;
	}
	
	public static void N_q_Set_Forward_Minimal() {
		for (int od=0;od<CODSet.ODSet.size();od++) {
			ArrayList<Integer> q_node_cut=(ArrayList<Integer>) CODSet.ODSet.get(od).nodes_set_forward.clone();
			for (int i=0;i<q_node_cut.size();i++) {
				int node=q_node_cut.get(i);
				q_node_cut.remove(i);
				ArrayList<Integer> opencs=CGetLength.QuFan(q_node_cut, od);
				boolean isfeasible = CGetLength.Run(opencs, od);
				if (isfeasible==true) {
					q_node_cut.add(i, node);
					continue;
				}else {
					i--;
				}
			}
			CODSet.ODSet.get(od).nodes_set_forward=(ArrayList<Integer>) q_node_cut.clone();
		}
	}
	
	public static void N_q_Set_Backward_Minimal() {
		for (int od=0;od<CODSet.ODSet.size();od++) {
			ArrayList<Integer> q_node_cut=(ArrayList<Integer>) CODSet.ODSet.get(od).nodes_set_backward.clone();
			for (int i=0;i<q_node_cut.size();i++) {
				int node=q_node_cut.get(i);
				q_node_cut.remove(i);
				ArrayList<Integer> opencs=CGetLength.QuFan(q_node_cut, od);
				boolean isfeasible = CGetLength.Run(opencs, od);
				if (isfeasible==true) {
					q_node_cut.add(i, node);
					continue;
				}else {
					i--;
				}
			}
			CODSet.ODSet.get(od).nodes_set_backward=(ArrayList<Integer>) q_node_cut.clone();
		}
	}
	
	public static void N_q_Set_Middle_Minimal() {
		for (int od=0;od<CODSet.ODSet.size();od++) {
			ArrayList<Integer> q_node_cut=(ArrayList<Integer>) CODSet.ODSet.get(od).nodes_set_middle.clone();
			for (int i=0;i<q_node_cut.size();i++) {
				int node=q_node_cut.get(i);
				q_node_cut.remove(i);
				ArrayList<Integer> opencs=CGetLength.QuFan(q_node_cut, od);
				boolean isfeasible = CGetLength.Run(opencs, od);
				if (isfeasible==true) {
					q_node_cut.add(i, node);
					continue;
				}else {
					i--;
				}
			}
			CODSet.ODSet.get(od).nodes_set_middle=(ArrayList<Integer>) q_node_cut.clone();
		}
	}

}
