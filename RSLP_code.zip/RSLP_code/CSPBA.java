package weiquanmax;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.PriorityQueue;

public class CSPBA {

    public ArrayList<Integer> zero_weight_nodelist = new ArrayList<Integer>();

    // Best original weight found by SPBA. This weight does NOT include any epsilon perturbation.
    public double min_wt = Double.POSITIVE_INFINITY;

    // Best length-bounded cut found by SPBA.
    public ArrayList<Integer> final_lb_cut_nodelist = new ArrayList<Integer>();

    // Optional statistics for debugging.
    public int explored_nodes = 0;
    public int pruned_by_weight = 0;
    public int leaf_nodes = 0;

    // Time-limit control. Default: 0.01 seconds.
    public double time_limit_sec = 0.01;
    public boolean time_limit_reached = false;

    private long start_time_nano = 0L;
    private long time_limit_nano = 10_000_000L; // 0.01 seconds

    private int cur_od = -1;
    private int O = -1;
    private int D = -1;
    private double[] value_x;
    private double length_bound;

    private static final double ZERO_TOL = 1e-9;
    private static final double WEIGHT_EPS = 1e-9;
    private static final double DIST_EPS = 0.01;

    private static class SPArc {
        int to;
        double len;

        SPArc(int to, double len) {
            this.to = to;
            this.len = len;
        }
    }

    private static class State implements Comparable<State> {
        int id;
        double dist;

        State(int id, double dist) {
            this.id = id;
            this.dist = dist;
        }

        @Override
        public int compareTo(State other) {
            return Double.compare(this.dist, other.dist);
        }
    }

    private static class ShortestPathResult {
        boolean feasible;
        double length;
        ArrayList<Integer> path;

        ShortestPathResult(boolean feasible, double length, ArrayList<Integer> path) {
            this.feasible = feasible;
            this.length = length;
            this.path = path;
        }
    }

    public void Init() {
        zero_weight_nodelist.clear();
        final_lb_cut_nodelist.clear();
        min_wt = Double.POSITIVE_INFINITY;
        explored_nodes = 0;
        pruned_by_weight = 0;
        leaf_nodes = 0;

        time_limit_sec = 0.01;
        time_limit_reached = false;
        start_time_nano = 0L;
        time_limit_nano = 10_000_000L;

        cur_od = -1;
        O = -1;
        D = -1;
        value_x = null;
        length_bound = Double.POSITIVE_INFINITY;
    }

    public void SetTimeLimit(double seconds) {
        time_limit_sec = seconds;

        // If seconds <= 0, do not impose a time limit.
        if (seconds <= 0.0) {
            time_limit_nano = 0L;
        } else {
            time_limit_nano = Math.max(1L, (long) (seconds * 1_000_000_000L));
        }
    }

    private void StartTimer() {
        time_limit_reached = false;
        start_time_nano = System.nanoTime();
    }

    private boolean TimeOut() {
        if (time_limit_nano <= 0L) {
            return false;
        }

        if (System.nanoTime() - start_time_nano >= time_limit_nano) {
            time_limit_reached = true;
            return true;
        }

        return false;
    }

    /**
     * Run shortest path-branch algorithm for one OD pair with the default time limit.
     */
    public ArrayList<Integer> Run(int od, double[] value_x) {
        return Run(od, value_x, time_limit_sec);
    }

    /**
     * Run shortest path-branch algorithm for one OD pair.
     *
     * The algorithm first removes all zero-weight nodes. Then, while the remaining
     * round-trip network still contains a path whose length is within the length bound,
     * it branches by removing one node from the current shortest path.
     *
     * @return best LB cut node list. If no cut is found, this list is empty and
     *         min_wt remains Double.POSITIVE_INFINITY.
     */
    public ArrayList<Integer> Run(int od, double[] value_x, double max_seconds) {
        SetTimeLimit(max_seconds);
        StartTimer();

        this.cur_od = od;
        this.value_x = value_x;
        this.O = CODSet.ODSet.get(od).origin_node;
        this.D = CODSet.ODSet.get(od).destination_node;
        this.length_bound = CODSet.shortestdis[O][D] * (1.0 + CLBC.tolerence) + DIST_EPS;

        zero_weight_nodelist.clear();
        final_lb_cut_nodelist.clear();
        min_wt = Double.POSITIVE_INFINITY;

        ArrayList<Integer> remaining_nodes = RemoveZeroNodes(od, value_x);
        ArrayList<Integer> initial_cut = new ArrayList<Integer>(zero_weight_nodelist);
        double initial_weight = 0.0;

        if (!TimeOut()) {
            Branch(remaining_nodes, initial_cut, initial_weight);
        }

        // CSPBA only finds a min-weight LB cut.
        // Cardinality reduction is handled outside CSPBA.
        return final_lb_cut_nodelist;
    }

    public ArrayList<Integer> RemoveZeroNodes(int od, double[] value_x) {
        ArrayList<Integer> temp = new ArrayList<Integer>();
        zero_weight_nodelist.clear();

        for (int i = 0; i < CODSet.ODSet.get(od).nodes_set.size(); i++) {
            if (TimeOut()) return Unique(temp);

            int id = CODSet.ODSet.get(od).nodes_set.get(i);
            if (NodeWeight(id) > ZERO_TOL) {
                temp.add(id);
            } else {
                zero_weight_nodelist.add(id);
            }
        }
        return Unique(temp);
    }

    private void Branch(ArrayList<Integer> remaining_nodes,
                        ArrayList<Integer> partial_cut,
                        double partial_weight) {
        if (TimeOut()) {
            return;
        }

        explored_nodes++;

        if (partial_weight > min_wt + WEIGHT_EPS) {
            pruned_by_weight++;
            return;
        }

        ShortestPathResult sp = ShortestPath(remaining_nodes);

        if (TimeOut()) {
            return;
        }

        // No length-feasible path remains, so partial_cut is a valid LB cut.
        if (!sp.feasible) {
            leaf_nodes++;
            ArrayList<Integer> candidate = Unique(partial_cut);
            double candidate_weight = partial_weight;
            UpdateBest(candidate, candidate_weight);
            return;
        }

        // Should not happen in the current round-trip network, because there is no direct
        // source-to-sink arc. Still, keep this guard to avoid infinite recursion.
        if (sp.path.size() == 0) {
            return;
        }

        ArrayList<Integer> branch_nodes = new ArrayList<Integer>(sp.path);
        Collections.sort(branch_nodes, new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return Double.compare(NodeWeight(a), NodeWeight(b));
            }
        });

        for (int k = 0; k < branch_nodes.size(); k++) {
            if (TimeOut()) {
                return;
            }

            int node = branch_nodes.get(k);
            double new_weight = partial_weight + NodeWeight(node);

            if (new_weight > min_wt + WEIGHT_EPS) {
                pruned_by_weight++;
                continue;
            }

            ArrayList<Integer> new_remaining = new ArrayList<Integer>(remaining_nodes);
            int idx = new_remaining.indexOf(node);
            if (idx < 0) continue;
            new_remaining.remove(idx);

            ArrayList<Integer> new_cut = new ArrayList<Integer>(partial_cut);
            if (new_cut.indexOf(node) < 0) {
                new_cut.add(node);
            }

            Branch(new_remaining, new_cut, new_weight);
        }
    }

    /**
     * Dijkstra shortest path in the current round-trip network induced by remaining_nodes.
     * Virtual source uses half range to depart, virtual sink uses half range to arrive.
     */
    @SuppressWarnings("unchecked")
    private ShortestPathResult ShortestPath(ArrayList<Integer> remaining_nodes) {
        int n = remaining_nodes.size();
        int S = n;
        int T = n + 1;
        int total = n + 2;

        ArrayList<SPArc>[] graph = new ArrayList[total];
        for (int i = 0; i < total; i++) {
            graph[i] = new ArrayList<SPArc>();
        }

        double R = CLBC.EV_Range;

        for (int i = 0; i < n; i++) {
            if (TimeOut()) {
                return new ShortestPathResult(true, Double.POSITIVE_INFINITY, new ArrayList<Integer>());
            }

            int vi = remaining_nodes.get(i);

            if (CODSet.shortestdis[O][vi] <= R / 2.0 + DIST_EPS) {
                graph[S].add(new SPArc(i, CODSet.shortestdis[O][vi]));
            }

            if (CODSet.shortestdis[vi][D] <= R / 2.0 + DIST_EPS) {
                graph[i].add(new SPArc(T, CODSet.shortestdis[vi][D]));
            }

            for (int j = 0; j < n; j++) {
                if (TimeOut()) {
                    return new ShortestPathResult(true, Double.POSITIVE_INFINITY, new ArrayList<Integer>());
                }

                if (i == j) continue;
                int vj = remaining_nodes.get(j);
                if (CODSet.shortestdis[vi][vj] <= R + DIST_EPS) {
                    graph[i].add(new SPArc(j, CODSet.shortestdis[vi][vj]));
                }
            }
        }

        double[] dist = new double[total];
        int[] prev = new int[total];
        Arrays.fill(dist, Double.POSITIVE_INFINITY);
        Arrays.fill(prev, -1);

        PriorityQueue<State> pq = new PriorityQueue<State>();
        dist[S] = 0.0;
        pq.add(new State(S, 0.0));

        while (!pq.isEmpty()) {
            if (TimeOut()) {
                return new ShortestPathResult(true, Double.POSITIVE_INFINITY, new ArrayList<Integer>());
            }

            State cur = pq.poll();
            if (cur.dist > dist[cur.id] + DIST_EPS) continue;
            if (cur.id == T) break;

            for (int e = 0; e < graph[cur.id].size(); e++) {
                if (TimeOut()) {
                    return new ShortestPathResult(true, Double.POSITIVE_INFINITY, new ArrayList<Integer>());
                }

                SPArc arc = graph[cur.id].get(e);
                double nd = cur.dist + arc.len;
                if (nd + DIST_EPS < dist[arc.to]) {
                    dist[arc.to] = nd;
                    prev[arc.to] = cur.id;
                    pq.add(new State(arc.to, nd));
                }
            }
        }

        if (dist[T] > length_bound) {
            return new ShortestPathResult(false, dist[T], new ArrayList<Integer>());
        }

        ArrayList<Integer> path = new ArrayList<Integer>();
        int cur = T;
        while (prev[cur] != -1) {
            if (TimeOut()) {
                return new ShortestPathResult(true, Double.POSITIVE_INFINITY, new ArrayList<Integer>());
            }

            int p = prev[cur];
            if (cur >= 0 && cur < n) {
                path.add(remaining_nodes.get(cur));
            }
            cur = p;
        }
        Collections.reverse(path);

        return new ShortestPathResult(true, dist[T], path);
    }

    private void UpdateBest(ArrayList<Integer> candidate, double candidate_weight) {
        if (candidate_weight < min_wt - WEIGHT_EPS) {
            min_wt = candidate_weight;
            final_lb_cut_nodelist = new ArrayList<Integer>(candidate);
            return;
        }

        if (Math.abs(candidate_weight - min_wt) <= WEIGHT_EPS) {
            if (final_lb_cut_nodelist.size() == 0 || candidate.size() < final_lb_cut_nodelist.size()) {
                final_lb_cut_nodelist = new ArrayList<Integer>(candidate);
            }
        }
    }

    private double ComputeWeight(ArrayList<Integer> nodes) {
        double sum = 0.0;
        for (int i = 0; i < nodes.size(); i++) {
            sum += NodeWeight(nodes.get(i));
        }
        return sum;
    }

    private double NodeWeight(int node) {
        if (value_x == null || node < 0 || node >= value_x.length) return 0.0;
        return Math.max(0.0, value_x[node]);
    }

    private ArrayList<Integer> Unique(ArrayList<Integer> list) {
        return new ArrayList<Integer>(new LinkedHashSet<Integer>(list));
    }
}
