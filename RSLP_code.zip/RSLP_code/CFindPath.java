package weiquanmax;

import java.util.ArrayList;

public class CFindPath {
	
	public static ArrayList<Integer> GetQNodes(ArrayList<Integer> nodeset,ArrayList<Integer> openCS){
		ArrayList<Integer> temp=(ArrayList<Integer>) nodeset.clone();
		for (int i=0;i<openCS.size();i++) {
			int id=openCS.get(i);
			int index=temp.indexOf(id);
			if (index>=0) {
				temp.remove(index);
			}
		}
		return temp;
	}

}
