package weiquanmax;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class CMain {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		{
			//1-BE581;2-CA339;3-QC405;4-US420
			int networktype=Integer.parseInt(args[0]);
			int R_type=Integer.parseInt(args[1]);
			float tolerance=Float.parseFloat(args[2]);
			int p_type=Integer.parseInt(args[3]);
			
			int nn=-1;
			if (networktype==1) {
				nn=581;
			}else if (networktype==2) {
				nn=339;
			}else if (networktype==3) {
				nn=405;
			}else if (networktype==4) {
				nn=420;
			}
			
			CLBC.NN=nn;CODSet.NN=nn;CGetLength.NN=nn;CGRB.NN=nn;
			
			int p=-1;
			if (networktype==1|networktype==3|networktype==4) {
				p=p_type*10;
			}else if (networktype==2) {
				p=p_type*5;
			}
			
			String network="";
			if (networktype==1) {
				network="BE";
			}else if (networktype==2) {
				network="CA";
			}else if (networktype==3) {
				network="QC";
			}else if (networktype==4) {
				network="US";
			}
			
			int R=-1;
			if (networktype==1&R_type==1) {
				R=200;
			}else if (networktype==1&R_type==2) {
				R=250;
			}if (networktype==1&R_type==3) {
				R=300;
			}
			
			if (networktype==2&R_type==1) {
				R=100;
			}else if (networktype==2&R_type==2) {
				R=150;
			}if (networktype==2&R_type==3) {
				R=200;
			}
			
			if (networktype==3&R_type==1) {
				R=200;
			}else if (networktype==3&R_type==2) {
				R=300;
			}if (networktype==3&R_type==3) {
				R=400;
			}
			
			if (networktype==4&R_type==1) {
				R=300;
			}else if (networktype==4&R_type==2) {
				R=400;
			}if (networktype==4&R_type==3) {
				R=500;
			}
			
			String OD_file="/home/wwq/projects/def-adulyasa/wwq/weiquanmax/"+network+"_ODs.txt";
			String Shortest_file="/home/wwq/projects/def-adulyasa/wwq/weiquanmax/"+network+"_ShortestLength.txt";

			CODSet.Init(R,OD_file,Shortest_file);
			System.out.println(CODSet.ODSet.size()+"\t"+tolerance+"\t"+R+"\t"+p);
			CLBC.Run(R,tolerance,nn);
			
			CGRB mp=new CGRB ();
			mp.Init();
			mp.build_model(p);
			mp.solve();			
			mp.end();
//			
//			CSave.Run();
			
		}
	}
}
