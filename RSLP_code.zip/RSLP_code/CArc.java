package weiquanmax;

public class CArc {

	public int real_left=-1;
	public int real_right=-1;
	public float distance=-1;
	
	public void set(int l,int r,float d) {
		real_left=l;
		real_right=r;
		distance=d;
	}
}
