package weiquanmax;

import java.util.ArrayList;
import java.util.List;

public class CGetLength {
	public static int NN;

	public static boolean Run (ArrayList<Integer> openCS,int od) {
		float length=ComputeLength(openCS,od);
		int O=CODSet.ODSet.get(od).origin_node;
		int D=CODSet.ODSet.get(od).destination_node;
		float Max_LEN=(float) (CODSet.shortestdis[O][D]*(1+CLBC.tolerence)+0.01);
		if (length>Max_LEN)
			return false;
		return true;
	}
	
	public static boolean Run_Back (ArrayList<Integer> openCS,int od) {
		float length=ComputeLength_Back(openCS,od);
		int O=CODSet.ODSet.get(od).origin_node;
		int D=CODSet.ODSet.get(od).destination_node;
		float Max_LEN=(float) (CODSet.shortestdis[O][D]*(1+CLBC.tolerence)+0.01);
		if (length>Max_LEN)
			return false;
		return true;
	}
	
	public static float ComputeLength (ArrayList<Integer> openCS,int od) {
		int O=CODSet.ODSet.get(od).origin_node;
		int D=CODSet.ODSet.get(od).destination_node;
		float Max_LEN=(float) (CODSet.shortestdis[O][D]*(1+CLBC.tolerence)+0.01);
		float R=CLBC.EV_Range;
		
		//init connect nodes
		ArrayList<ArrayList<Integer>> connect_nodes=new ArrayList<>();
		for (int i=0;i<NN;i++) {
			ArrayList<Integer> temp=new ArrayList<Integer>();
			connect_nodes.add(temp);
		}
		for (int i=0;i<openCS.size();i++) {
			for (int j=0;j<openCS.size();j++) {
				if (i!=j) {
					int cs_i=openCS.get(i);
					int cs_j=openCS.get(j);
					if (CODSet.shortestdis[cs_i][cs_j]<=R) {
						connect_nodes.get(cs_i).add(cs_j);
					}
				}
			}
		}

		//init short length
		float []min_distance=new float[NN];
		for (int i=0;i<NN;i++) {
			if (i!=O)
				min_distance[i]=Float.POSITIVE_INFINITY;
		}
		
		ArrayList<CPartialPath> partial_path_set=new ArrayList<>();
		//add start path
		{
			ArrayList<CPartialPath> temp_path_set=new ArrayList<>();
			for (int i=0;i<openCS.size();i++) {
				int cs=openCS.get(i);
				if (CODSet.shortestdis[O][cs]<=R/2+0.01) {					
					CPartialPath cp=new CPartialPath();
					cp.path.add(cs);
					cp.length=CODSet.shortestdis[O][cs];
					min_distance[cs]=CODSet.shortestdis[O][cs];
					temp_path_set.add(cp);
				}
			}
			partial_path_set=(ArrayList<CPartialPath>) temp_path_set.clone();
		}
		//add other
		while(partial_path_set.size()>0) {
			//Go Home
			for (int i=0;i<partial_path_set.size();i++) {
				int last_pos=partial_path_set.get(i).path.size()-1;
				int last_cs=partial_path_set.get(i).path.get(last_pos);
				if (CODSet.shortestdis[last_cs][D]>R/2+0.01)
					continue;
				float whole_length=partial_path_set.get(i).length+CODSet.shortestdis[last_cs][D];
				if (whole_length>Max_LEN)
					continue;
				return whole_length;
			}
			//add other
			ArrayList<CPartialPath> temp_path_set=new ArrayList<>();
			for (int i=0;i<partial_path_set.size();i++) {
				int last_pos=partial_path_set.get(i).path.size()-1;
				int last_cs=partial_path_set.get(i).path.get(last_pos);
				for (int j=0;j<connect_nodes.get(last_cs).size();j++) {
					int next_cs=connect_nodes.get(last_cs).get(j);
					float whole_length=partial_path_set.get(i).length+CODSet.shortestdis[last_cs][next_cs];
					if (whole_length>Max_LEN)
						continue;
					if (whole_length>=min_distance[next_cs])
						continue;
					min_distance[next_cs]=whole_length;
					CPartialPath cp=new CPartialPath();
					cp.path=(ArrayList<Integer>) partial_path_set.get(i).path.clone();
					cp.path.add(next_cs);
					cp.length=whole_length;
					temp_path_set.add(cp);
				}
			}
			partial_path_set=(ArrayList<CPartialPath>) temp_path_set.clone();
		}
		return Float.POSITIVE_INFINITY;
	}
	
	public static float ComputeLength_Back (ArrayList<Integer> openCS,int od) {
		int O=CODSet.ODSet.get(od).origin_node;
		int D=CODSet.ODSet.get(od).destination_node;
		float Max_LEN=(float) (CODSet.shortestdis[O][D]*(1+CLBC.tolerence)+0.01);
		float R=CLBC.EV_Range;
		
		//init connect nodes
		ArrayList<ArrayList<Integer>> connect_nodes=new ArrayList<>();
		for (int i=0;i<NN;i++) {
			ArrayList<Integer> temp=new ArrayList<Integer>();
			connect_nodes.add(temp);
		}
		for (int i=0;i<openCS.size();i++) {
			for (int j=0;j<openCS.size();j++) {
				if (i!=j) {
					int cs_i=openCS.get(i);
					int cs_j=openCS.get(j);
					if (CODSet.shortestdis[cs_i][cs_j]<=R) {
						connect_nodes.get(cs_i).add(cs_j);
					}
				}
			}
		}
		

		//init short length
		float []min_distance=new float[NN];
		for (int i=0;i<NN;i++) {
			if (i!=O)
				min_distance[i]=Float.POSITIVE_INFINITY;
		}
		
		ArrayList<CPartialPath> partial_path_set=new ArrayList<>();
		//add start path
		{
			ArrayList<CPartialPath> temp_path_set=new ArrayList<>();
			for (int i=0;i<openCS.size();i++) {
				int cs=openCS.get(i);
				if (CODSet.shortestdis[O][cs]<=R/2+0.01) {					
					CPartialPath cp=new CPartialPath();
					cp.path.add(cs);
					cp.length=CODSet.shortestdis[O][cs];
					min_distance[cs]=CODSet.shortestdis[O][cs];
					temp_path_set.add(cp);
				}
			}
			partial_path_set=(ArrayList<CPartialPath>) temp_path_set.clone();
		}
		//add other
		while(partial_path_set.size()>0) {
			//Go Home
			for (int i=0;i<partial_path_set.size();i++) {
				int last_pos=partial_path_set.get(i).path.size()-1;
				int last_cs=partial_path_set.get(i).path.get(last_pos);
				if (CODSet.shortestdis[last_cs][D]>R/2+0.01)
					continue;
				float whole_length=partial_path_set.get(i).length+CODSet.shortestdis[last_cs][D];
				if (whole_length>Max_LEN)
					continue;
				return whole_length;
			}
			//add other
			ArrayList<CPartialPath> temp_path_set=new ArrayList<>();
			for (int i=0;i<partial_path_set.size();i++) {
				int last_pos=partial_path_set.get(i).path.size()-1;
				int last_cs=partial_path_set.get(i).path.get(last_pos);
				for (int j=0;j<connect_nodes.get(last_cs).size();j++) {
					int next_cs=connect_nodes.get(last_cs).get(j);
					float whole_length=partial_path_set.get(i).length+CODSet.shortestdis[last_cs][next_cs];
					if (whole_length>Max_LEN)
						continue;
					if (whole_length>=min_distance[next_cs])
						continue;
					min_distance[next_cs]=whole_length;
					CPartialPath cp=new CPartialPath();
					cp.path=(ArrayList<Integer>) partial_path_set.get(i).path.clone();
					cp.path.add(next_cs);
					cp.length=whole_length;
					temp_path_set.add(cp);
				}
			}
			partial_path_set=(ArrayList<CPartialPath>) temp_path_set.clone();
		}
		return Float.POSITIVE_INFINITY;
	}
	
	public static ArrayList<Integer> Filter (ArrayList<Integer> openCS,int od) {
		ArrayList<Integer> temp=new ArrayList<Integer>();
		for (int i=0;i<openCS.size();i++) {
			int cs=openCS.get(i);
			if (CODSet.ODSet.get(od).nodes_set.indexOf(cs)>=0) {
				temp.add(cs);
			}
		}
		return temp;
	}
	
	public static ArrayList<Integer> QuFan (ArrayList<Integer> openCS,int od) {
		ArrayList<Integer> temp=(ArrayList<Integer>) CODSet.ODSet.get(od).nodes_set.clone();
		for (int i=0;i<openCS.size();i++) {
			int node=openCS.get(i);
			int index=temp.indexOf(node);
			temp.remove(index);
		}
		return temp;
	}
}
