package weiquanmax;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class CODSet {
	public static int NN;
	public static float[][]shortestdis;
	public static ArrayList<CODPair> ODSet=new ArrayList<>();
	public static int total_path_num;
	public static float EV_Range;
	
	public static void Init(float R,String OD_file,String Length_file) {
		EV_Range=R;
		ODSet.clear();
		total_path_num=0;
		shortestdis=new float[NN][NN];
		LoadLength(Length_file);
		LoadOD(OD_file);
	}
	
	
	public static void LoadOD(String OD_file) {
		try {
			File file = new File(OD_file);
			FileReader fred = new FileReader(file);
			@SuppressWarnings("resource")
			BufferedReader bfred = new BufferedReader(fred);
			String temp = "";

			//init 
			float sum_flow=0;
			while (null != (temp = bfred.readLine())) {		
				temp=temp.replaceAll("\\s", ",");
				String[] newArr = temp.split(",");
				int head_node=Integer.parseInt(newArr[0]);
				int tail_node=Integer.parseInt(newArr[1]);				
				double flow=Double.parseDouble(newArr[2]);
				
//				if (shortestdis[head_node][tail_node]<EV_Range/2)
//					continue;
//				if (shortestdis[head_node][tail_node]>500)
//					continue;
				
				CODPair od=new CODPair();
				od.origin_node=head_node;
				od.destination_node=tail_node;
				od.flow=flow;
				ODSet.add(od);		
				sum_flow+=flow;
			}
			
			for (int od=0;od<ODSet.size();od++) {
				ODSet.get(od).flow=100*ODSet.get(od).flow/sum_flow;
			}
		} catch (Exception e) {
			System.out.print(e.toString());
		}
	}
	
	public static void LoadLength(String s) {
		try {
			File file = new File(s);
			FileReader fred = new FileReader(file);
			@SuppressWarnings("resource")
			BufferedReader bfred = new BufferedReader(fred);
			String temp = "";

			while (null != (temp = bfred.readLine())) {		
				temp=temp.replaceAll("\\s", ";");
				String[] newArr = temp.split(",");
				int i=Integer.parseInt(newArr[0]);
				int j=Integer.parseInt(newArr[1]);
				float distance=Float.parseFloat(newArr[2]);
				shortestdis[i][j]=distance;
			}
		} catch (Exception e) {
			System.out.print(e.toString());
		}
	}
}
