package weiquanmax;

import java.util.ArrayList;

public class CPath {

	public int real_left=-1;
	public int real_right=-1;
	public int var_p=-1;
	public ArrayList<Integer> path;
	public float length;
}
