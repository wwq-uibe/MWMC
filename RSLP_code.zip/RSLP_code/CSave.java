package weiquanmax;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class CSave {

	public static void Run() {		
		remove();
		System.out.println(CMyCB.Total_LBT_List.size());
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("total_lbt.txt"))) {

            for (int i = 0; i < CMyCB.Total_LBT_List.size(); i++) {
                for (int j = 0; j < CMyCB.Total_LBT_List.get(i).size(); j++) {
                    bw.write(CMyCB.Total_LBT_List.get(i).get(j) + ",");
                }
                bw.newLine();
            }

            // 可选：显式 flush 一下也行
            bw.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
	public static void remove () {
		for (int i=0;i< CMyCB.Total_LBT_List.size()-1; i++) {
			for (int j=i+1;j< CMyCB.Total_LBT_List.size(); j++) {
				boolean isequal=true;
				if (CMyCB.Total_LBT_List.get(i).size()==CMyCB.Total_LBT_List.get(j).size()) {
					if (CMyCB.Total_LBT_List.get(i).get(0)==CMyCB.Total_LBT_List.get(j).get(0)) {
						ArrayList<Integer> q_i=(ArrayList<Integer>) CMyCB.Total_LBT_List.get(i).clone();
						ArrayList<Integer> q_j=(ArrayList<Integer>) CMyCB.Total_LBT_List.get(j).clone();
						q_i.remove(0);
						q_j.remove(0);
						for (int k=0;k<q_i.size();k++) {
							int node=q_i.get(k);
							if (q_j.indexOf(node)<0) {
								isequal=false;
								break;
							}
						}
						if (isequal==true) {
							CMyCB.Total_LBT_List.remove(i);
							i--;
							break;
						}
					}
				}
			}
		}
	}
}
