package weiquanmax;

import java.util.ArrayList;

public class CPartialPath {

	public ArrayList<Integer> path=new ArrayList<Integer>();
	public float length;
}
