package weiquanmax;

import java.util.ArrayList;

public class CODPair {

	public int origin_node;
	public int destination_node;
	public double flow;
	public ArrayList<Integer> nodes_set=new ArrayList<Integer>();
	public ArrayList<Integer> nodes_set_forward=new ArrayList<Integer>();
	public ArrayList<Integer> nodes_set_backward=new ArrayList<Integer>();
	public ArrayList<Integer> nodes_set_middle=new ArrayList<Integer>();
	public ArrayList<Integer> feasible_node=new ArrayList<Integer>();
	public ArrayList<Integer> nodes_LengthBound=new ArrayList<Integer>();
	public ArrayList<CPartialPath> path_set=new ArrayList<CPartialPath>();
	public int mincut_cardinality;
}
