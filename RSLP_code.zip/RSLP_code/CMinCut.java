package weiquanmax;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;

public class CMinCut {
    // wt is always the ORIGINAL min-cut weight: sum value_x[i] over selected real nodes.
    public static double wt = 0.0;

    // Optional: the perturbed weight used internally by the min-cut algorithm.
    // This equals sum max(value_x[i], ZERO_NODE_EPS) only for selected zero-weight nodes.
    public static double perturbed_wt = 0.0;

    public static ArrayList<Integer> mincut = new ArrayList<Integer>();

    private static final double EPS = 1e-9;
    private static final double DIST_EPS = 0.01;

    // Treat |value_x[i]| <= ZERO_TOL as zero in the fractional solution.
    private static final double ZERO_TOL = 1e-9;

    // Epsilon capacity assigned to zero-weight nodes when computing min-cut.
    // Keep this small. If needed, you can tune it to 1e-7 or 1e-8.
    private static final double ZERO_NODE_EPS = 1e-6;

    private static ArrayList<Edge>[] graph;
    private static int[] level;
    private static int[] iter;

    private static class Edge {
        int to;
        int rev;
        double cap;

        Edge(int to, int rev, double cap) {
            this.to = to;
            this.rev = rev;
            this.cap = cap;
        }
    }

    @SuppressWarnings("unchecked")
    private static void initGraph(int n) {
        graph = new ArrayList[n];
        for (int i = 0; i < n; i++) {
            graph[i] = new ArrayList<Edge>();
        }
        level = new int[n];
        iter = new int[n];
    }

    private static void addEdge(int from, int to, double cap) {
        Edge fwd = new Edge(to, graph[to].size(), cap);
        Edge rev = new Edge(from, graph[from].size(), 0.0);
        graph[from].add(fwd);
        graph[to].add(rev);
    }

    private static boolean bfs(int s, int t) {
        Arrays.fill(level, -1);
        ArrayDeque<Integer> q = new ArrayDeque<Integer>();
        level[s] = 0;
        q.add(s);

        while (!q.isEmpty()) {
            int v = q.poll();
            for (Edge e : graph[v]) {
                if (e.cap > EPS && level[e.to] < 0) {
                    level[e.to] = level[v] + 1;
                    if (e.to == t) return true;
                    q.add(e.to);
                }
            }
        }
        return level[t] >= 0;
    }

    private static double dfs(int v, int t, double f) {
        if (v == t) return f;

        for (; iter[v] < graph[v].size(); iter[v]++) {
            Edge e = graph[v].get(iter[v]);
            if (e.cap <= EPS || level[e.to] != level[v] + 1) continue;

            double pushed = dfs(e.to, t, Math.min(f, e.cap));
            if (pushed > EPS) {
                e.cap -= pushed;
                graph[e.to].get(e.rev).cap += pushed;
                return pushed;
            }
        }
        return 0.0;
    }

    private static double maxFlow(int s, int t, double inf) {
        double flow = 0.0;
        while (bfs(s, t)) {
            Arrays.fill(iter, 0);
            while (true) {
                double pushed = dfs(s, t, inf);
                if (pushed <= EPS) break;
                flow += pushed;
            }
        }
        return flow;
    }

    private static boolean[] residualReachable(int s) {
        boolean[] visited = new boolean[graph.length];
        ArrayDeque<Integer> q = new ArrayDeque<Integer>();
        visited[s] = true;
        q.add(s);

        while (!q.isEmpty()) {
            int v = q.poll();
            for (Edge e : graph[v]) {
                if (e.cap > EPS && !visited[e.to]) {
                    visited[e.to] = true;
                    q.add(e.to);
                }
            }
        }
        return visited;
    }

    private static boolean hasPathInRoundTripNetwork(int O, int D, ArrayList<Integer> nodes) {
        int n = nodes.size();
        boolean[] visited = new boolean[n];
        ArrayDeque<Integer> q = new ArrayDeque<Integer>();
        double R = CLBC.EV_Range;

        for (int i = 0; i < n; i++) {
            int v = nodes.get(i);
            if (CODSet.shortestdis[O][v] <= R / 2.0 + DIST_EPS) {
                visited[i] = true;
                q.add(i);
            }
        }

        while (!q.isEmpty()) {
            int i = q.poll();
            int v = nodes.get(i);

            if (CODSet.shortestdis[v][D] <= R / 2.0 + DIST_EPS) {
                return true;
            }

            for (int j = 0; j < n; j++) {
                if (visited[j] || i == j) continue;
                int u = nodes.get(j);
                if (CODSet.shortestdis[v][u] <= R + DIST_EPS) {
                    visited[j] = true;
                    q.add(j);
                }
            }
        }
        return false;
    }

    private static double originalWeight(int realNode, double[] value_x) {
        if (realNode < 0 || realNode >= value_x.length) return 0.0;
        return Math.max(0.0, value_x[realNode]);
    }

    private static double capacityUsedInMinCut(int realNode, double[] value_x) {
        double w = originalWeight(realNode, value_x);
        if (w <= ZERO_TOL) return ZERO_NODE_EPS;
        return w;
    }

    /**
     * Compute a minimum-weight node cut in the round-trip network for OD=(O,D).
     *
     * Round-trip network:
     *   source -> i       if dist(O,i) <= R/2
     *   i -> j            if dist(i,j) <= R
     *   i -> sink         if dist(i,D) <= R/2
     *
     * Important:
     *   - The algorithm uses epsilon capacity for zero-weight nodes to prefer fewer
     *     zero-weight nodes among otherwise equivalent cuts.
     *   - The returned wt is still the original weight, i.e., sum value_x[i].
     */
    public static void Run(int O, int D, ArrayList<Integer> nodeset, double[] value_x) {
        wt = 0.0;
        perturbed_wt = 0.0;
        mincut.clear();

        if (nodeset == null || nodeset.size() == 0) {
            return;
        }

        // Remove duplicate node ids, if any, while keeping the original order.
        ArrayList<Integer> nodes = new ArrayList<Integer>(new LinkedHashSet<Integer>(nodeset));
        int n = nodes.size();

        // If even the full round-trip network has no O-D path, the empty cut is valid.
        if (!hasPathInRoundTripNetwork(O, D, nodes)) {
            return;
        }

        int S = 2 * n;
        int T = 2 * n + 1;
        int totalNodes = 2 * n + 2;

        double finiteCapSum = 0.0;
        for (int realNode : nodes) {
            finiteCapSum += capacityUsedInMinCut(realNode, value_x);
        }
        double INF = Math.max(1.0, finiteCapSum + 1.0);

        initGraph(totalNodes);

        double R = CLBC.EV_Range;

        // Split each real node i into i_in -> i_out.
        // Use perturbed capacity here, not the original weight.
        for (int i = 0; i < n; i++) {
            int realNode = nodes.get(i);
            double cap = capacityUsedInMinCut(realNode, value_x);
            addEdge(2 * i, 2 * i + 1, cap);
        }

        // Virtual source/sink arcs and range-feasible arcs among charging nodes.
        for (int i = 0; i < n; i++) {
            int vi = nodes.get(i);

            if (CODSet.shortestdis[O][vi] <= R / 2.0 + DIST_EPS) {
                addEdge(S, 2 * i, INF);
            }
            if (CODSet.shortestdis[vi][D] <= R / 2.0 + DIST_EPS) {
                addEdge(2 * i + 1, T, INF);
            }

            for (int j = 0; j < n; j++) {
                if (i == j) continue;
                int vj = nodes.get(j);
                if (CODSet.shortestdis[vi][vj] <= R + DIST_EPS) {
                    addEdge(2 * i + 1, 2 * j, INF);
                }
            }
        }

        maxFlow(S, T, INF);

        boolean[] reach = residualReachable(S);

        // A real node is in the min node cut if v_in is reachable but v_out is not.
        for (int i = 0; i < n; i++) {
            int in = 2 * i;
            int out = 2 * i + 1;
            if (reach[in] && !reach[out]) {
                int realNode = nodes.get(i);
                mincut.add(realNode);

                // Output original data, not epsilon-perturbed data.
                wt += originalWeight(realNode, value_x);
                perturbed_wt += capacityUsedInMinCut(realNode, value_x);
            }
        }
    }
}
