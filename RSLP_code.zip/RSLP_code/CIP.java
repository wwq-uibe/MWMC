package weiquanmax;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

public class CIP {
	int cur_od=-1;
	ArrayList<Integer> N_k=new ArrayList<Integer> ();
	GRBEnv env;
	GRBModel model;	
	
	GRBVar[] u;
	GRBVar[] pi;
	
	double pi_t=0;
	GRBVar pi_s;

	public void Init() throws GRBException {
		env = new GRBEnv(true);
		env.set("logFile", "knapsack.log");
		env.set(GRB.IntParam.OutputFlag, 0);
        env.start();
        
        model = new GRBModel(env);
        model.set(GRB.DoubleParam.TimeLimit, 3600.0);
	}
	
	public void build_model(int od,ArrayList<Integer> nodeset) throws GRBException {
		cur_od=od;
		N_k=(ArrayList<Integer>) nodeset.clone();
		int O=CODSet.ODSet.get(od).origin_node;int D=CODSet.ODSet.get(od).destination_node;
		pi_s=model.addVar(0, GRB.INFINITY,0, GRB.CONTINUOUS, "pi_s");
		
		double M=CODSet.shortestdis[O][D]*(1+CLBC.tolerence)*1.5;
		//CODSet.shortestdis[O][D]*(1+CLBC.tolerence)+0.01;
		
		u=new GRBVar[nodeset.size()];
	    pi=new GRBVar[nodeset.size()];
	    for (int i=0;i<nodeset.size();i++) {
	    	u[i]=model.addVar(0, 1,0, GRB.BINARY, "u" + i);
	    	pi[i]=model.addVar(0, GRB.INFINITY,0, GRB.CONTINUOUS, "pi" + i);
	    }
	    //constraints
	    //pi_s
	    model.addConstr(CODSet.shortestdis[O][D]*(1+CLBC.tolerence)+0.01, GRB.LESS_EQUAL, pi_s, null);
	    
	    int tempk=0;
	    //node to node
	    for (int i=0;i<nodeset.size();i++) {
	    	int real_cs_i=nodeset.get(i);
	    	for (int j=0;j<nodeset.size();j++) {
	    		if (i!=j) {
	    			int real_cs_j=nodeset.get(j);
	    			if (CODSet.shortestdis[real_cs_i][real_cs_j]<=CLBC.EV_Range) {
	    				GRBLinExpr temp = new GRBLinExpr();
	    				temp.addTerm(1.0, pi[i]);
	    				temp.addTerm(-1.0, pi[j]);
	    				temp.addConstant(-CODSet.shortestdis[real_cs_i][real_cs_j]);
	    				temp.addTerm(-M, u[j]);
	    				model.addConstr(temp, GRB.LESS_EQUAL, 0, null);
	    				tempk++;
	    			}
	    		}
	    	}
	    }
	    //s_k to node
	    for (int i=0;i<nodeset.size();i++) {
	    	int real_cs=nodeset.get(i);
	    	if (CODSet.shortestdis[O][real_cs]<=CLBC.EV_Range/2) {
	    		GRBLinExpr temp = new GRBLinExpr();
	    		temp.addTerm(1.0, pi_s);
	    		temp.addTerm(-1.0, pi[i]);
	    		temp.addConstant(-CODSet.shortestdis[O][real_cs]);
	    		temp.addTerm(-M, u[i]);
	    		model.addConstr(temp, GRB.LESS_EQUAL, 0, null);
	    		tempk++;
	    	}
	    }
	    //node to t_k
	    for (int i=0;i<nodeset.size();i++) {
	    	int real_cs=nodeset.get(i);
	    	if (CODSet.shortestdis[real_cs][D]<=CLBC.EV_Range/2) {
	    		GRBLinExpr temp = new GRBLinExpr();
	    		temp.addTerm(1.0, pi[i]);
	    		temp.addConstant(-CODSet.shortestdis[real_cs][D]);
	    		model.addConstr(temp, GRB.LESS_EQUAL, 0, null);
	    		tempk++;
	    	}
	    }
	    //maximize OBJ	    
	    GRBLinExpr obj = new GRBLinExpr();
	    for (int i=0;i<nodeset.size();i++) {
	    	obj.addTerm(1.0, u[i]);
	    }
	    model.setObjective(obj, GRB.MINIMIZE);
	}
	
	public void solve() throws GRBException {			
		model.optimize();
		
		ArrayList<Integer> remove_nodes=new ArrayList<Integer> ();
		for (int i=0;i<u.length;i++) {
			if (u[i].get(GRB.DoubleAttr.X)>0.5) {
				int node=N_k.get(i);
				remove_nodes.add(node);
			}
		}
		
		ArrayList<Integer> opencs=CGetLength.QuFan(remove_nodes, cur_od);
		boolean isfeasible=CGetLength.Run(opencs, cur_od);
		System.out.println(cur_od+"\t"+N_k.size()+"\t"+remove_nodes.size()+"\t"+model.get(GRB.DoubleAttr.Runtime)+"\t"+isfeasible);
	}
	
	public void end () throws GRBException {
		model.dispose();
        env.dispose();
	}
}
