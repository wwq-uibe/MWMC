package weiquanmax;

import java.util.ArrayList;
import java.util.LinkedHashSet;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

/**
 * Node-based min-weight length-bounded cut MIP for one OD pair.
 *
 * Input:  od, value_x
 * Output: wt, mincut
 *
 * Model:
 *   min sum_i x_i^* u_i
 *   pi_t = 0, u_t = 0
 *   pi_i <= pi_j + delta_ij + M u_j,  forall (i,j) in A_q
 *   pi_s >= lambda_q + eps
 *   pi_i >= 0
 *   u_i binary for real candidate nodes
 */
public class CMIPLB {

    // True original weight of the returned cut; does NOT include zero-node epsilon.
    public static double wt = Double.POSITIVE_INFINITY;

    // Perturbed objective value used by the MIP; mainly for debugging.
    public static double mip_obj = Double.POSITIVE_INFINITY;

    // Returned real node ids in the LB cut.
    public static ArrayList<Integer> mincut = new ArrayList<Integer>();

    // Status information.
    public static boolean cutFound = false;
    public static boolean optimal = false;
    public static boolean timeLimitReached = false;
    public static int status = -1;
    public static double runtime = 0.0;
    public static int solCount = 0;
    public static int arcCount = 0;

    // Default settings.
    public static double defaultTimeLimitSec = 0.01;
    public static boolean useZeroWeightEpsilon = false;
    public static boolean checkCutValidity = true;

    private static final double ZERO_TOL = 1e-9;
    private static final double ZERO_NODE_EPS = 1e-6;
    private static final double DIST_EPS = 0.01;
    private static final double STRICT_EPS = 1e-6;

    public static ArrayList<Integer> Run(int od, double[] value_x) {
        return Run(od, value_x, defaultTimeLimitSec);
    }

    public static ArrayList<Integer> Run(int od, double[] value_x, double timeLimitSec) {
        Reset();

        GRBEnv env = null;
        GRBModel model = null;

        try {
            int O = CODSet.ODSet.get(od).origin_node;
            int D = CODSet.ODSet.get(od).destination_node;
            double R = CLBC.EV_Range;
            double lengthBound = CODSet.shortestdis[O][D] * (1.0 + CLBC.tolerence) + DIST_EPS;
            double M = 2.0 * lengthBound + R + 1.0;

            ArrayList<Integer> nodes = Unique(CODSet.ODSet.get(od).nodes_set);
            int n = nodes.size();

            // If there are no candidate nodes, the empty cut is valid in the current
            // station-based round-trip network representation.
            if (n == 0) {
                wt = 0.0;
                mip_obj = 0.0;
                cutFound = true;
                optimal = true;
                return mincut;
            }

            env = new GRBEnv(true);
            env.set(GRB.IntParam.OutputFlag, 0);
            env.start();

            model = new GRBModel(env);
            if (timeLimitSec > 0.0) {
                model.set(GRB.DoubleParam.TimeLimit, timeLimitSec);
            }
            model.set(GRB.IntParam.OutputFlag, 0);
            model.set(GRB.IntParam.Threads, 1);

            int S = n;
            int T = n + 1;
            int total = n + 2;

            GRBVar[] u = new GRBVar[n];
            GRBVar[] pi = new GRBVar[total];

            for (int i = 0; i < n; i++) {
                int realNode = nodes.get(i);
                u[i] = model.addVar(0.0, 1.0, 0.0, GRB.BINARY, "u_" + realNode);
                pi[i] = model.addVar(0.0, GRB.INFINITY, 0.0, GRB.CONTINUOUS, "pi_" + realNode);
            }
            pi[S] = model.addVar(0.0, GRB.INFINITY, 0.0, GRB.CONTINUOUS, "pi_s");
            pi[T] = model.addVar(0.0, 0.0, 0.0, GRB.CONTINUOUS, "pi_t");

            // Objective: min sum_i x_i^* u_i. Optionally perturb zero-weight nodes.
            GRBLinExpr obj = new GRBLinExpr();
            for (int i = 0; i < n; i++) {
                int realNode = nodes.get(i);
                obj.addTerm(ObjectiveWeight(realNode, value_x), u[i]);
            }
            model.setObjective(obj, GRB.MINIMIZE);

            // pi_s >= lambda_q + eps.
            model.addConstr(pi[S], GRB.GREATER_EQUAL, lengthBound + STRICT_EPS, "length_bound");

            // Source arcs: (s_q, i), if d(O,i) <= R/2.
            for (int i = 0; i < n; i++) {
                int vi = nodes.get(i);
                double dij = CODSet.shortestdis[O][vi];
                if (dij <= R / 2.0 + DIST_EPS) {
                    // pi_s <= pi_i + d(O,i) + M u_i
                    GRBLinExpr expr = new GRBLinExpr();
                    expr.addTerm(1.0, pi[S]);
                    expr.addTerm(-1.0, pi[i]);
                    expr.addTerm(-M, u[i]);
                    model.addConstr(expr, GRB.LESS_EQUAL, dij, "arc_s_" + vi);
                    arcCount++;
                }
            }

            // Middle arcs: (i,j), if d(i,j) <= R.
            for (int i = 0; i < n; i++) {
                int vi = nodes.get(i);
                for (int j = 0; j < n; j++) {
                    if (i == j) continue;
                    int vj = nodes.get(j);
                    double dij = CODSet.shortestdis[vi][vj];
                    if (dij <= R + DIST_EPS) {
                        // pi_i <= pi_j + d(i,j) + M u_j
                        GRBLinExpr expr = new GRBLinExpr();
                        expr.addTerm(1.0, pi[i]);
                        expr.addTerm(-1.0, pi[j]);
                        expr.addTerm(-M, u[j]);
                        model.addConstr(expr, GRB.LESS_EQUAL, dij, "arc_" + vi + "_" + vj);
                        arcCount++;
                    }
                }
            }

            // Sink arcs: (i,t_q), if d(i,D) <= R/2. Since u_t = 0 and pi_t = 0,
            // this is pi_i <= d(i,D).
            for (int i = 0; i < n; i++) {
                int vi = nodes.get(i);
                double dij = CODSet.shortestdis[vi][D];
                if (dij <= R / 2.0 + DIST_EPS) {
                    GRBLinExpr expr = new GRBLinExpr();
                    expr.addTerm(1.0, pi[i]);
                    expr.addTerm(-1.0, pi[T]);
                    model.addConstr(expr, GRB.LESS_EQUAL, dij, "arc_" + vi + "_t");
                    arcCount++;
                }
            }

            model.optimize();

            status = model.get(GRB.IntAttr.Status);
            solCount = model.get(GRB.IntAttr.SolCount);
            runtime = model.get(GRB.DoubleAttr.Runtime);
            optimal = (status == GRB.Status.OPTIMAL);
            timeLimitReached = (status == GRB.Status.TIME_LIMIT);

            if (solCount <= 0) {
                return mincut;
            }

            for (int i = 0; i < n; i++) {
                if (u[i].get(GRB.DoubleAttr.X) > 0.5) {
                    mincut.add(nodes.get(i));
                }
            }

            wt = ComputeTrueWeight(mincut, value_x);
            mip_obj = model.get(GRB.DoubleAttr.ObjVal);

            if (checkCutValidity) {
                cutFound = ValidateCut(od, mincut);
                if (!cutFound) {
                    mincut.clear();
                    wt = Double.POSITIVE_INFINITY;
                    mip_obj = Double.POSITIVE_INFINITY;
                }
            } else {
                cutFound = true;
            }

        } catch (GRBException e) {
            System.err.println("CMIPLB error: code=" + e.getErrorCode() + ", msg=" + e.getMessage());
            Reset();
        } catch (Exception e) {
            System.err.println("CMIPLB error: " + e.getMessage());
            Reset();
        } finally {
            try {
                if (model != null) model.dispose();
                if (env != null) env.dispose();
            } catch (GRBException e) {
                System.err.println("CMIPLB dispose error: " + e.getMessage());
            }
        }

        return mincut;
    }

    private static void Reset() {
        wt = Double.POSITIVE_INFINITY;
        mip_obj = Double.POSITIVE_INFINITY;
        mincut.clear();
        cutFound = false;
        optimal = false;
        timeLimitReached = false;
        status = -1;
        runtime = 0.0;
        solCount = 0;
        arcCount = 0;
    }

    private static double ObjectiveWeight(int node, double[] value_x) {
        double w = TrueWeight(node, value_x);
        if (useZeroWeightEpsilon && w <= ZERO_TOL) {
            return ZERO_NODE_EPS;
        }
        return w;
    }

    private static double TrueWeight(int node, double[] value_x) {
        if (value_x == null || node < 0 || node >= value_x.length) {
            return 0.0;
        }
        return Math.max(0.0, value_x[node]);
    }

    private static double ComputeTrueWeight(ArrayList<Integer> nodes, double[] value_x) {
        double sum = 0.0;
        for (int i = 0; i < nodes.size(); i++) {
            sum += TrueWeight(nodes.get(i), value_x);
        }
        return sum;
    }

    private static boolean ValidateCut(int od, ArrayList<Integer> cut) {
        ArrayList<Integer> remainingNodes = CGetLength.QuFan(cut, od);
        // If remainingNodes still admits a length-feasible path, this is not a valid LB cut.
        return !CGetLength.Run(remainingNodes, od);
    }

    private static ArrayList<Integer> Unique(ArrayList<Integer> list) {
        return new ArrayList<Integer>(new LinkedHashSet<Integer>(list));
    }
}
