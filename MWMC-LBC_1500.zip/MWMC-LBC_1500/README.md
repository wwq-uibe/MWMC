# MWMC-LBC: solution methods and the 1,500 lb-cut instances

Code and instances of Section 6.1 of the paper "Lexicographic Minimum-Weight Minimum-Cardinality Length-Bounded Cuts: Applications in Network Optimization".

## Contents

- `instances/LBC-Instances-1500/`: the 1,500 lb-cut separation instances.
- `src/impl/`: Java code of all methods compared in Section 6.1, the validation of the returned cuts, and the experiment driver.

## Instances

Each instance is a separation problem recorded at a fractional solution during a branch-and-cut run:

- 640 instances on the four road networks of the RSLP experiments: 193 on BE581 (`be_*`), 166 on CA339 (`CA_*`), 116 on QC405 (`qc_*`), and 165 on US420 (`usEast_*`). The second field of the file name is the deviation level of the run in which the instance was recorded.
- 860 instances on NDSR networks with 80 nodes and 320 arcs (`<graph>_A320_N80_W<m>_iter<k>`), 430 for each of the two service metrics (`W1`, `W2`).

File format (whitespace-separated):

```
org   dest   lengthbound   time
<o>   <d>    <L>           <t>
Arc:from   to   length   weight
<i>   <j>   <length of arc (i,j)>   <weight of arc (i,j)>
...
```

- `org`, `dest`: origin and destination node.
- `lengthbound`: length bound L. An arc set C is an lb-cut if every `org`-`dest` path that avoids C has length at least L + θ (θ = 10^-4 in the paper).
- `time`: time (s) of the separation call in which the instance was recorded. It is informational only and not used by the methods.
- `weight`: value of the fractional solution associated with the arc. Weights are rounded to integers W_a = round(10^6 w_a) by the methods. Values printed as `-0.000000` are zero.

The MW-LBC problem asks for an lb-cut of minimum total weight; the MWMC-LBC problem asks for a minimum-cardinality cut among the minimum-weight cuts.

## Methods (column prefixes in the output CSV)

| Prefix | Method in the paper |
|---|---|
| `MWLBC` | [MW-LBC] |
| `LEX` | [MWMC-LEX] (two-stage lexicographic formulation; `LEX_T1`, `LEX_T2` are the times of the two stages) |
| `LEXEXACT` | [MWMC-LEX1] (single-stage integer encoding) |
| `EPS3`, `EPS4`, `EPS5` | [MWMC-ε] with ε = 10^-3, 10^-4, 10^-5 |
| `HEUR` | [MWMC-Heuristic] |
| `EPSMIN` | ε-MIN |
| `SPBA` | exact SPBA |
| `SPBA001CM` | SPBA-0.01 + cut-min |

For every method X the CSV contains `X_W` (integer weight, i.e., weight × 10^6), `X_C` (cardinality), `X_T` (seconds), `X_valid` (1 if the cut passes the independent shortest-path check of `CValidator`), and `X_status`.

Gurobi settings for all MIP-based methods: `MIPGap = MIPGapAbs = 0`, `IntFeasTol = FeasibilityTol = 1e-9`, `Threads = 1`, `Seed = 0`, time limit 3,600 s per MIP; M = L + θ with θ = 10^-4 (see `CConfig`).

## Requirements

- Java 17 or later
- Gurobi 12.0 with its Java API (`gurobi.jar`) and a valid license
- JGraphT (`jgrapht-core` and its dependencies)

## Running

```
javac -encoding UTF-8 -cp "gurobi.jar:lib/*" -d bin src/impl/*.java
java  -cp "bin:gurobi.jar:lib/*" impl.CRunExperiment instances/LBC-Instances-1500 results_mwmc.csv [seed]
```

On Windows, replace `:` by `;` in the class path. `impl.CQuickTest` runs a small subset of 12 instances. `impl.CRerunMissing` re-runs the instances with missing results in an existing CSV. Each row of the CSV is written as soon as the instance is finished, so an interrupted run can be resumed.
