package impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

/**
 * [REV 2026-11] Quick check of the revised code on 12 instances before the full run.
 * Includes the instances on which the old LEX results were inconsistent.
 * Run it in Eclipse (Run As > Java Application); output: results_quicktest.csv.
 * All *_valid columns should be 1, and LEX_W should equal SPBA_W and LEXEXACT_W.
 */
public class CQuickTest {
    static final String[] FILES = {
        "6371_A320_N80_W1_iter0.txt", "8411_A320_N80_W2_iter46.txt", "7362_A320_N80_W1_iter32.txt",
        "6371_A320_N80_W1_iter59.txt", "5469_A320_N80_W1_iter84.txt", "4874_A320_N80_W1_iter15.txt",
        "be_0.0_150_iter8.txt", "be_0.2_150_iter9.txt", "CA_0.5_50_iter48.txt",
        "qc_0.5_150_iter48.txt", "usEast_0.5_80_iter15.txt", "usEast_0.1_80_iter0.txt"
    };

    public static void main(String[] args) throws Exception {
        String folder = CRunExperiment.resolveFolder(
                args.length > 0 ? args[0] : "instances/LBC-Instances-1500");
        String out = args.length > 1 ? args[1] : "results_quicktest.csv";
        BufferedWriter w = new BufferedWriter(new FileWriter(out, false));
        w.write(CRunExperiment.header());
        w.newLine();
        int k = 0;
        for (String name : FILES) {
            k++;
            CLBInstance inst = CLBInstance.readLBInstance(new File(folder, name));
            w.write(CRunExperiment.runInstance(inst));
            w.newLine();
            w.flush();
            System.out.println(k + "/" + FILES.length + "  " + name);
        }
        w.close();
        System.out.println("Quick test finished. Results in " + out);
    }
}
