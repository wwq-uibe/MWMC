package impl;

import java.util.ArrayList;

public class Clbcut {
	public ArrayList<CArc> ArcSet=new ArrayList<CArc> ();
	public ArrayList<Integer> lbcut=new ArrayList<Integer> ();
	public double weight;
	public long weightScaled; // [REV 2026-11] integer-scaled weight
	public double length;
	public ArrayList<Integer> shortpatharclist=new ArrayList<Integer>();
}
