package impl;

public class CArc {

	public int real_left=-1;
	public int real_right=-1;
	public double length;
	public double weight;
	public int index;
}
