package impl;

import java.util.ArrayList;

/**
 * cut-min: sequential minimalization of an lb-cut (Arslan et al. 2019, IntSep-M).
 * Removes an arc from CLOSE whenever the remaining set is still an lb-cut.
 */
public class CCutMin {
	
	public int cardinality;	
	public void Run (ArrayList<CArc> AS,int s,int t,double LEN_BOUND,ArrayList<Integer> CLOSE) {	
		
		ArrayList<CArc> OPEN=new ArrayList<CArc>();
		for (int a=0;a<AS.size();a++) {
			int id=AS.get(a).index;
			if (CLOSE.indexOf(id)<0) {
				OPEN.add(AS.get(a));
			}
		}
		
		for (int a=0;a<CLOSE.size();a++) {
			int arc_id=CLOSE.get(a);
			OPEN.add(0,AS.get(arc_id));
			
			ArrayList<Integer> patharclist = CJGraph.getPathIndexList(s, t, OPEN);
			double shortestDist = CJGraph.shortestDist;
			if (CConfig.isCut(shortestDist, LEN_BOUND)) { // [REV 2026-11] same THETA as all methods (was > L)
				CLOSE.remove(a);
				a--;
			}else {
				OPEN.remove(0);
			}
		}
		
		cardinality=CLOSE.size();
	}
}
