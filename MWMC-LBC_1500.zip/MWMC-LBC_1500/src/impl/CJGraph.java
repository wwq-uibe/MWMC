package impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

public class CJGraph {

	public static double shortestDist;
	public static double Check(int s,int t, ArrayList<CArc> ArcSet) {		
		Graph<Integer, DefaultWeightedEdge> g =
	            new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);
		
		for (int i=0;i<ArcSet.size();i++) {			
	        int u = ArcSet.get(i).real_left;
	        int v = ArcSet.get(i).real_right;

	        if (!g.containsVertex(u)) g.addVertex(u);
	        if (!g.containsVertex(v)) g.addVertex(v);

	        DefaultWeightedEdge e = g.addEdge(u, v);

	        if (e != null) {
	            double w = ArcSet.get(i).length;
	            g.setEdgeWeight(e, w);
	        } else {
	            // [REV 2026-11] parallel arc: keep the shorter one (was silently ignored)
	            DefaultWeightedEdge old = g.getEdge(u, v);
	            if (ArcSet.get(i).length < g.getEdgeWeight(old)) {
	                g.setEdgeWeight(old, ArcSet.get(i).length);
	            }
	        }
	    }
		
		// [REV 2026-11] s or t without remaining arcs: no s-t path (was an IllegalArgumentException)
		if (!g.containsVertex(s) || !g.containsVertex(t))
			return Double.POSITIVE_INFINITY;
		
		DijkstraShortestPath<Integer, DefaultWeightedEdge> dijkstra =
	            new DijkstraShortestPath<>(g);
		
		GraphPath<Integer, DefaultWeightedEdge> path =
	            dijkstra.getPath(s, t);
		if (path==null)
			return Double.POSITIVE_INFINITY;
		else {
			return path.getWeight();
		}
		
	}
	
	public static ArrayList<Integer> getPathIndexList(int s, int t, ArrayList<CArc> ArcSet) {
	    // 建图部分保持不变
	    Graph<Integer, DefaultWeightedEdge> g = new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);
	    
	    // 为了快速根据 (u,v) 找到对应的 arc index，可以建一个映射
	    Map<String, Integer> edgeToIndex = new HashMap<>();
	    
	    for (CArc arc : ArcSet) {
	        int u = arc.real_left;
	        int v = arc.real_right;
	        
	        if (!g.containsVertex(u)) g.addVertex(u);
	        if (!g.containsVertex(v)) g.addVertex(v);
	        
	        DefaultWeightedEdge e = g.addEdge(u, v);
	        String key = u + "," + v;
	        if (e != null) {
	            g.setEdgeWeight(e, arc.length);
	            // 存储映射关系，注意用特殊分隔符
	            edgeToIndex.put(key, arc.index);
	        } else {
	            // [REV 2026-11] parallel arc: keep the shorter one and its index (was silently ignored)
	            DefaultWeightedEdge old = g.getEdge(u, v);
	            if (arc.length < g.getEdgeWeight(old)) {
	                g.setEdgeWeight(old, arc.length);
	                edgeToIndex.put(key, arc.index);
	            }
	        }
	    }
	    
	    if (!g.containsVertex(s) || !g.containsVertex(t)) {
	        shortestDist = Double.POSITIVE_INFINITY;
	        return new ArrayList<>();
	    }
	    
	    DijkstraShortestPath<Integer, DefaultWeightedEdge> dijkstra = new DijkstraShortestPath<>(g);
	    GraphPath<Integer, DefaultWeightedEdge> path = dijkstra.getPath(s, t);
	    
	    if (path == null) {
	    	shortestDist = Double.POSITIVE_INFINITY;
	        return new ArrayList<>(); // 或者返回 null
	    }else {
	    	shortestDist = path.getWeight();
	    }
	    
	    ArrayList<Integer> indexList = new ArrayList<>();
	    List<DefaultWeightedEdge> edgeList = path.getEdgeList();
	    
	    for (DefaultWeightedEdge edge : edgeList) {
	        int u = g.getEdgeSource(edge);
	        int v = g.getEdgeTarget(edge);
	        String key = u + "," + v;
	        Integer idx = edgeToIndex.get(key);
	        if (idx != null) {
	            indexList.add(idx);
	        }
	    }
	    
	    return indexList;
	}
}
