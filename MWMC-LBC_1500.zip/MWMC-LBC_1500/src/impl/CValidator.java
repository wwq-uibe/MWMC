package impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

/**
 * [REV 2026-11] Independent check of every returned cut:
 * remove the cut arcs, run Dijkstra, and require the remaining shortest
 * s-t path to have length >= L + THETA. Also recomputes the cut weight
 * with the integer-scaled weights, so that all methods are compared on
 * exactly the same weight scale.
 */
public final class CValidator {
    private CValidator() {}

    /** Shortest s-t path length after removing the arcs whose index is in cutIdx. */
    public static double remainingShortest(ArrayList<CArc> arcs, int s, int t, Collection<Integer> cutIdx) {
        HashSet<Integer> cut = new HashSet<Integer>(cutIdx);
        ArrayList<CArc> rest = new ArrayList<CArc>();
        for (CArc a : arcs) {
            if (!cut.contains(a.index)) {
                rest.add(a);
            }
        }
        return CJGraph.Check(s, t, rest);
    }

    public static boolean isValid(ArrayList<CArc> arcs, int s, int t, double L, Collection<Integer> cutIdx) {
        return CConfig.isCut(remainingShortest(arcs, s, t, cutIdx), L);
    }

    /** Integer-scaled weight of a cut. Assumes arcs.get(k).index == k (as built by CLBInstance). */
    public static long scaledWeight(ArrayList<CArc> arcs, Collection<Integer> cutIdx) {
        long w = 0;
        for (int idx : cutIdx) {
            w += CConfig.scaled(arcs.get(idx).weight);
        }
        return w;
    }
}
