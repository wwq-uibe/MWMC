package impl;

import java.util.ArrayList;

/**
 * SPBA: shortest-path branching for the minimum-weight lb-cut
 * (lbcutA of Arslan, Jabali and Laporte, 2020, adapted from Golovach and Thilikos, 2011),
 * with zero-weight arcs pre-removed and incumbent-based pruning.
 *
 * [REV 2026-11]
 *  - the time limit is a parameter: Run(..., timeLimitSec) with timeLimitSec <= 0 = exact SPBA.
 *    The old 4-argument Run keeps the previous behaviour (SPBA-0.01);
 *  - the lb-cut test uses CConfig.isCut (same THETA as the MIP models; was L + 0.001);
 *  - weights are compared with integer-scaled weights (no floating-point ties);
 *  - a branch is pruned BEFORE its shortest path is computed when its weight cannot
 *    improve the incumbent; nodes with weight >= incumbent are discarded (was > incumbent);
 *  - timedOut reports whether the time limit was hit.
 */
public class ClbcutA {

	public ArrayList<CArc> AS = new ArrayList<CArc> ();
	public ArrayList<Integer> zero_weight_arclist = new ArrayList<Integer> ();

	public double min_wt=0;
	public long min_wt_scaled=Long.MAX_VALUE;   // [REV]
	public boolean timedOut=false;               // [REV]
	public ArrayList<Integer> final_lb_cut_arclist=new ArrayList<Integer> ();

	public void Init () {
		AS.clear();
		zero_weight_arclist.clear();
		min_wt=Double.POSITIVE_INFINITY;
		min_wt_scaled=Long.MAX_VALUE;
		timedOut=false;
		final_lb_cut_arclist.clear();
	}

	/** Backward compatible: time-limited SPBA with CConfig.SPBA_SHORT_LIMIT (= previous behaviour). */
	public void Run (ArrayList<CArc> ArcSet,int s,int t,double LEN_BOUND) {
		Run(ArcSet, s, t, LEN_BOUND, CConfig.SPBA_SHORT_LIMIT);
	}

	@SuppressWarnings("unchecked")
	public void Run (ArrayList<CArc> ArcSet,int s,int t,double LEN_BOUND,double timeLimitSec) {
		AS=(ArrayList<CArc>) ArcSet.clone();
		long start=System.nanoTime();

		ArcSet=RemoveZeroWeightArc(ArcSet);

		ArrayList<Clbcut> CutList=new ArrayList<Clbcut> ();
		{
			ArrayList<Integer> patharclist = CJGraph.getPathIndexList(s, t, ArcSet);
			double shortestDist = CJGraph.shortestDist;

			if (CConfig.isCut(shortestDist, LEN_BOUND)) {
				min_wt=0;
				min_wt_scaled=0;
				final_lb_cut_arclist.clear();
				return;
			}
			Clbcut temp = new Clbcut ();
			temp.ArcSet=(ArrayList<CArc>) ArcSet.clone();
			temp.lbcut.clear();
			temp.weight=0;
			temp.weightScaled=0;
			temp.length=shortestDist;
			temp.shortpatharclist=(ArrayList<Integer>) patharclist.clone();
			CutList.add(temp);
		}

		while (true) {
			ArrayList<Clbcut> temp_CutList=new ArrayList<Clbcut> ();
			for (int i=0;i<CutList.size();i++) {
				Clbcut node = CutList.get(i);
				if (node.weightScaled >= min_wt_scaled) continue;
				for (int j=0;j<node.shortpatharclist.size();j++) {
					int index=node.shortpatharclist.get(j);
					long new_weight_scaled = node.weightScaled + CConfig.scaled(AS.get(index).weight);
					if (new_weight_scaled >= min_wt_scaled) continue;   // cannot improve the incumbent

					ArrayList<CArc> new_ArcSet = GetNewArcSetRemove (node.ArcSet,index);
					ArrayList<Integer> new_shortpatharclist = CJGraph.getPathIndexList(s, t, new_ArcSet);
					double new_length = CJGraph.shortestDist;

					ArrayList<Integer> new_lbcut=(ArrayList<Integer>) node.lbcut.clone();
					new_lbcut.add(index);

					if (CConfig.isCut(new_length, LEN_BOUND)) {
						min_wt_scaled=new_weight_scaled;
						min_wt=GetWeight(new_lbcut);
						final_lb_cut_arclist=(ArrayList<Integer>) new_lbcut.clone();
					} else {
						Clbcut newlb = new Clbcut();
						newlb.ArcSet=new_ArcSet;
						newlb.lbcut=new_lbcut;
						newlb.weight=GetWeight(new_lbcut);
						newlb.weightScaled=new_weight_scaled;
						newlb.length=new_length;
						newlb.shortpatharclist=new_shortpatharclist;
						temp_CutList.add(newlb);
					}
				}
				if (timeLimitSec > 0 && (System.nanoTime()-start)/1e9 > timeLimitSec) {
					timedOut=true;
					return;
				}
			}

			for (int i=0;i<temp_CutList.size();i++) {
				if (temp_CutList.get(i).weightScaled>=min_wt_scaled) {
					temp_CutList.remove(i);
					i--;
				}
			}

			if (temp_CutList.size()==0) {
				break;
			}

			if (timeLimitSec > 0 && (System.nanoTime()-start)/1e9 > timeLimitSec) {
				timedOut=true;
				return;
			}

			CutList=temp_CutList;
		}
	}

	public double GetWeight (ArrayList<Integer> patharclist) {
		double wt=0;
		for (int i=0;i<patharclist.size();i++) {
			int index=patharclist.get(i);
			wt+=AS.get(index).weight;
		}
		return wt;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<CArc> GetNewArcSetRemove (ArrayList<CArc> arcset, int index) {
		ArrayList<CArc> temp = (ArrayList<CArc>) arcset.clone();
		for (int i=0;i<temp.size();i++) {
			if (temp.get(i).index==index) {
				temp.remove(i);
				break;
			}
		}
		return temp;
	}

	public ArrayList<CArc> RemoveZeroWeightArc (ArrayList<CArc> arcset) {
		ArrayList<CArc> temp=new ArrayList<CArc>();

		zero_weight_arclist.clear();
		for (int i=0;i<arcset.size();i++) {
			if (CConfig.scaled(arcset.get(i).weight)<=0) {
				zero_weight_arclist.add(arcset.get(i).index);
			}else {
				temp.add(arcset.get(i));
			}
		}
		return temp;
	}
}
