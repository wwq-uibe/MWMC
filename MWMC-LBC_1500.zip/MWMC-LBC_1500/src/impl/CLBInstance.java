package impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CLBInstance {

	String fileName;

    int org;
    int dest;
    double lengthBound;
    double time;
    ArrayList<CArc> arcs = new ArrayList<>();
    int MAX_NODE;
    
    int arc_number;
    int node_number;
    
    public static CLBInstance readLBInstance(File file) throws IOException {
        CLBInstance inst = new CLBInstance();
        inst.fileName = file.getName();
        ArrayList<Integer> nodelist=new ArrayList<Integer> ();
        int arc_n=0;

        int NNN=-1;
        int k=0;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;

            // 1. 跳过第一行: org dest lengthbound time
            line = br.readLine();

            // 2. 读取第二行: 4 338 1219.2058 0.002...
            line = br.readLine();
            String[] od = line.trim().split("\\s+");

            inst.org = Integer.parseInt(od[0]);
            inst.dest = Integer.parseInt(od[1]);
            inst.lengthBound = Double.parseDouble(od[2]);
            inst.time = Double.parseDouble(od[3]);

            // 3. 跳过第三行: Arc:from to length weight
            line = br.readLine();

            // 4. 读取 arcs
            while ((line = br.readLine()) != null) {
                line = line.trim();

                if (line.isEmpty()) continue;

                String[] parts = line.split("\\s+");

                int from = Integer.parseInt(parts[0]);
                int to = Integer.parseInt(parts[1]);
                double length = Double.parseDouble(parts[2]);
                double weight = Double.parseDouble(parts[3]);
                // 处理 -0.000000
                if (Math.abs(weight) < 1e-9) {
                    weight = 0.0;
                }
                CArc arc=new CArc ();
                arc.real_left=from;
                arc.real_right=to;
                arc.length=length;
                arc.weight=weight;
                arc.index=k;
                inst.arcs.add(arc);
                arc_n++;
                k++;
                if (nodelist.indexOf(from)<0) {
                	nodelist.add(from);
                }
                if (nodelist.indexOf(to)<0) {
                	nodelist.add(to);
                }
                if (NNN<from) {
                	NNN=from;
                }
                if (NNN<to) {
                	NNN=to;
                }
            }
        }
        inst.arc_number=arc_n;
        inst.node_number=nodelist.size();
        inst.MAX_NODE=NNN;
        return inst;
    }
}
