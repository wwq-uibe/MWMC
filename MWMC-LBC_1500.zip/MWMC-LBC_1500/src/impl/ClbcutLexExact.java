package impl;

import java.util.ArrayList;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

/**
 * [REV 2026-11] NEW: exact single-stage MWMC model with integer coefficients.
 *
 *   min  sum_a ( K * W_a + 1 ) u_a ,   K = |A| + 1,   W_a = round(w_a * 10^6).
 *
 * Since every cut has at most |A| < K arcs, (K*W(C) + |C|) orders cuts first by the
 * integer weight W(C) and then by |C|. Hence one MIP solve returns a lexicographically
 * optimal cut, with no instance-dependent epsilon: this is Proposition 3 with
 * Delta_w >= 1 (in scaled units) and epsilon = 1/K. All coefficients are integers
 * below 2^53, so they are represented exactly in double precision.
 */
public class ClbcutLexExact {

    double obj;
    double runtime;
    int status;
    double mipgap = Double.NaN;

    GRBEnv env;
    GRBModel model;

    GRBVar[] u;
    GRBVar[] pi;

    int org;
    int dest;

    public ArrayList<CArc> AS = new ArrayList<CArc>();
    ArrayList<Integer> lbcut = new ArrayList<Integer>();

    public double Total_Weight = 0;
    public long weightScaled = -1;

    public void Init() throws GRBException {
        env = new GRBEnv(true);
        env.set("logFile", "knapsack.log");
        env.set(GRB.IntParam.OutputFlag, 0);
        env.start();
        model = new GRBModel(env);
        CGrb.apply(model, CConfig.TIME_LIMIT);
    }

    @SuppressWarnings("unchecked")
    public void build_model(ArrayList<CArc> ArcSet, int s, int t, int Node_N, double LEN_BOUND) throws GRBException {
        org = s;
        dest = t;
        AS = (ArrayList<CArc>) ArcSet.clone();
        double M = CConfig.bigM(LEN_BOUND);

        pi = new GRBVar[Node_N + 1];
        u = new GRBVar[ArcSet.size()];
        for (int a = 0; a < u.length; a++) {
            u[a] = model.addVar(0, 1, 0, GRB.BINARY, "u" + a);
        }
        for (int i = 0; i < pi.length; i++) {
            pi[i] = model.addVar(0, M, 0, GRB.CONTINUOUS, "pi" + i);
        }

        model.addConstr(pi[t], GRB.EQUAL, 0, null);
        for (int a = 0; a < ArcSet.size(); a++) {
            int i = ArcSet.get(a).real_left;
            int j = ArcSet.get(a).real_right;
            GRBLinExpr lhs = new GRBLinExpr();
            lhs.addTerm(1.0, pi[i]);
            lhs.addTerm(-1.0, pi[j]);
            lhs.addConstant(-ArcSet.get(a).length);
            GRBLinExpr rhs = new GRBLinExpr();
            rhs.addTerm(M, u[a]);
            model.addConstr(lhs, GRB.LESS_EQUAL, rhs, null);
        }
        model.addConstr(pi[s], GRB.GREATER_EQUAL, LEN_BOUND + CConfig.THETA, null);

        long K = ArcSet.size() + 1L;
        GRBLinExpr objective = new GRBLinExpr();
        for (int a = 0; a < u.length; a++) {
            long coef = K * CConfig.scaled(ArcSet.get(a).weight) + 1L;
            objective.addTerm((double) coef, u[a]);
        }
        model.setObjective(objective, GRB.MINIMIZE);
    }

    public void solve() throws GRBException {
        model.optimize();
        status = model.get(GRB.IntAttr.Status);
        runtime = model.get(GRB.DoubleAttr.Runtime);
        if (model.get(GRB.IntAttr.SolCount) == 0) {
            Total_Weight = Double.POSITIVE_INFINITY;
            weightScaled = -1;
            return;
        }
        obj = model.get(GRB.DoubleAttr.ObjVal);
        if (status == GRB.Status.OPTIMAL) mipgap = 0.0;
        else { try { mipgap = model.get(GRB.DoubleAttr.MIPGap); } catch (Exception ignored) {} }
        lbcut.clear();
        Total_Weight = 0;
        weightScaled = 0;
        for (int i = 0; i < u.length; i++) {
            if (u[i].get(GRB.DoubleAttr.X) > 0.5) {
                lbcut.add(AS.get(i).index);
                Total_Weight += AS.get(i).weight;
                weightScaled += CConfig.scaled(AS.get(i).weight);
            }
        }
    }

    public void end() throws GRBException {
        model.dispose();
        env.dispose();
    }
}
