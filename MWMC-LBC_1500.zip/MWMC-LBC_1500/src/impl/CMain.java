package impl;


public class CMain {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		{
			// [REV 2026-11] revised MWMC experiment: all methods + validation, one CSV row per instance
			CRunExperiment.main(new String[] {
					"instances/LBC-Instances-1500",
					"results_mwmc.csv" });

		}
	}
}
