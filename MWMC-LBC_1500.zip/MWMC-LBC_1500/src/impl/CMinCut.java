package impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import org.jgrapht.Graph;
import org.jgrapht.alg.flow.DinicMFImpl;
import org.jgrapht.alg.interfaces.MinimumSTCutAlgorithm;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

public class CMinCut {

	public static double total_weight;
	public static ArrayList<Integer> lbcut=new ArrayList<Integer>();
	public static ArrayList<CArc> Mincutlist=new ArrayList<CArc> ();
	public static void Run (ArrayList<CArc> ArcSet, int s,int t) {
		Mincutlist.clear();
		lbcut.clear();
		total_weight=Double.MAX_VALUE;
		
		Graph<Integer, DefaultWeightedEdge> g =
				new DefaultDirectedWeightedGraph<>(DefaultWeightedEdge.class);
		// 用来把JGraphT中的edge映射回你自己的CArc
		HashMap<DefaultWeightedEdge, CArc> edgeToArc = new HashMap<>();
		
		for (int a=0;a<ArcSet.size();a++) {
			int u = ArcSet.get(a).real_left;
			int v = ArcSet.get(a).real_right;

			if (!g.containsVertex(u)) {
				g.addVertex(u);
			}
			if (!g.containsVertex(v)) {
				g.addVertex(v);
			}

			// 如果网络中不存在平行边，这样写就可以
			DefaultWeightedEdge e = g.addEdge(u, v);

			// 若重复边导致 addEdge 返回 null，则跳过或自行处理
			if (e != null) {
				// 
				if (ArcSet.get(a).weight<1e-5) {
					g.setEdgeWeight(e, 1e-5);
				}else {
					g.setEdgeWeight(e, ArcSet.get(a).weight);
				}
				
				edgeToArc.put(e, ArcSet.get(a));
			}
		}
		
		if (!g.containsVertex(s) || !g.containsVertex(t)) {
		    throw new IllegalArgumentException("Graph must contain both s and t.");
		}
		
		MinimumSTCutAlgorithm<Integer, DefaultWeightedEdge> minCutAlg =
				new DinicMFImpl<>(g);

		minCutAlg.calculateMinCut(s, t);
		Set<DefaultWeightedEdge> cutEdges = minCutAlg.getCutEdges();
		
		total_weight=0;
		
		for (DefaultWeightedEdge e : cutEdges) {
			CArc arc = edgeToArc.get(e);
			Mincutlist.add(arc);
			lbcut.add(arc.index);
			if (arc != null) {
				total_weight+=arc.weight;
			}
		}

	}
}
