package impl;

/**
 * Global settings shared by ALL lb-cut methods.
 *
 * [REV 2026-11] Revised for the major revision:
 *  - one single length tolerance THETA used by the MIP models, SPBA, cut-min and the validator,
 *    so that every method solves exactly the same problem;
 *  - integer-scaled weights (WEIGHT_SCALE) used consistently in both LEX stages;
 *  - explicit Threads / Seed / TimeLimit settings for reproducibility.
 */
public final class CConfig {
    private CConfig() {}

    // ------------------------------------------------------------------
    // Length tolerance (Proposition 2).
    // An lb-cut must leave every remaining s-t path with length >= L + THETA.
    // The length bounds L in the instance files are stored with 4 decimals,
    // so THETA = 1e-4 equals their precision. For instances whose arc lengths
    // have at most 4 decimals (BE, CA, NDSR) this is exactly "length > L";
    // for QC/US (8-decimal arc lengths) paths with length in (L, L+1e-4) are
    // also cut, i.e. differences below the precision of L are ignored.
    // ------------------------------------------------------------------
    public static final double THETA = 1e-4;

    /** Floating-point tolerance when comparing accumulated path lengths. */
    public static final double LEN_EPS = 1e-9;

    /** Arc weights have 6 decimals; weight objectives/constraints use W_a = round(w_a * WEIGHT_SCALE). */
    public static final long WEIGHT_SCALE = 1_000_000L;

    // Exact MIP termination settings.
    public static final double MIP_GAP = 0.0;
    public static final double MIP_GAP_ABS = 0.0;
    public static final double FEASIBILITY_TOL = 1e-9;
    public static final double INT_FEAS_TOL = 1e-9;

    // Run settings (report these in the paper).
    public static double TIME_LIMIT = 3600.0; // seconds, per MIP solve
    public static int THREADS = 1;            // Gurobi Threads parameter
    public static int SEED = 0;               // Gurobi Seed parameter

    /** Time limit (seconds) of the time-limited variant SPBA-t. */
    public static final double SPBA_SHORT_LIMIT = 0.01;

    /** Kept for backward compatibility with older code. */
    public static final double WEIGHT_TOL = 1e-9;

    /** Integer-scaled weight W_a = round(w_a * 10^6). */
    public static long scaled(double w) {
        return Math.round(w * WEIGHT_SCALE);
    }

    /** True iff a remaining shortest s-t path length dist means that the cut is a valid lb-cut. */
    public static boolean isCut(double dist, double L) {
        return dist >= L + THETA - LEN_EPS;
    }

    /** Big-M and upper bound of the distance potentials (Proposition 2: M = L + THETA). */
    public static double bigM(double L) {
        return L + THETA;
    }
}
