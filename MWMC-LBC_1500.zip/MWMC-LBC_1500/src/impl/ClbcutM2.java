package impl;

import java.util.ArrayList;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

/**
 * [MC-LBC] Stage 2 of MWMC-LEX: minimum cardinality subject to sum W_a u_a <= Z*.
 *
 * [REV 2026-11]
 *  - Z* is now passed as an exact integer (ClbcutM.objScaled), computed with the
 *    SAME integer weights as this constraint. Previously stage 1 optimized the
 *    unrounded weights while stage 2 used per-arc rounded weights, so cuts with
 *    equal weight could be excluded (or slightly heavier cuts admitted);
 *  - distance potentials bounded by L + THETA and big-M = L + THETA;
 *  - common Gurobi parameters from CConfig.
 */
public class ClbcutM2 {

	public static int zero_gap=0;
	public static int max_gap=0;

	double obj;
	double runtime;
	int status;
	double mipgap=Double.NaN;
	double objbound=Double.NaN;

	GRBEnv env;
	GRBModel model;

	GRBVar[] u;
	GRBVar[] pi;

	int org;
	int dest;

	double ps;

	public ArrayList<CArc> AS=new ArrayList<CArc>();

	ArrayList<Integer> lbcut=new ArrayList<Integer>();
	public double Total_Weight=0;
	public long weightScaled=-1; // [REV]

	public void Init() throws GRBException {
		env = new GRBEnv(true);
		env.set("logFile", "knapsack.log");
		env.set(GRB.IntParam.OutputFlag, 0);
        env.start();

        model = new GRBModel(env);
        CGrb.apply(model, CConfig.TIME_LIMIT);
	}

	/** Backward-compatible version: MW given in original units. Prefer the long version. */
	public void build_model(ArrayList<CArc> ArcSet,int s,int t,int Node_N,double LEN_BOUND,double MW) throws GRBException {
		build_model(ArcSet, s, t, Node_N, LEN_BOUND, CConfig.scaled(MW));
	}

	/** [REV] MWScaled must be the integer-scaled weight of an optimal stage-1 cut (ClbcutM.objScaled). */
	@SuppressWarnings("unchecked")
	public void build_model(ArrayList<CArc> ArcSet,int s,int t,int Node_N,double LEN_BOUND,long MWScaled) throws GRBException {
		org=s;
		dest=t;
		AS=(ArrayList<CArc>) ArcSet.clone();
		double M = CConfig.bigM(LEN_BOUND);
		//init
		pi=new GRBVar[Node_N+1];
		u=new GRBVar[ArcSet.size()];
		for (int a=0;a<u.length;a++) {
	    	u[a]=model.addVar(0, 1, 0, GRB.BINARY, "u" +a);
	    }
		for (int i=0;i<pi.length;i++) {
			pi[i]=model.addVar(0, M, 0, GRB.CONTINUOUS, "pi"+i);
		}
		//constraint
		model.addConstr(pi[t], GRB.EQUAL, 0, null);

		for (int a=0;a<ArcSet.size();a++) {
			int i=ArcSet.get(a).real_left;
			int j=ArcSet.get(a).real_right;
			double dis=ArcSet.get(a).length;
			GRBLinExpr temp = new GRBLinExpr();
			temp.addTerm(1.0, pi[i]);
			temp.addTerm(-1.0, pi[j]);
			temp.addConstant(-dis);

			GRBLinExpr temp_M = new GRBLinExpr();
			temp_M.addTerm(M, u[a]);

			model.addConstr(temp, GRB.LESS_EQUAL, temp_M, null);
		}

		model.addConstr(pi[s], GRB.GREATER_EQUAL, LEN_BOUND + CConfig.THETA, null);

		//obj: cardinality
		GRBLinExpr obj = new GRBLinExpr();
		for (int a=0;a<u.length;a++) {
			obj.addTerm(1, u[a]);
		}
		model.setObjective(obj, GRB.MINIMIZE);

		// total weight constraint with the same integer weights as stage 1
		GRBLinExpr totalw = new GRBLinExpr();
		for (int a = 0; a < u.length; a++) {
		    totalw.addTerm((double) CConfig.scaled(ArcSet.get(a).weight), u[a]);
		}
		model.addConstr(totalw, GRB.LESS_EQUAL, (double) MWScaled, "MW_constraint");
	}

	public void solve() throws GRBException {
		model.optimize();
		status = model.get(GRB.IntAttr.Status);
		runtime=model.get(GRB.DoubleAttr.Runtime);

		if (model.get(GRB.IntAttr.SolCount) == 0) {
			Total_Weight=Double.POSITIVE_INFINITY;
			weightScaled=-1;
			return;
		}

		obj = model.get(GRB.DoubleAttr.ObjVal);
		objbound = model.get(GRB.DoubleAttr.ObjBound);
		if (status == GRB.Status.OPTIMAL) mipgap = 0.0;
		else { try { mipgap = model.get(GRB.DoubleAttr.MIPGap); } catch (Exception ignored) {} }
		lbcut.clear();
		Total_Weight = 0;
		weightScaled = 0;
		for (int i=0;i<u.length;i++) {
			if (u[i].get(GRB.DoubleAttr.X)>0.5) {
				int arcindex=AS.get(i).index;
				lbcut.add(arcindex);
				Total_Weight+=AS.get(i).weight;
				weightScaled+=CConfig.scaled(AS.get(i).weight);
			}
		}
		ps=pi[org].get(GRB.DoubleAttr.X);
	}

	public void end () throws GRBException {
		model.dispose();
        env.dispose();
	}
}
