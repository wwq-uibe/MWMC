package impl;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBModel;

/** [REV 2026-11] Applies the common Gurobi parameters of CConfig to a model. */
public final class CGrb {
    private CGrb() {}

    public static void apply(GRBModel model, double timeLimit) throws GRBException {
        model.set(GRB.DoubleParam.TimeLimit, timeLimit);
        model.set(GRB.DoubleParam.MIPGap, CConfig.MIP_GAP);
        model.set(GRB.DoubleParam.MIPGapAbs, CConfig.MIP_GAP_ABS);
        model.set(GRB.DoubleParam.FeasibilityTol, CConfig.FEASIBILITY_TOL);
        model.set(GRB.DoubleParam.IntFeasTol, CConfig.INT_FEAS_TOL);
        model.set(GRB.IntParam.Threads, CConfig.THREADS);
        model.set(GRB.IntParam.Seed, CConfig.SEED);
    }
}
