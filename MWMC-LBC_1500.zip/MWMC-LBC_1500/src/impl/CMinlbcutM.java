package impl;

import java.util.ArrayList;
import java.util.HashSet;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

/**
 * [MWMC-HEURISTIC] Minimum-cardinality lb-cut restricted to the arcs of one
 * minimum-weight cut (adaptation of min-lbcutM of Arslan, Jabali and Laporte, 2020).
 *
 * [REV 2026-11]
 *  - common Gurobi parameters (time limit was hard-coded to 60 s before);
 *  - potentials bounded by L + THETA and big-M = L + THETA;
 *  - checks SolCount (a time-limited run without a solution no longer crashes);
 *  - variables outside the restriction set are fixed through their bounds
 *    instead of extra constraints, and the membership test uses a HashSet.
 */
public class CMinlbcutM {

	public static int zero_gap=0;
	public static int max_gap=0;

	double obj;
	double runtime;
	int status;

	GRBEnv env;
	GRBModel model;

	GRBVar[] u;
	GRBVar[] pi;

	int org;
	int dest;

	double ps;
	double total_weight=0;
	long weightScaled=-1; // [REV]

	public ArrayList<CArc> AS=new ArrayList<CArc>();

	ArrayList<Integer> lbcut=new ArrayList<Integer>();


	public void Init() throws GRBException {
		env = new GRBEnv(true);
		env.set("logFile", "knapsack.log");
		env.set(GRB.IntParam.OutputFlag, 0);
        env.start();

        model = new GRBModel(env);
        CGrb.apply(model, CConfig.TIME_LIMIT);
	}

	/** trick = positions (in ArcSet) of the arcs of the minimum-weight cut (ClbcutM.trick). */
	@SuppressWarnings("unchecked")
	public void build_model(ArrayList<CArc> ArcSet,int s,int t,int Node_N,double LEN_BOUND,ArrayList<Integer> trick) throws GRBException {
		org=s;
		dest=t;
		AS=(ArrayList<CArc>) ArcSet.clone();
		double M = CConfig.bigM(LEN_BOUND);
		HashSet<Integer> allowed = new HashSet<Integer>(trick);
		//init
		pi=new GRBVar[Node_N+1];
		u=new GRBVar[ArcSet.size()];
		for (int a=0;a<u.length;a++) {
			double ub = allowed.contains(a) ? 1 : 0;
	    	u[a]=model.addVar(0, ub, 0, GRB.BINARY, "u" +a);
	    }
		for (int i=0;i<pi.length;i++) {
			pi[i]=model.addVar(0, M, 0, GRB.CONTINUOUS, "pi"+i);
		}
		//constraint
		model.addConstr(pi[t], GRB.EQUAL, 0, null);

		for (int a=0;a<ArcSet.size();a++) {
			int i=ArcSet.get(a).real_left;
			int j=ArcSet.get(a).real_right;
			double dis=ArcSet.get(a).length;
			GRBLinExpr temp = new GRBLinExpr();
			temp.addTerm(1.0, pi[i]);
			temp.addTerm(-1.0, pi[j]);
			temp.addConstant(-dis);

			GRBLinExpr temp_M = new GRBLinExpr();
			temp_M.addTerm(M, u[a]);

			model.addConstr(temp, GRB.LESS_EQUAL, temp_M, null);
		}

		model.addConstr(pi[s], GRB.GREATER_EQUAL, LEN_BOUND + CConfig.THETA, null);

		//obj
		GRBLinExpr obj = new GRBLinExpr();
		for (int a=0;a<u.length;a++) {
			obj.addTerm(1, u[a]);
		}
		model.setObjective(obj, GRB.MINIMIZE);
	}

	public void solve() throws GRBException {
		model.optimize();
		status = model.get(GRB.IntAttr.Status);
		runtime=model.get(GRB.DoubleAttr.Runtime);

		if (model.get(GRB.IntAttr.SolCount) == 0) {
			total_weight=Double.POSITIVE_INFINITY;
			weightScaled=-1;
			return;
		}

		obj = model.get(GRB.DoubleAttr.ObjVal);
		lbcut.clear();
		total_weight=0;
		weightScaled=0;
		for (int i=0;i<u.length;i++) {
			if (u[i].get(GRB.DoubleAttr.X)>0.5) {
				int arcindex=AS.get(i).index;
				lbcut.add(arcindex);
				total_weight+=AS.get(i).weight;
				weightScaled+=CConfig.scaled(AS.get(i).weight);
			}
		}

		ps=pi[org].get(GRB.DoubleAttr.X);
	}

	public void end () throws GRBException {
		model.dispose();
        env.dispose();
	}
}
