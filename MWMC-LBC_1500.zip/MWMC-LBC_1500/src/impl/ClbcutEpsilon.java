package impl;

import java.util.ArrayList;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

/**
 * [MWMC-eps] Single-stage perturbed model: min sum (W_a + round(eps*10^6)) u_a.
 * [REV 2026-11] common parameters, potentials bounded by L + THETA, big-M = L + THETA,
 * weightScaled reported. Not guaranteed lexicographic for a fixed eps; see ClbcutLexExact.
 */
public class ClbcutEpsilon {

    public static int zero_gap = 0;
    public static int max_gap = 0;

    double obj;
    double runtime;
    int status;
    double mipgap = Double.NaN;
    double objbound = Double.NaN;

    GRBEnv env;
    GRBModel model;

    GRBVar[] u;
    GRBVar[] pi;

    int org;
    int dest;

    double ps;

    public ArrayList<CArc> AS = new ArrayList<CArc>();

    ArrayList<Integer> lbcut = new ArrayList<Integer>();

    public double Total_Weight = 0;
    public long weightScaled = -1; // [REV 2026-11]

    // ============================================================
    // Scale factor for integer objective coefficients
    // Assumption: arc weights have at most 6 decimal places
    // ============================================================
    private static final long SCALE = 1_000_000L;

    public void Init() throws GRBException {

        env = new GRBEnv(true);
        env.set("logFile", "knapsack.log");
        env.set(GRB.IntParam.OutputFlag, 0);
        env.start();

        model = new GRBModel(env);

        // [REV 2026-11] common parameters (time limit was hard-coded to 60 s before)
        CGrb.apply(model, CConfig.TIME_LIMIT);
    }

    @SuppressWarnings("unchecked")
    public void build_model(
            ArrayList<CArc> ArcSet,
            int s,
            int t,
            int Node_N,
            double LEN_BOUND,
            double epsilon) throws GRBException {

        org = s;
        dest = t;
        AS = (ArrayList<CArc>) ArcSet.clone();

        // ============================================================
        // Variables
        // ============================================================

        pi = new GRBVar[Node_N + 1];
        u = new GRBVar[ArcSet.size()];

        for (int a = 0; a < u.length; a++) {
            u[a] = model.addVar(
                    0,
                    1,
                    0,
                    GRB.BINARY,
                    "u" + a
            );
        }

        for (int i = 0; i < pi.length; i++) {
            pi[i] = model.addVar(
                    0,
                    CConfig.bigM(LEN_BOUND), // [REV] potentials bounded by L + THETA
                    0,
                    GRB.CONTINUOUS,
                    "pi" + i
            );
        }

        // ============================================================
        // Constraints
        // ============================================================

        model.addConstr(
                pi[t],
                GRB.EQUAL,
                0,
                null
        );

        for (int a = 0; a < ArcSet.size(); a++) {

            int i = ArcSet.get(a).real_left;
            int j = ArcSet.get(a).real_right;
            double dis = ArcSet.get(a).length;

            GRBLinExpr temp = new GRBLinExpr();

            temp.addTerm(1.0, pi[i]);
            temp.addTerm(-1.0, pi[j]);
            temp.addConstant(-dis);

            GRBLinExpr temp_M = new GRBLinExpr();

            temp_M.addTerm(
                    CConfig.bigM(LEN_BOUND), // [REV] big-M = L + THETA (Proposition 2)
                    u[a]
            );

            model.addConstr(
                    temp,
                    GRB.LESS_EQUAL,
                    temp_M,
                    null
            );
        }

        model.addConstr(
                LEN_BOUND + CConfig.THETA,
                GRB.LESS_EQUAL,
                pi[s],
                null
        );

        // ============================================================
        // Objective
        //
        // Original:
        //      sum (w_a + epsilon) u_a
        //
        // Scaled equivalent:
        //      sum (round(w_a * SCALE)
        //           + round(epsilon * SCALE)) u_a
        //
        // Example:
        //      epsilon = 1e-3 -> 1000
        //      epsilon = 1e-4 -> 100
        //      epsilon = 1e-5 -> 10
        // ============================================================

        GRBLinExpr objective = new GRBLinExpr();

        long epsilonScaled =
                Math.round(epsilon * SCALE);

        for (int a = 0; a < u.length; a++) {

            long weightScaled =
                    Math.round(
                            ArcSet.get(a).weight * SCALE
                    );

            long coefficient =
                    weightScaled + epsilonScaled;

            objective.addTerm(
                    (double) coefficient,
                    u[a]
            );
        }

        model.setObjective(
                objective,
                GRB.MINIMIZE
        );
    }

    public void solve() throws GRBException {

        model.optimize();

        status = model.get(GRB.IntAttr.Status);

        runtime = model.get(GRB.DoubleAttr.Runtime);

        if (model.get(GRB.IntAttr.SolCount) == 0) {
            Total_Weight = Double.POSITIVE_INFINITY;
            weightScaled = -1;
            return;
        }

        obj = model.get(GRB.DoubleAttr.ObjVal);
        objbound = model.get(GRB.DoubleAttr.ObjBound);

        if (status == GRB.Status.OPTIMAL) {

            mipgap = 0.0;

        } else {

            try {
                mipgap =
                        model.get(
                                GRB.DoubleAttr.MIPGap
                        );
            } catch (Exception ignored) {
            }
        }

        runtime =
                model.get(
                        GRB.DoubleAttr.Runtime
                );

        lbcut.clear();

        Total_Weight = 0;
        weightScaled = 0;

        for (int i = 0; i < u.length; i++) {

            double x =
                    u[i].get(
                            GRB.DoubleAttr.X
                    );

            if (x > 0.5) {

                int arcindex =
                        AS.get(i).index;

                lbcut.add(arcindex);

                Total_Weight +=
                        AS.get(i).weight;
                weightScaled += CConfig.scaled(AS.get(i).weight);
            }
        }

        ps =
                pi[org].get(
                        GRB.DoubleAttr.X
                );
    }

    public void end() throws GRBException {

        model.dispose();
        env.dispose();
    }
}