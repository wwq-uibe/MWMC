package impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;

/**
 * [REV 2026-11] NEW: runner for the MWMC-LBC experiment (Section 6.1, Table 4).
 *
 * For every instance in CInstance.files it runs all methods, validates every returned
 * cut with CValidator (Dijkstra), recomputes its integer-scaled weight, and writes one
 * CSV row. Rows are flushed immediately; a rerun skips instances already in the CSV.
 *
 * Usage: java impl.CRunExperiment [instanceFolder] [outputCsv] [seed]
 *
 * Columns per method X: X_W (integer-scaled weight, i.e. weight*10^6), X_C (cardinality),
 * X_T (seconds), X_valid (1 = valid lb-cut), X_status (Gurobi status code, or OPT / TL / OK / NA).
 * MIP times are Gurobi Runtime; LEX_T = LEX_T1 + LEX_T2 and HEUR_T include stage 1.
 * Combinatorial methods (EPSMIN, SPBA, SPBA001CM) report wall-clock time.
 */
public class CRunExperiment {

    static final String[] METHODS = {
        "MWLBC", "LEX", "LEXEXACT", "EPS3", "EPS4", "EPS5", "HEUR", "EPSMIN", "SPBA", "SPBA001CM"
    };
    static final double[] EPS = {1e-3, 1e-4, 1e-5};

    public static void main(String[] args) throws Exception {
        String folder = args.length > 0 ? args[0] : "instances/LBC-Instances-1500";
        String out = args.length > 1 ? args[1] : "results_mwmc.csv";
        if (args.length > 2) CConfig.SEED = Integer.parseInt(args[2]);

        folder = resolveFolder(folder);
        HashSet<String> done = readDone(out);
        boolean writeHeader = done.isEmpty() && !new File(out).exists();
        BufferedWriter w = new BufferedWriter(new FileWriter(out, true));
        if (writeHeader) {
            w.write(header());
            w.newLine();
            w.flush();
        }

        int k = 0;
        for (String name : CInstance.files) {
            k++;
            if (done.contains(name)) continue;
            File f = new File(folder, name);
            if (!f.exists()) {
                System.err.println("Missing instance: " + f.getAbsolutePath());
                continue;
            }
            CLBInstance inst = CLBInstance.readLBInstance(f);
            String row = runInstance(inst);
            w.write(row);
            w.newLine();
            w.flush();
            System.out.println(k + "/" + CInstance.files.length + "  " + name);
        }
        w.close();
        System.out.println("Finished. Results in " + out);
    }

    static String runInstance(CLBInstance inst) {
        ArrayList<CArc> arcs = inst.arcs;
        int s = inst.org, t = inst.dest, N = inst.MAX_NODE;
        double L = inst.lengthBound;
        // [REV] Numerical safeguard: a binary u within IntFeasTol of 0 relaxes a big-M constraint
        // by up to M * IntFeasTol; this must stay well below THETA, otherwise invalid cuts can appear.
        if (CConfig.bigM(L) * CConfig.INT_FEAS_TOL > CConfig.THETA / 10) {
            System.err.println("WARNING " + inst.fileName + ": M*IntFeasTol = "
                    + CConfig.bigM(L) * CConfig.INT_FEAS_TOL + " is not << THETA = " + CConfig.THETA);
        }
        Result[] r = new Result[METHODS.length];
        for (int i = 0; i < r.length; i++) r[i] = Result.na();
        double t1 = Double.NaN, t2 = Double.NaN;

        // 1. MW-LBC (also stage 1 of LEX and HEUR)
        ClbcutM mw = new ClbcutM();
        try {
            mw.Init();
            mw.build_model(arcs, s, t, N, L);
            mw.solve();
            t1 = mw.runtime;
            r[0] = Result.of(arcs, s, t, L, mw.objScaled >= 0 ? mw.lbcut : null, mw.runtime, String.valueOf(mw.status));
            mw.end();
        } catch (Exception e) { e.printStackTrace(); }

        // 2. MWMC-LEX stage 2
        if (mw.objScaled >= 0) {
            try {
                ClbcutM2 lex = new ClbcutM2();
                lex.Init();
                lex.build_model(arcs, s, t, N, L, mw.objScaled);
                lex.solve();
                t2 = lex.runtime;
                r[1] = Result.of(arcs, s, t, L, lex.weightScaled >= 0 ? lex.lbcut : null, t1 + t2, String.valueOf(lex.status));
                lex.end();
            } catch (Exception e) { e.printStackTrace(); }
        }

        // 3. exact single-stage MWMC
        try {
            ClbcutLexExact ex = new ClbcutLexExact();
            ex.Init();
            ex.build_model(arcs, s, t, N, L);
            ex.solve();
            r[2] = Result.of(arcs, s, t, L, ex.weightScaled >= 0 ? ex.lbcut : null, ex.runtime, String.valueOf(ex.status));
            ex.end();
        } catch (Exception e) { e.printStackTrace(); }

        // 4-6. MWMC-eps
        for (int q = 0; q < EPS.length; q++) {
            try {
                ClbcutEpsilon ep = new ClbcutEpsilon();
                ep.Init();
                ep.build_model(arcs, s, t, N, L, EPS[q]);
                ep.solve();
                r[3 + q] = Result.of(arcs, s, t, L, ep.weightScaled >= 0 ? ep.lbcut : null, ep.runtime, String.valueOf(ep.status));
                ep.end();
            } catch (Exception e) { e.printStackTrace(); }
        }

        // 7. MWMC-HEURISTIC (restricted to the arcs of the MW-LBC cut)
        if (mw.objScaled >= 0) {
            try {
                CMinlbcutM h = new CMinlbcutM();
                h.Init();
                h.build_model(arcs, s, t, N, L, mw.trick);
                h.solve();
                r[6] = Result.of(arcs, s, t, L, h.weightScaled >= 0 ? h.lbcut : null, t1 + h.runtime, String.valueOf(h.status));
                h.end();
            } catch (Exception e) { e.printStackTrace(); }
        }

        // 8. eps-MIN (classical minimum cut, eps on (near-)zero-weight arcs)
        try {
            long a0 = System.nanoTime();
            CMinCut.Run(arcs, s, t);
            double tt = (System.nanoTime() - a0) / 1e9;
            r[7] = Result.of(arcs, s, t, L, new ArrayList<Integer>(CMinCut.lbcut), tt, "OK");
        } catch (Exception e) { e.printStackTrace(); }

        // 9. exact SPBA (no time limit)
        try {
            long a0 = System.nanoTime();
            ClbcutA sp = new ClbcutA();
            sp.Init();
            sp.Run(arcs, s, t, L, 0);
            double tt = (System.nanoTime() - a0) / 1e9;
            ArrayList<Integer> cut = null;
            if (sp.min_wt_scaled != Long.MAX_VALUE) {
                cut = new ArrayList<Integer>(sp.zero_weight_arclist);
                cut.addAll(sp.final_lb_cut_arclist);
            }
            r[8] = Result.of(arcs, s, t, L, cut, tt, sp.timedOut ? "TL" : "OPT");
        } catch (Exception e) { e.printStackTrace(); }

        // 10. SPBA-0.01 + cut-min
        try {
            long a0 = System.nanoTime();
            ClbcutA sp = new ClbcutA();
            sp.Init();
            sp.Run(arcs, s, t, L, CConfig.SPBA_SHORT_LIMIT);
            ArrayList<Integer> cut = null;
            if (sp.min_wt_scaled != Long.MAX_VALUE) {
                cut = new ArrayList<Integer>(sp.zero_weight_arclist);
                cut.addAll(sp.final_lb_cut_arclist);
                CCutMin cm = new CCutMin();
                cm.Run(arcs, s, t, L, cut);   // minimalizes 'cut' in place
            }
            double tt = (System.nanoTime() - a0) / 1e9;
            r[9] = Result.of(arcs, s, t, L, cut, tt, sp.timedOut ? "TL" : "OPT");
        } catch (Exception e) { e.printStackTrace(); }

        String src = Character.isDigit(inst.fileName.charAt(0)) ? "NDSR" : "RSLP";
        StringBuilder sb = new StringBuilder();
        sb.append(inst.fileName).append(',').append(src).append(',').append(inst.arc_number).append(',')
          .append(inst.node_number).append(',').append(fmt(L)).append(',')
          .append(fmt(t1)).append(',').append(fmt(t2));
        for (Result x : r) sb.append(',').append(x.toCsv());
        return sb.toString();
    }

    static String header() {
        StringBuilder h = new StringBuilder("instance,source,arcs,nodes,L,LEX_T1,LEX_T2");
        for (String m : METHODS) {
            h.append(',').append(m).append("_W,").append(m).append("_C,").append(m)
             .append("_T,").append(m).append("_valid,").append(m).append("_status");
        }
        return h.toString();
    }

    /** Accepts both .../LBC-Instances-1500 and the nested folder created by Windows "Extract All". */
    static String resolveFolder(String folder) {
        if (new File(folder, CInstance.files[0]).exists()) return folder;
        File nested = new File(folder, "LBC-Instances-1500");
        if (new File(nested, CInstance.files[0]).exists()) return nested.getPath();
        return folder;
    }

    static String fmt(double x) {
        return Double.isNaN(x) ? "" : String.format(Locale.US, "%.6f", x);
    }

    static HashSet<String> readDone(String out) {
        HashSet<String> done = new HashSet<String>();
        File f = new File(out);
        if (!f.exists()) return done;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line = br.readLine(); // header
            while ((line = br.readLine()) != null) {
                int c = line.indexOf(',');
                if (c > 0) done.add(line.substring(0, c));
            }
        } catch (IOException e) { e.printStackTrace(); }
        return done;
    }

    /** One method's outcome on one instance. */
    static class Result {
        long w = -1; int c = -1; double time = Double.NaN; int valid = -1; String status = "NA";

        static Result na() { return new Result(); }

        static Result of(ArrayList<CArc> arcs, int s, int t, double L, Collection<Integer> cut, double time, String status) {
            Result r = new Result();
            r.time = time;
            r.status = status;
            if (cut != null) {
                r.w = CValidator.scaledWeight(arcs, cut);
                r.c = cut.size();
                r.valid = CValidator.isValid(arcs, s, t, L, cut) ? 1 : 0;
            }
            return r;
        }

        String toCsv() {
            return (w >= 0 ? String.valueOf(w) : "") + "," + (c >= 0 ? String.valueOf(c) : "") + ","
                 + fmt(time) + "," + (valid >= 0 ? String.valueOf(valid) : "") + "," + status;
        }
    }
}
