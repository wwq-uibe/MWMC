package impl;

import java.util.ArrayList;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

/**
 * [MW-LBC] Minimum-weight lb-cut model; also stage 1 of MWMC-LEX.
 *
 * [REV 2026-11]
 *  - objective uses the integer-scaled weights W_a = round(w_a * 10^6), the same
 *    weights as stage 2 (ClbcutM2), so that Z* is passed exactly as an integer (objScaled);
 *  - distance potentials bounded by L + THETA and big-M = L + THETA (Proposition 2);
 *  - common Gurobi parameters (time limit, threads, seed) from CConfig.
 */
public class ClbcutM {

	public static int zero_gap=0;
	public static int max_gap=0;

	double obj;            // cut weight in original units (backward compatible)
	long objScaled = -1;   // [REV] cut weight in integer-scaled units (exact Z* for stage 2)
	double runtime;
	int status;
	double mipgap=Double.NaN;
	double objbound=Double.NaN;

	GRBEnv env;
	GRBModel model;

	GRBVar[] u;
	GRBVar[] pi;

	int org;
	int dest;

	double ps;

	public ArrayList<CArc> AS=new ArrayList<CArc>();

	ArrayList<Integer> lbcut=new ArrayList<Integer>();

	ArrayList<Integer> trick=new ArrayList<Integer>();

	public double Total_Weight=0;

	public void Init() throws GRBException {
		env = new GRBEnv(true);
		env.set("logFile", "knapsack.log");
		env.set(GRB.IntParam.OutputFlag, 0);
        env.start();

        model = new GRBModel(env);
        CGrb.apply(model, CConfig.TIME_LIMIT);
	}

	@SuppressWarnings("unchecked")
	public void build_model(ArrayList<CArc> ArcSet,int s,int t,int Node_N,double LEN_BOUND) throws GRBException {
		org=s;
		dest=t;
		AS=(ArrayList<CArc>) ArcSet.clone();
		double M = CConfig.bigM(LEN_BOUND);
		//init
		pi=new GRBVar[Node_N+1];
		u=new GRBVar[ArcSet.size()];
		for (int a=0;a<u.length;a++) {
	    	u[a]=model.addVar(0, 1, 0, GRB.BINARY, "u" +a);
	    }
		for (int i=0;i<pi.length;i++) {
			pi[i]=model.addVar(0, M, 0, GRB.CONTINUOUS, "pi"+i);
		}
		//constraint
		model.addConstr(pi[t], GRB.EQUAL, 0, null);

		for (int a=0;a<ArcSet.size();a++) {
			int i=ArcSet.get(a).real_left;
			int j=ArcSet.get(a).real_right;
			double dis=ArcSet.get(a).length;
			GRBLinExpr temp = new GRBLinExpr();
			temp.addTerm(1.0, pi[i]);
			temp.addTerm(-1.0, pi[j]);
			temp.addConstant(-dis);

			GRBLinExpr temp_M = new GRBLinExpr();
			temp_M.addTerm(M, u[a]);

			model.addConstr(temp, GRB.LESS_EQUAL, temp_M, null);
		}

		model.addConstr(pi[s], GRB.GREATER_EQUAL, LEN_BOUND + CConfig.THETA, null);

		//obj: integer-scaled weights
		GRBLinExpr obj = new GRBLinExpr();
		for (int a=0;a<u.length;a++) {
			obj.addTerm((double) CConfig.scaled(ArcSet.get(a).weight), u[a]);
		}
		model.setObjective(obj, GRB.MINIMIZE);
	}

	public void solve() throws GRBException {
		model.optimize();
		status = model.get(GRB.IntAttr.Status);
		runtime=model.get(GRB.DoubleAttr.Runtime);
		if (model.get(GRB.IntAttr.SolCount) == 0) {
			Total_Weight = Double.POSITIVE_INFINITY;
			obj = Double.POSITIVE_INFINITY;
			objScaled = -1;
			return;
		}
		objbound = model.get(GRB.DoubleAttr.ObjBound);
		if (status == GRB.Status.OPTIMAL) mipgap = 0.0;
		else { try { mipgap = model.get(GRB.DoubleAttr.MIPGap); } catch (Exception ignored) {} }
		lbcut.clear();
		trick.clear();
		Total_Weight = 0;
		objScaled = 0;
		for (int i=0;i<u.length;i++) {
			if (u[i].get(GRB.DoubleAttr.X)>0.5) {
				int arcindex=AS.get(i).index;
				lbcut.add(arcindex);
				trick.add(i);
				Total_Weight += AS.get(i).weight;
				objScaled += CConfig.scaled(AS.get(i).weight);
			}
		}
		obj = Total_Weight;
		ps=pi[org].get(GRB.DoubleAttr.X);
	}

	public void end () throws GRBException {
		model.dispose();
        env.dispose();
	}
}
