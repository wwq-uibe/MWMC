package impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * [REV 2026-11] Re-runs every instance whose row in the results CSV (default results_mwmc.csv) has a method
 * without a result (status NA or empty validity flag), e.g. after the
 * "Graph must contain the source vertex" exception fixed in CJGraph.Check.
 * New rows are written to results_mwmc_fix.csv; the analysis uses the fixed row
 * whenever an instance appears in both files. The original CSV is not modified.
 */
public class CRerunMissing {
    public static void main(String[] args) throws Exception {
        String folder = CRunExperiment.resolveFolder(args.length > 0 ? args[0] : "instances/LBC-Instances-1500");
        String in = args.length > 1 ? args[1] : "results_mwmc.csv";
        String out = args.length > 2 ? args[2] : "results_mwmc_fix.csv";

        ArrayList<String> todo = new ArrayList<String>();
        try (BufferedReader br = new BufferedReader(new FileReader(in))) {
            String[] head = br.readLine().split(",", -1);
            String line;
            while ((line = br.readLine()) != null) {
                String[] v = line.split(",", -1);
                for (int k = 0; k < head.length && k < v.length; k++) {
                    boolean bad = (head[k].endsWith("_status") && v[k].equals("NA"))
                               || (head[k].endsWith("_valid") && v[k].isEmpty());
                    if (bad) { todo.add(v[0]); break; }
                }
            }
        }
        // instances that already have a COMPLETE row in the fix file are skipped
        HashSet<String> done = readComplete(out);
        System.out.println("Instances to re-run: " + todo);

        boolean writeHeader = !new File(out).exists();
        try (BufferedWriter w = new BufferedWriter(new FileWriter(out, true))) {
            if (writeHeader) { w.write(CRunExperiment.header()); w.newLine(); w.flush(); }
            int k = 0;
            for (String name : todo) {
                k++;
                if (done.contains(name)) continue;
                CLBInstance inst = CLBInstance.readLBInstance(new File(folder, name));
                w.write(CRunExperiment.runInstance(inst));
                w.newLine();
                w.flush();
                System.out.println(k + "/" + todo.size() + "  " + name);
            }
        }
        System.out.println("Finished. Results in " + out);
    }

    /** Instances whose row in file f has a result for every method. */
    static HashSet<String> readComplete(String f) throws Exception {
        HashSet<String> ok = new HashSet<String>();
        if (!new File(f).exists()) return ok;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String[] head = br.readLine().split(",", -1);
            String line;
            while ((line = br.readLine()) != null) {
                String[] v = line.split(",", -1);
                boolean bad = false;
                for (int k = 0; k < head.length && k < v.length; k++) {
                    if ((head[k].endsWith("_status") && v[k].equals("NA"))
                            || (head[k].endsWith("_valid") && v[k].isEmpty())) { bad = true; break; }
                }
                if (!bad) ok.add(v[0]);
            }
        }
        return ok;
    }
}
